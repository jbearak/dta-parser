list(safe_reference = list(profiled = TRUE, calls = 2000L, interval_seconds = 0.001, 
    cleanup_before = list(classes = c("rlang_error", "error", 
    "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the\n  `dplyr::mutate()` expression ?"), 
    cleanup_after = list(classes = c("rlang_error", "error", 
    "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the\n  `dplyr::mutate()` expression ?"), 
    source_and_output_checks = "pass"), direct = list(profiled = TRUE, 
    calls = 2000L, interval_seconds = 0.001, cleanup_before = list(
        classes = c("rlang_error", "error", "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?"), 
    cleanup_after = list(classes = c("rlang_error", "error", 
    "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?"), 
    source_and_output_checks = "pass"))
