list(expanded = list(tibble = list(events = c("x:1", "x:2", "y:1", 
"y:2"), factories = 1L, names = c("g", "x", "y"), columns = list(
    g = c(1L, 1L, 2L), x = 1:3, y = 4:6)), dibble = list(events = c("x:1", 
"x:2", "y:1", "y:2"), factories = 1L, names = c("g", "x", "y"
), columns = list(g = c(1L, 1L, 2L), x = 1:3, y = 4:6))), aliased = list(
    tibble = list(events = c("x:1", "y:1", "x:2", "y:2"), factories = 4L, 
        names = c("g", "x", "y"), columns = list(g = c(1L, 1L, 
        2L), x = 1:3, y = 4:6)), dibble = list(events = c("x:1", 
    "y:1", "x:2", "y:2"), factories = 4L, names = c("g", "x", 
    "y"), columns = list(g = c(1L, 1L, 2L), x = 1:3, y = 4:6))), 
    named = list(tibble = list(events = c("x:1", "y:1", "x:2", 
    "y:2"), factories = 4L, names = c("g", "x", "y", "packed"
    ), columns = list(g = c(1L, 1L, 2L), x = 1:3, y = 4:6, packed = list(
        x = 1:3, y = 4:6))), dibble = list(events = c("x:1", 
    "y:1", "x:2", "y:2"), factories = 4L, names = c("g", "x", 
    "y", "packed"), columns = list(g = c(1L, 1L, 2L), x = 1:3, 
        y = 4:6, packed = list(x = 1:3, y = 4:6)))), unpacked = list(
        tibble = list(events = c("x:1", "y:1", "x:2", "y:2"), 
            factories = 0L, names = c("g", "x", "y", "x_value", 
            "y_value"), columns = list(g = c(1L, 1L, 2L), x = 1:3, 
                y = 4:6, x_value = 1:3, y_value = 4:6)), dibble = list(
            events = c("x:1", "y:1", "x:2", "y:2"), factories = 0L, 
            names = c("g", "x", "y", "x_value", "y_value"), columns = list(
                g = c(1L, 1L, 2L), x = 1:3, y = 4:6, x_value = 1:3, 
                y_value = 4:6))), within_across_input_values = list(
        x = c(11L, 13L), y = c(11L, 13L)), identity = list(source = "a2d8b6a5a00d75cf20c962d3f28cf959ed4192b9", 
        R = "R version 4.6.0 (2026-04-24)", library = "/private/tmp/dta-direct-stage5-validation/root-r460-integration/candidate-a2d8b6a-v1/library/dtatools", 
        DLL = "/private/tmp/dta-direct-stage5-validation/root-r460-integration/candidate-a2d8b6a-v1/library/dtatools/libs/dtatools.so", 
        dplyr = "1.2.1", namespace_paths = c(dtatools = "/private/tmp/dta-direct-stage5-validation/root-r460-integration/candidate-a2d8b6a-v1/library/dtatools", 
        tidyselect = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/tidyselect", 
        compiler = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/compiler", 
        R6 = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/R6", 
        magrittr = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/magrittr", 
        generics = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/generics", 
        cli = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/cli", 
        graphics = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/graphics", 
        tools = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/tools", 
        withr = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/withr", 
        pillar = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/pillar", 
        glue = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/glue", 
        dplyr = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dplyr-libraries/1.2.1/dplyr", 
        utils = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/utils", 
        tibble = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/tibble", 
        grDevices = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/grDevices", 
        stats = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/stats", 
        datasets = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/datasets", 
        vctrs = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/vctrs", 
        methods = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R/library/methods", 
        lifecycle = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/lifecycle", 
        pkgconfig = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/pkgconfig", 
        rlang = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-dependencies/rlang"
        )))
