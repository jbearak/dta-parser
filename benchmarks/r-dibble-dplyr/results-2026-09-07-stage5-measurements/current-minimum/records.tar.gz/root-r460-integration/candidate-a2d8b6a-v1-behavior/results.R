list(identity = list(source = "a2d8b6a5a00d75cf20c962d3f28cf959ed4192b9", 
    R = "R version 4.6.0 (2026-04-24)", R_home = "/private/tmp/dta-direct-stage5-minimum-preflight/r460-clean-install/lib/R", 
    package = "/private/tmp/dta-direct-stage5-validation/root-r460-integration/candidate-a2d8b6a-v1/library/dtatools", 
    DLL = "/private/tmp/dta-direct-stage5-validation/root-r460-integration/candidate-a2d8b6a-v1/library/dtatools/libs/dtatools.so", 
    DLL_md5 = "94793894f79a05b4831cca75ea6a1e63", namespaces = c("R6", 
    "base", "cli", "compiler", "data.table", "datasets", "dplyr", 
    "dtatools", "generics", "glue", "grDevices", "graphics", 
    "lifecycle", "magrittr", "methods", "pillar", "pkgconfig", 
    "rlang", "stats", "tibble", "tidyselect", "tools", "utils", 
    "vctrs", "withr"), versions = c(R6 = "2.6.1", base = "4.6.0", 
    cli = "3.6.6", compiler = "4.6.0", data.table = "1.18.6.1", 
    datasets = "4.6.0", dplyr = "1.2.1", dtatools = "0.7.1", 
    generics = "0.1.4", glue = "1.8.1", grDevices = "4.6.0", 
    graphics = "4.6.0", lifecycle = "1.0.5", magrittr = "2.0.5", 
    methods = "4.6.0", pillar = "1.11.1", pkgconfig = "2.0.3", 
    rlang = "1.3.0", stats = "4.6.0", tibble = "3.3.1", tidyselect = "1.2.1", 
    tools = "4.6.0", utils = "4.6.0", vctrs = "0.7.3", withr = "3.0.3"
    )), cases = list(`sequential missing typing` = list(passed = TRUE, 
    observations = TRUE, warnings = character(0)), `repeated output preserves current metadata then deletion clears it` = list(
    passed = TRUE, observations = TRUE, warnings = character(0)), 
    `captured input and both table aliases isolate later writes` = list(
        passed = TRUE, observations = TRUE, warnings = character(0)), 
    `group values remain stable across groups and later expressions` = list(
        passed = TRUE, observations = TRUE, warnings = character(0)), 
    `rowwise list extraction and captured vectors` = list(passed = TRUE, 
        observations = TRUE, warnings = character(0)), `arbitrary helper reads contribute to keep used` = list(
        passed = TRUE, observations = TRUE, warnings = character(0)), 
    `foreign data table result is captured` = list(passed = TRUE, 
        observations = TRUE, warnings = character(0)), `late promises and mask closures are characterized without parity assumption` = list(
        passed = TRUE, observations = list(promises = list(list(
            kind = "error", classes = c("rlang_error", "error", 
            "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?"), 
            list(kind = "error", classes = c("rlang_error", "error", 
            "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?")), 
            closures = list(list(kind = "error", classes = c("rlang_error", 
            "error", "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?"), 
                list(kind = "error", classes = c("rlang_error", 
                "error", "condition"), message = "Obsolete data mask.\n✖ Too late to resolve `x` after the end of `dplyr::mutate()`.\nℹ Did you save an object that uses `x` lazily in a column in the `dplyr::mutate()` expression ?"))), 
        warnings = c("restarting interrupted promise evaluation", 
        "restarting interrupted promise evaluation", "restarting interrupted promise evaluation"
        ))))
