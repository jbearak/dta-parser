args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
source(file.path(support, "workloads-v1.R"))
source(file.path(support, "validation-v1.R"))
suppressPackageStartupMessages(library(bench))
index <- seq_len(16L)
width <- 8L
payload <- sprintf("c%02d", seq_len(width))
duplicate <- TRUE
        pipeline <- function(value) {
            value <- dplyr::rename(value, renamed = c01)
            selected <- c("key", "renamed", payload[-1L])
            if (duplicate) value <- dplyr::select(value, tidyselect::all_of(c(stats::setNames(selected, selected), copy = "renamed")))
            else value <- dplyr::select(value, tidyselect::all_of(selected))
            if (duplicate) value <- dplyr::relocate(value, copy, .before = renamed)
            else value <- dplyr::relocate(value, c08, .before = renamed)
            value <- dplyr::rename(value, c01 = renamed)
            if (duplicate) dplyr::relocate(value, copy, .after = c08)
            else dplyr::relocate(value, c08, .after = c07)
        }
records <- list()
for (container in c("tibble", "dibble")) {
    columns <- lapply(seq_len(width), function(i) s8_payload(index, i, 1L))
    names(columns) <- payload
    raw <- tibble::new_tibble(c(list(key = dtatools::dta_long(index)), columns), nrow = 16L)
    attr(raw, "label") <- "Stage 8 input 1"
    original <- if (container == "dibble") dtatools::as_dibble(raw) else raw
    original_schema <- s8_schema(original)
    expected <- original_schema
    expected$metadata$names <- c("key", payload, "copy")
    expected$slots <- c(expected$slots, expected$slots[2L])
    expected_value <- function(i) {
        if (container == "tibble" && i == 7L) as.integer(index %% 67L + 100L)
        else s8_values(index, i, 1L)
    }
    latest <- original
    for (call in 1:2) {
        latest <- pipeline(latest)
        s8_table(latest, 16L, c("key", payload, "copy"), dibble = container == "dibble")
        s8_column(latest, "key", as.double(index))
        for (i in seq_len(width)) s8_column(latest, payload[[i]], expected_value(i))
        s8_column(latest, "copy", s8_values(index, 1L, 1L))
        stopifnot(identical(s8_schema(latest), expected), identical(s8_schema(original), original_schema))
        s8_table(original, 16L, c("key", payload), dibble = container == "dibble")
        s8_column(original, "key", as.double(index))
        for (i in seq_len(width)) s8_column(original, payload[[i]], expected_value(i))
        left_slot <- match("c01", names(latest))
        copy_slot <- match("copy", names(latest))
        shared_slot <- identical(rlang::obj_address(.subset2(latest, left_slot)),
            rlang::obj_address(.subset2(latest, copy_slot)))
        stopifnot(shared_slot)
        source_handle_separate <- NA
        if (container == "dibble") {
            left_handle <- owned_native("C_dtatools_mutation_info", latest, as.integer(left_slot))$handle
            copy_handle <- owned_native("C_dtatools_mutation_info", latest, as.integer(copy_slot))$handle
            original_handle <- owned_native("C_dtatools_mutation_info", original, 2L)$handle
            stopifnot(identical(left_handle, copy_handle))
            source_handle_separate <- !identical(left_handle, original_handle)
            stopifnot(source_handle_separate)
        }
        records[[length(records) + 1L]] <- data.frame(container, call,
            names = paste(names(latest), collapse = ","), values_schema_source = TRUE,
            shared_slot, source_handle_separate)
        write.csv(do.call(rbind, records), file.path(output, "duplicate-preflight.csv"), row.names = FALSE)
    }
}
stopifnot(length(records) == 4L)
validate_benchmark_install(library_path, args[[3L]])
cat("PASS four explicit-named duplicate selector pipelines across tibble/dibble, with independent values/schema/source checks.\n")
