# Twenty-four fresh children. Public installed writes after500calls; no timing/RSS/heap measurement.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
source_sha <- args[[3L]]
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
suppressPackageStartupMessages(library(bench))

write_worker <- function(library_path, source_sha, support, helper_root,
                             kind, lifetime, duplicate, direction, write_kind, output) {
    .libPaths(c(library_path, "/opt/homebrew/lib/R/4.6/site-library", .Library))
    record_runtime <- function() {
        ns <- sort(loadedNamespaces())
        write.table(data.frame(name = ns, path = vapply(ns, function(name)
            if (name == "base") file.path(.Library, "base") else
                getNamespaceInfo(asNamespace(name), "path"), character(1))),
            file.path(output, "namespaces.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
        dlls <- getLoadedDLLs()
        write.table(data.frame(name = names(dlls), path = vapply(dlls,
            function(dll) dll[["path"]], character(1))), file.path(output, "dlls.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
        writeLines(capture.output(sessionInfo()), file.path(output, "runtime.txt"))
    }
    tryCatch({
        library(dtatools, lib.loc = library_path)
        selected <- getNamespaceInfo(asNamespace("dtatools"), "path")
        stopifnot(identical(normalizePath(selected),
            normalizePath(file.path(library_path, "dtatools"))))
        provenance <- readRDS(file.path(selected, "Meta", "benchmark-provenance.rds"))
        stopifnot(identical(provenance$source_sha, source_sha))
        source(file.path(support, "workloads-v1.R"))
        source(file.path(support, "validation-v1.R"))
        # The copied benchmark helper sources use their repository-relative paths.
        setwd(helper_root)
        source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
        rows <- 16L
        width <- 8L
        index <- seq_len(rows)
        payload <- sprintf("c%02d", seq_len(width))
        pipeline <- function(value) {
            value <- dplyr::rename(value, renamed = c01)
            selected <- c("key", "renamed", payload[-1L])
            if (duplicate) value <- dplyr::select(value, tidyselect::all_of(c(stats::setNames(selected, selected), copy = "renamed")))
            else value <- dplyr::select(value, tidyselect::all_of(selected))
            if (duplicate) value <- dplyr::relocate(value, copy, .before = renamed)
            else value <- dplyr::relocate(value, c08, .before = renamed)
            value <- dplyr::rename(value, c01 = renamed)
            if (duplicate) dplyr::relocate(value, copy, .after = c08)
            else dplyr::relocate(value, c08, .after = c07)
        }
        fresh_raw <- function() {
            columns <- lapply(seq_len(width), function(i) s8_payload(index, i, 1L))
            names(columns) <- payload
            raw <- tibble::new_tibble(c(list(key = dtatools::dta_long(index)), columns), nrow = rows)
            attr(raw, "label") <- "Stage 8 input 1"
            raw
        }
        operation <- switch(kind, selector = pipeline,
            constructor = function(value) dtatools::as_dibble(fresh_raw()),
            reserve = function(value) dtatools::reserve_columns(value, n = 32L))
        stopifnot(is.function(operation))
        check <- function(value, expected_schema, has_duplicate) {
            s8_table(value, rows, c("key", payload, if (has_duplicate) "copy"))
            s8_column(value, "key", as.double(index))
            for (i in seq_len(width)) s8_column(value, payload[[i]], s8_values(index, i, 1L))
            if (has_duplicate) s8_column(value, "copy", s8_values(index, 1L, 1L))
            stopifnot(identical(s8_schema(value), expected_schema))
            invisible(NULL)
        }
        warm <- s8_frame(index, width, 1L)
        original_schema <- s8_schema(warm)
        expected_schema <- original_schema
        if (duplicate) {
            expected_schema$metadata$names <- c("key", payload, "copy")
            expected_schema$slots <- c(expected_schema$slots, expected_schema$slots[2L])
        }
        warm_result <- operation(warm)
        check(warm, original_schema, FALSE)
        check(warm_result, expected_schema, duplicate)
        rm(warm, warm_result)
        original <- if (kind == "constructor") NULL else s8_frame(index, width, 1L)
        latest <- original
        first <- NULL
        if (lifetime == "latest_chain") original <- NULL
        for (i in seq_len(500L)) {
            latest <- operation(if (lifetime == "fixed_original") original else latest)
            if (i == 1L && lifetime == "retained_chain") first <- latest
        }
        if (!is.null(original)) check(original, original_schema, FALSE)
        if (!is.null(first)) check(first, expected_schema, duplicate)
        check(latest, expected_schema, duplicate)
        writeLines("500", file.path(output, "completed-calls.txt"))
        # Atomic observations use newly allocated ordinary vectors. No payload
        # view from the tested table is retained as the before/expected graph.
        semantic <- function(value) {
            if (is.null(value)) return(NULL)
            fields <- attributes(value)
            fields$.dtatools_ref_state <- NULL
            fields$.internal.selfref <- NULL
            fields <- fields[sort(names(fields))]
            if (typeof(value) == "list") {
                contents <- lapply(seq_along(value), function(i) semantic(.subset2(value, i)))
            } else {
                storage <- switch(typeof(value), logical = "integer", integer = "integer",
                    double = "double", character = "character", stop("Unexpected snapshot type"))
                contents <- vector(storage, length(value))
                for (i in seq_along(value)) contents[[i]] <- switch(typeof(value),
                    logical = as.integer(.subset2(value, i)), integer = as.integer(.subset2(value, i)),
                    double = as.double(.subset2(value, i)), character = as.character(.subset2(value, i)))
            }
            list(type = typeof(value), fields = lapply(fields, semantic), values = contents)
        }
        before <- list(original = semantic(original), first = semantic(first), latest = semantic(latest))
        role <- if (direction == "source") "original" else "latest"
        target <- if (direction == "source") original else latest
        stopifnot(!is.null(target), "c01" %in% names(target))
        affected_columns <- c("c01", if ("copy" %in% names(target)) "copy")
        if (length(affected_columns) == 2L) stopifnot(identical(
            rlang::obj_address(.subset2(target, "c01")), rlang::obj_address(.subset2(target, "copy"))))
        slots <- match(affected_columns, names(target))
        prior <- before[[role]]$values[[slots[[1L]]]]$values[[1L]]
        stopifnot(is.finite(prior))
        expected <- unserialize(serialize(before, NULL))
        changed <- prior + .125
        label <- "Changed after 500 calls"
        for (slot in slots) {
            if (write_kind == "payload") expected[[role]]$values[[slot]]$values[[1L]] <- changed
            else expected[[role]]$values[[slot]]$fields$label <- semantic(label)
        }
        before_primitives <- c(as.integer(TRUE), as.integer(FALSE))
        writeLines(as.character(before_primitives), file.path(output, "primitives-before.txt"))
        observation <- list(kind = kind, lifetime = lifetime, duplicate = duplicate,
            direction = direction, write_kind = write_kind, calls = 500L, rows = rows,
            role = role, affected_columns = affected_columns, target_row = 1L,
            before = before, expected = expected)
        saveRDS(observation, file.path(output, "prepared-observations.rds"), compress = FALSE)
        if (write_kind == "payload") data.table::set(target, i = 1L, j = "c01", value = changed)
        else data.table::setattr(.subset2(target, "c01"), "label", label)
        after_primitives <- c(as.integer(TRUE), as.integer(FALSE))
        writeLines(as.character(c(before_primitives, after_primitives)), file.path(output, "primitives.txt"))
        after <- list(original = semantic(original), first = semantic(first), latest = semantic(latest))
        observation$after <- after
        saveRDS(observation, file.path(output, "observations.rds"), compress = FALSE)
        stopifnot(identical(before_primitives, c(1L, 0L)), identical(after_primitives, c(1L, 0L)))
        if (!identical(after, expected)) {
            writeLines(capture.output(dput(all.equal(after, expected))), file.path(output, "difference.txt"))
            stop("Intended write or protected source/first/latest state differs")
        }
        result <- list(passed = TRUE, kind = kind, lifetime = lifetime, duplicate = duplicate,
            direction = direction, write_kind = write_kind, calls = 500L,
            verbs_per_call = if (kind == "selector") 5L else 1L, rows = rows,
            payload_width = width, source_sha = source_sha, namespace_path = selected,
            affected_columns = affected_columns, primitives = after_primitives,
            scope = "Public installed numeric/column-label writes after500calls. Exact declared retained roles and all tiny semantic nodes protected; duplicate result slots intentionally coupled. No timing/RSS/heap/complete child-image or arbitrarytype/foreignextension qualification.")
        dput(result, file.path(output, "result.R"))
        result
    }, finally = tryCatch(record_runtime(), error = function(error) {
        writeLines(conditionMessage(error), file.path(output, "runtime-recording-error.txt"))
    }))
}

base_cases <- expand.grid(kind = "selector", lifetime = c("fixed_original", "latest_chain", "retained_chain"),
                     duplicate = c(FALSE, TRUE), stringsAsFactors = FALSE)
base_cases <- rbind(base_cases, data.frame(kind = c("constructor", "reserve"),
    lifetime = "latest_chain", duplicate = FALSE))
cases <- do.call(rbind, lapply(seq_len(nrow(base_cases)), function(i) {
    case <- base_cases[i, ]
    directions <- if (case$kind == "selector" && case$lifetime != "latest_chain")
        c("source", "result") else "result"
    writes <- expand.grid(direction = directions, write_kind = c("payload", "metadata"),
        stringsAsFactors = FALSE)
    cbind(case[rep(1L, nrow(writes)), ], writes)
}))
stopifnot(nrow(cases) == 24L)
records <- list()
for (i in seq_len(nrow(cases))) {
    case <- cases[i, ]
    name <- paste(case$kind, case$lifetime, case$duplicate, case$direction, case$write_kind, sep = "-")
    destination <- file.path(output, name)
    stopifnot(dir.create(destination))
    result <- tryCatch(callr::r(write_worker, args = list(library_path, source_sha, support,
        getwd(), case$kind, case$lifetime, case$duplicate, case$direction, case$write_kind, destination), libpath = .libPaths(),
        stdout = file.path(destination, "stdout.log"), stderr = file.path(destination, "stderr.log"),
        timeout = 600), error = function(error) list(passed = FALSE,
            error_classes = class(error), error_message = conditionMessage(error)))
    dput(result, file.path(destination, "parent-result.R"))
    passed <- isTRUE(result$passed) && !file.exists(file.path(destination, "runtime-recording-error.txt"))
    records[[length(records) + 1L]] <- cbind(case, data.frame(planned_calls = 500L, passed = passed))
    write.csv(do.call(rbind, records), file.path(output, "retention-write-cases.csv"), row.names = FALSE)
    if (!passed) stop(paste("Retained write child failure:", name))
}
stopifnot(length(records) == 24L)
validate_benchmark_install(library_path, source_sha)
cat("PASS twenty-four public installed write cases after500calls; protected roles and intended duplicate-slot coupling checked.\n")
