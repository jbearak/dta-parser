# Eight fresh children. Retained heap only; no timing/RSS acceptance.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
source_sha <- args[[3L]]
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
suppressPackageStartupMessages(library(bench))

retention_worker <- function(library_path, source_sha, support, helper_root,
                             kind, lifetime, duplicate, output) {
    .libPaths(c(library_path, "/opt/homebrew/lib/R/4.6/site-library", .Library))
    record_runtime <- function() {
        ns <- sort(loadedNamespaces())
        write.table(data.frame(name = ns, path = vapply(ns, function(name)
            if (name == "base") file.path(.Library, "base") else
                getNamespaceInfo(asNamespace(name), "path"), character(1))),
            file.path(output, "namespaces.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
        dlls <- getLoadedDLLs()
        write.table(data.frame(name = names(dlls), path = vapply(dlls,
            function(dll) dll[["path"]], character(1))), file.path(output, "dlls.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
        writeLines(capture.output(sessionInfo()), file.path(output, "runtime.txt"))
    }
    tryCatch({
        library(dtatools, lib.loc = library_path)
        selected <- getNamespaceInfo(asNamespace("dtatools"), "path")
        stopifnot(identical(normalizePath(selected),
            normalizePath(file.path(library_path, "dtatools"))))
        provenance <- readRDS(file.path(selected, "Meta", "benchmark-provenance.rds"))
        stopifnot(identical(provenance$source_sha, source_sha))
        source(file.path(support, "workloads-v1.R"))
        source(file.path(support, "validation-v1.R"))
        # The copied benchmark helper sources use their repository-relative paths.
        setwd(helper_root)
        source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
        rows <- 256L
        width <- 8L
        index <- seq_len(rows)
        payload <- sprintf("c%02d", seq_len(width))
        pipeline <- function(value) {
            value <- dplyr::rename(value, renamed = c01)
            selected <- c("key", "renamed", payload[-1L])
            if (duplicate) value <- dplyr::select(value, tidyselect::all_of(c(stats::setNames(selected, selected), copy = "renamed")))
            else value <- dplyr::select(value, tidyselect::all_of(selected))
            if (duplicate) value <- dplyr::relocate(value, copy, .before = renamed)
            else value <- dplyr::relocate(value, c08, .before = renamed)
            value <- dplyr::rename(value, c01 = renamed)
            if (duplicate) dplyr::relocate(value, copy, .after = c08)
            else dplyr::relocate(value, c08, .after = c07)
        }
        fresh_raw <- function() {
            columns <- lapply(seq_len(width), function(i) s8_payload(index, i, 1L))
            names(columns) <- payload
            raw <- tibble::new_tibble(c(list(key = dtatools::dta_long(index)), columns), nrow = rows)
            attr(raw, "label") <- "Stage 8 input 1"
            raw
        }
        operation <- switch(kind, selector = pipeline,
            constructor = function(value) dtatools::as_dibble(fresh_raw()),
            reserve = function(value) dtatools::reserve_columns(value, n = 32L))
        stopifnot(is.function(operation))
        state <- function(value, checkpoint, role) {
            records <- lapply(seq_along(value), function(i) {
                column <- .subset2(value, i)
                owned <- owned_native("C_dtatools_owned_info", column)
                if (!is.null(owned)) stopifnot(owned$depth == 1L)
                cbind(data.frame(checkpoint, role, column = names(value)[[i]],
                    type = typeof(column), owned = !is.null(owned)),
                    as.data.frame(owned_native("C_dtatools_mutation_info", value, as.integer(i))))
            })
            path <- file.path(output, "states.csv")
            write.table(do.call(rbind, records), path, sep = ",", row.names = FALSE,
                        col.names = !file.exists(path), append = file.exists(path))
            invisible(NULL)
        }
        check <- function(value, expected_schema, has_duplicate) {
            s8_table(value, rows, c("key", payload, if (has_duplicate) "copy"))
            s8_column(value, "key", as.double(index))
            for (i in seq_len(width)) s8_column(value, payload[[i]], s8_values(index, i, 1L))
            if (has_duplicate) s8_column(value, "copy", s8_values(index, 1L, 1L))
            stopifnot(identical(s8_schema(value), expected_schema))
            invisible(NULL)
        }
        warm <- s8_frame(index, width, 1L)
        original_schema <- s8_schema(warm)
        expected_schema <- original_schema
        if (duplicate) {
            expected_schema$metadata$names <- c("key", payload, "copy")
            expected_schema$slots <- c(expected_schema$slots, expected_schema$slots[2L])
        }
        warm_result <- operation(warm)
        check(warm, original_schema, FALSE)
        check(warm_result, expected_schema, duplicate)
        state(warm_result, "prime", "discarded_warm_result")
        rm(warm, warm_result)
        heap <- list()
        record_heap <- function(checkpoint) {
            invisible(gc(full = TRUE))
            current <- gc(full = TRUE)
            heap[[length(heap) + 1L]] <<- data.frame(checkpoint,
                n_cells_used = current["Ncells", "used"], v_cells_used = current["Vcells", "used"],
                vector_heap_bytes = current["Vcells", "used"] * 8,
                gc_used_megabytes_rounded = sum(current[, 2L]))
            write.csv(do.call(rbind, heap), file.path(output, "heap.csv"), row.names = FALSE)
            invisible(NULL)
        }
        record_heap("prefixture")
        original <- if (kind == "constructor") NULL else s8_frame(index, width, 1L)
        latest <- original
        first <- NULL
        if (lifetime == "latest_chain") original <- NULL
        record_heap("0")
        if (!is.null(original)) state(original, "0", "original")
        if (!is.null(latest)) state(latest, "0", "latest")
        for (i in seq_len(500L)) {
            latest <- operation(if (lifetime == "fixed_original") original else latest)
            if (i == 1L && lifetime == "retained_chain") first <- latest
            if (i %in% c(5L, 50L, 500L)) {
                record_heap(as.character(i))
                if (!is.null(original)) state(original, as.character(i), "original")
                if (!is.null(first)) state(first, as.character(i), "first")
                state(latest, as.character(i), "latest")
            }
        }
        record_heap("before_validation")
        if (!is.null(original)) check(original, original_schema, FALSE)
        if (!is.null(first)) check(first, expected_schema, duplicate)
        check(latest, expected_schema, duplicate)
        record_heap("after_validation")
        if (!is.null(original)) state(original, "after_validation", "original")
        if (!is.null(first)) state(first, "after_validation", "first")
        state(latest, "after_validation", "latest")
        original <- first <- latest <- NULL
        record_heap("released")
        for (i in seq_len(3L)) record_heap(paste0("released_gc_", i))
        result <- list(passed = TRUE, kind = kind, lifetime = lifetime, duplicate = duplicate,
            calls = 500L, verbs_per_call = if (kind == "selector") 5L else 1L,
            rows = rows, payload_width = width, source_sha = source_sha,
            namespace_path = selected,
            scope = "Post-GC retained heap, recorder included; all live values/schemas and selected native depth checked; no timing/RSS/asymptotic or exclusive object-cause claim")
        dput(result, file.path(output, "result.R"))
        result
    }, finally = tryCatch(record_runtime(), error = function(error) {
        writeLines(conditionMessage(error), file.path(output, "runtime-recording-error.txt"))
    }))
}

cases <- expand.grid(kind = "selector", lifetime = c("fixed_original", "latest_chain", "retained_chain"),
                     duplicate = c(FALSE, TRUE), stringsAsFactors = FALSE)
cases <- rbind(cases, data.frame(kind = c("constructor", "reserve"),
    lifetime = "latest_chain", duplicate = FALSE))
records <- list()
for (i in seq_len(nrow(cases))) {
    case <- cases[i, ]
    name <- paste(case$kind, case$lifetime, case$duplicate, sep = "-")
    destination <- file.path(output, name)
    stopifnot(dir.create(destination))
    result <- tryCatch(callr::r(retention_worker, args = list(library_path, source_sha, support,
        getwd(), case$kind, case$lifetime, case$duplicate, destination), libpath = .libPaths(),
        stdout = file.path(destination, "stdout.log"), stderr = file.path(destination, "stderr.log"),
        timeout = 600), error = function(error) list(passed = FALSE,
            error_classes = class(error), error_message = conditionMessage(error)))
    dput(result, file.path(destination, "parent-result.R"))
    passed <- isTRUE(result$passed) && !file.exists(file.path(destination, "runtime-recording-error.txt"))
    records[[length(records) + 1L]] <- cbind(case, data.frame(planned_calls = 500L, passed = passed))
    write.csv(do.call(rbind, records), file.path(output, "retention-cases.csv"), row.names = FALSE)
    if (!passed) stop(paste("Retained child failure:", name))
}
stopifnot(length(records) == 8L)
validate_benchmark_install(library_path, source_sha)
cat("PASS eight installed-source retained-heap children; separate source/result lifetimes preserved.\n")
