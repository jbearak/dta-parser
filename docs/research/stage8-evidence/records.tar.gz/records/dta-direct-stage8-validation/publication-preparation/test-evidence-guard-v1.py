from pathlib import Path
import copy, importlib.util, json, sys, tempfile

source=Path(__file__).with_name('prepare-evidence-v1.py')
spec=importlib.util.spec_from_file_location('evidence',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
row=dict(path='/private/tmp/example.txt',resolved='/private/tmp/example.txt',bytes=0,mode='0o644',sha256='e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',member='records/example.txt')
cases=[]
def case(name,fn,reject):
    error=None
    try: fn()
    except RuntimeError as exc: error=str(exc)
    if (error is not None)!=reject:raise RuntimeError('Wrong guard outcome: '+name)
    cases.append(dict(name=name,rejected=reject,error=error))
def changed(**kw):
    r=copy.deepcopy(row);r.update(kw);return [r]
case('valid complete identity',lambda:m.validate([row]),False)
case('duplicate path and member',lambda:m.validate([row,row]),True)
case('missing digest',lambda:m.validate([{k:v for k,v in row.items() if k!='sha256'}]),True)
case('malformed digest',lambda:m.validate(changed(sha256='123')),True)
case('wrong member',lambda:m.validate(changed(member='records/other.txt')),True)
case('escaping source',lambda:m.validate(changed(path='/private/tmp/../escape.txt')),True)
case('boolean bytes',lambda:m.validate(changed(bytes=True)),True)
case('empty selection',lambda:m.validate([]),True)
with tempfile.TemporaryDirectory(prefix='stage8-evidence-guard-',dir='/private/tmp') as d:
    p=Path(d)/'target';p.write_text('test');link=Path(d)/'link';link.symlink_to(p)
    case('symlink input rejected',lambda:m.fact(link),True)
print(json.dumps(dict(argv=sys.orig_argv,optimize=sys.flags.optimize,cases=cases,status='pass')))
