test_that("B01 mixed binding order and containers are observed", {
    on.exit(.s8b_finish_block("B01", 60L))
    operations <- list(base_rows = .s8b_operation("base", "rbind"), base_cols = .s8b_operation("base", "cbind"),
        dplyr_rows = .s8b_operation("dplyr", "bind_rows"), dplyr_cols = .s8b_operation("dplyr", "bind_cols"),
        vctrs_rows = .s8b_operation("vctrs", "vec_rbind"), vctrs_cols = .s8b_operation("vctrs", "vec_cbind"))
    for (kind in c("frame", "tibble", "reference", "grouped", "rowwise"))
        for (order in c("dibble_first", "dibble_second"))
            for (name in names(operations)) {
                first <- .s8b_frame(if (order == "dibble_first") "dibble" else kind,
                    .s8b_columns())
                second <- .s8b_frame(if (order == "dibble_second") "dibble" else kind,
                    .s8b_columns(2L))
                .s8b_observe(paste("B01", kind, order, name, sep = "/"),
                    list(first, second), operations[[name]])
            }
})

test_that("B02 binding names ids sizes and prototypes are observed", {
    on.exit(.s8b_finish_block("B02", 12L))
    x <- function() .s8b_frame("dibble", .s8b_columns())
    y <- function() .s8b_frame("tibble", .s8b_columns(2L))
    .s8b_observe("B02/leading_NULL_rows", list(NULL, x(), y()), .s8b_operation("dplyr", "bind_rows"))
    .s8b_observe("B02/leading_NULL_cols", list(NULL, x(), y()), .s8b_operation("dplyr", "bind_cols"))
    .s8b_observe("B02/named_id", list(left = x(), right = y()),
        .s8b_operation("dplyr", "bind_rows"), list(.id = "origin"))
    .s8b_observe("B02/id_collision", list(left = x(), right = y()),
        .s8b_operation("dplyr", "bind_rows"), list(.id = "value"))
    .s8b_observe("B02/column_union", list(x(), tibble::tibble(k = 3L, extra = "z")),
        .s8b_operation("dplyr", "bind_rows"))
    .s8b_observe("B02/factor_union", list(dibble(k = 1L, f = factor("a")),
        tibble::tibble(k = 2L, f = factor("b"))), .s8b_operation("dplyr", "bind_rows"))
    .s8b_observe("B02/zero_rows_base", list(dibble(k = integer(), value = double()), y()),
        .s8b_operation("base", "rbind"))
    .s8b_observe("B02/zero_columns_vctrs", list(tibble::new_tibble(list(), nrow = 2L), x()),
        .s8b_operation("vctrs", "vec_cbind"))
    .s8b_observe("B02/explicit_ptype", list(x(), y()), .s8b_operation("vctrs", "vec_rbind"),
        list(.ptype = tibble::tibble(k = double(), value = double())))
    .s8b_observe("B02/minimal_names", list(x(), y()), .s8b_operation("dplyr", "bind_cols"),
        list(.name_repair = "minimal"))
    .s8b_observe("B02/scalar_recycling", list(x(), extra = 7L), .s8b_operation("dplyr", "bind_cols"))
    .s8b_observe("B02/named_frame_packing", list(left = x(), right = y()), .s8b_operation("vctrs", "vec_cbind"))
})

test_that("B03 every rows verb records keys values and result container", {
    on.exit(.s8b_finish_block("B03", 18L))
    for (kind in c("frame", "tibble", "dibble"))
        for (verb in c("insert", "append", "update", "patch", "upsert", "delete")) {
            values <- if (verb == "patch") c(10, NA_real_) else c(10, 20)
            x <- .s8b_frame(kind, list(k = 1:2, value = values))
            y <- switch(verb,
                insert = list(k = 3L, value = 30),
                append = list(k = 3L, value = 30),
                update = list(k = 2L, value = 99),
                patch = list(k = 2L, value = 99),
                upsert = list(k = 2:3, value = c(99, 30)),
                delete = list(k = 2L))
            expected_keys <- switch(verb, insert = 1:3, append = 1:3,
                update = 1:2, patch = 1:2, upsert = 1:3, delete = 1L)
            .s8b_observe(paste("B03", kind, verb, sep = "/"),
                list(x, .s8b_frame(kind, y)),
                .s8b_operation("dplyr", paste0("rows_", verb)),
                if (verb == "append") list() else list(by = "k"),
                expectation = list(source_policy_keys = expected_keys,
                    scope = "Comparison aid only; not asserted as a green observation"))
        }
})

test_that("B04 directional casting and matching are observed", {
    on.exit(.s8b_finish_block("B04", 18L))
    for (kind in c("frame", "tibble", "dibble"))
        for (case in c("append_wide", "update_wide", "common_key_match",
                      "fractional_key_ignore", "upsert_wide_key", "append_wide_string")) {
            x <- .s8b_frame(kind, list(k = dta_byte(1:2), value = dta_byte(c(10, 20))))
            y <- switch(case,
                append_wide = list(k = 3L, value = 200),
                update_wide = list(k = 2L, value = 200),
                common_key_match = list(k = 2, value = 99),
                fractional_key_ignore = list(k = 1.5, value = 99),
                upsert_wide_key = list(k = 300, value = 99),
                append_wide_string = list(k = 3L, value = "wider"))
            if (case == "append_wide_string")
                x <- .s8b_frame(kind, list(k = dta_byte(1:2), value = dta_string(c("a", "b"), "str1")))
            verb <- if (startsWith(case, "append")) "append" else
                if (case == "upsert_wide_key") "upsert" else "update"
            args <- if (verb == "append") list() else list(by = "k")
            if (case == "fractional_key_ignore") args$unmatched <- "ignore"
            .s8b_observe(paste("B04", kind, case, sep = "/"),
                list(x, .s8b_frame(kind, y)),
                .s8b_operation("dplyr", paste0("rows_", verb)), args)
        }
})

test_that("B05 key conflict duplicate unmatched and default policies are observed", {
    on.exit(.s8b_finish_block("B05", 24L))
    for (kind in c("frame", "tibble", "dibble"))
        for (case in c("insert_conflict_error", "insert_conflict_ignore",
                      "update_duplicate_y", "update_duplicate_x",
                      "update_unmatched_error", "update_unmatched_ignore",
                      "delete_extra_column", "default_by")) {
            x <- .s8b_frame(kind, list(k = if (case == "update_duplicate_x") c(1L, 1L) else 1:2,
                value = c(10, 20)))
            y <- if (case == "update_duplicate_y") list(k = c(1L, 1L), value = c(40, 50)) else
                if (startsWith(case, "update_unmatched")) list(k = 3L, value = 99) else
                    list(k = 1L, value = 99)
            verb <- if (startsWith(case, "insert")) "insert" else
                if (case == "delete_extra_column") "delete" else "update"
            args <- if (case == "default_by") list() else list(by = "k")
            if (case == "insert_conflict_ignore") args$conflict <- "ignore"
            if (case == "update_unmatched_ignore") args$unmatched <- "ignore"
            .s8b_observe(paste("B05", kind, case, sep = "/"),
                list(x, .s8b_frame(kind, y)),
                .s8b_operation("dplyr", paste0("rows_", verb)), args)
        }
})

test_that("B06 column modification recycling deletion and errors are observed", {
    on.exit(.s8b_finish_block("B06", 9L))
    for (kind in c("frame", "tibble", "dibble"))
        for (case in c("scalar", "delete", "wrong_size")) {
            cols <- switch(case, scalar = list(value = 7L, added = "x"),
                delete = list(value = NULL), wrong_size = list(value = 1:3))
            .s8b_observe(paste("B06", kind, case, sep = "/"),
                list(.s8b_frame(kind, .s8b_columns()), cols), .s8b_operation("dplyr", "dplyr_col_modify"))
        }
})
