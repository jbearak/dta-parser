# Source-only selected shared builder with an opt-in regroup condition.
# Existing callers retain FALSE; only direct grouped column modification opts in.
.build_group_metadata <- function(columns, keys, row_count,
                                   drop = TRUE, rowwise = FALSE, signal_regroup = FALSE) {
    key_frame <- .group_key_frame(columns, keys, row_count)
    if (rowwise) {
        key_frame$.rows <- vctrs::new_list_of(as.list(seq_len(row_count)),
                                             ptype = integer())
        return(key_frame)
    }
    if (!length(keys)) return(NULL)
    located <- vctrs::vec_locate_sorted_groups(key_frame, nan_distinct = TRUE)
    legacy_locale <- getOption("dplyr.legacy_locale")
    if (!is.null(legacy_locale)) {
        if (!is.logical(legacy_locale) || length(legacy_locale) != 1L || is.na(legacy_locale)) {
            rlang::abort("Global option `dplyr.legacy_locale` must be a single `TRUE` or `FALSE`.")
        }
        if (legacy_locale) located <- vctrs::vec_slice(
            located, .group_order_legacy(located$key))
    }
    if (signal_regroup) rlang::signal("", class = "dplyr_regroup")
    groups <- tibble::new_tibble(as.list(located$key), nrow = nrow(located$key))
    groups$.rows <- vctrs::new_list_of(located$loc, ptype = integer())
    if (!isTRUE(drop) && any(vapply(groups[keys], is.factor, logical(1)))) {
        groups <- .expand_group_metadata(groups, keys)
    }
    attr(groups, ".drop") <- drop
    groups
}
