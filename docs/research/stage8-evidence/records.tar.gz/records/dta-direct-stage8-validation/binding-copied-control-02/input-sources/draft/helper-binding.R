# Newly authored Stage8 binding fixtures and observation bookkeeping.
.s8b_frame <- function(kind, columns) {
    switch(kind,
        frame = .s8_frame("frame", columns),
        tibble = .s8_frame("tibble", columns),
        dibble = .s8_frame("dibble", columns),
        reference = {
            frame <- reserve_columns(.s8_frame("frame", columns))
            # Existing installed fixture seam: mark a fresh ordinary physical
            # frame without generating/replacing a payload column.
            frame <- dtatools:::.mark_reference_data(frame,
                dtatools:::.new_reference_state(frame, dibble = FALSE))
            stopifnot(inherits(frame, "dtatools_ref_data"), !is_dibble(frame),
                dtatools:::.reference_state_valid(frame))
            frame
        },
        grouped = dplyr::group_by(.s8_frame("tibble", columns), k, .drop = FALSE),
        rowwise = dplyr::rowwise(.s8_frame("tibble", columns), k),
        stop("Unknown fixture kind"))
}
.s8b_columns <- function(offset = 0L) {
    value <- c(10, 20) + offset
    attr(value, "label") <- "binding value"
    list(k = c(1L, 2L) + offset, value = value)
}
.s8b_snapshot <- function(inputs) {
    conditions <- list()
    failed <- FALSE
    value <- tryCatch(withCallingHandlers(lapply(inputs, .s8_semantic),
        warning = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleWarning")
        }, message = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleMessage")
        }), error = function(cnd) { failed <<- TRUE; cnd })
    list(status = if (failed) "error" else "complete", conditions = conditions,
         error = if (failed) .s8_condition(value) else NULL,
         value = if (failed) NULL else value)
}
.s8b_observe <- function(id, inputs, operation, arguments = list(), expectation = NULL) {
    # The fixture expressions are evaluated anew by each caller. No invocation
    # reuses a previous result or previous input container.
    before <- .s8b_snapshot(inputs)
    .s8b_route$last <- NULL
    result <- .s8_record(id, do.call(operation, c(inputs, arguments)))
    # Public outcome and result snapshot are already saved by .s8_record().
    record <- .s8_records$values[[id]]
    record$inputs_before <- before
    record$expectation <- expectation
    record$selected_route <- .s8b_route$last
    record$inputs_after <- list(status = "pending")
    .s8_records$values[[id]] <- record
    record$inputs_after <- .s8b_snapshot(inputs)
    .s8_records$values[[id]] <- record
    invisible(NULL)
}
.s8b_finish_block <- function(prefix, expected) {
    # Save available results before checking completeness or record membership.
    .s8_flush()
    ids <- names(.s8_records$values)
    ids <- ids[startsWith(ids, paste0(prefix, "/"))]
    expect_identical(length(ids), expected)
    for (id in ids) {
        value <- .s8_records$values[[id]]
        expect_identical(value$inputs_before$status, "complete", info = id)
        expect_identical(value$inputs_after$status, "complete", info = id)
    }
}
