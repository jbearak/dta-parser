test_that("B07 copied entry outcomes retain the observed predecessor contract", {
    .s8_flush()
    before <- readRDS(file.path(get("draft", .GlobalEnv), "predecessor-observations.rds"))
    actual <- .s8_records$values
    expect_setequal(names(actual), names(before))
    used <- character()
    for (id in names(before)) {
        now <- actual[[id]]; previous <- before[[id]]
        expect_identical(now$status, previous$status, info = id)
        expect_identical(now$snapshot_status, previous$snapshot_status, info = id)
        if (previous$status == "return") expect_identical(now$value, previous$value, info = id) else
            expect_identical(now$error$classes, previous$error$classes, info = id)
        expect_identical(lapply(now$conditions, `[[`, "classes"),
                         lapply(previous$conditions, `[[`, "classes"), info = id)
        expect_identical(now$inputs_after$value, now$inputs_before$value, info = id)
        if (isTRUE(now$selected_route$direct)) used <- c(used, now$selected_route$name)
    }
    expect_setequal(unique(used), c("rbind", "cbind", "rows_insert", "rows_append",
        "rows_update", "rows_patch", "rows_upsert", "rows_delete", "dplyr_col_modify"))
})
