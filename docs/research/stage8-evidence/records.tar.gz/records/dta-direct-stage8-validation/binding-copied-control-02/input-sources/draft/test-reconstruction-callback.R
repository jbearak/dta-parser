test_that("B10 inherited column modification invokes custom reconstruction", {
    method_name <- "dplyr_reconstruct.stage8_column_reconstruction"
    if (exists(method_name, .GlobalEnv, inherits = FALSE)) stop("Diagnostic method name already exists")
    events <- new.env(parent = emptyenv()); events$values <- character()
    assign(method_name, function(data, template) {
        mode <- attr(template, "stage8_mode", exact = TRUE)
        events$values <- c(events$values, paste0("reconstruct:", mode))
        if (mode == "error") stop("Stage8 reconstruction sentinel", call. = FALSE)
        if (mode == "warning") warning("Stage8 reconstruction warning", call. = FALSE)
        data$value <- data$value + 100
        attr(data, "label") <- "custom reconstruction"
        data
    }, envir = .GlobalEnv)
    on.exit(rm(list = method_name, envir = .GlobalEnv), add = TRUE)
    observed <- list()
    on.exit({
        directory <- get("out", .GlobalEnv)
        saveRDS(observed, file.path(directory, "reconstruction-callback.rds"))
        dput(observed, file.path(directory, "reconstruction-callback.R"))
    }, add = TRUE)
    store <- new.env(parent = environment(.s8_record))
    store$.s8_records <- new.env(parent = emptyenv()); store$.s8_records$values <- list()
    record <- .s8_record; environment(record) <- store
    for (mode in c("transform", "warning", "error")) {
        pair <- list()
        for (route in c("public", "copied")) {
            # Public conversion intentionally strips unsupported subclasses.
            # The diagnostic starts with normalized fresh owned columns and
            # applies a new valid private marker after setting the test class.
            x <- dtatools:::.reference_snapshot(dibble(k = 1:2, value = c(10, 20)))
            class(x) <- c("stage8_column_reconstruction", "data.frame")
            attr(x, "stage8_mode") <- mode
            x <- dtatools:::.mark_reference_data(x,
                dtatools:::.new_reference_state(x, dibble = TRUE))
            expect_true(is_dibble(x))
            expect_true(dtatools:::.reference_state_valid(x))
            expect_identical(class(dtatools:::.reference_snapshot(x)),
                c("stage8_column_reconstruction", "data.frame"))
            before <- .s8b_snapshot(list(x))
            fn <- if (route == "public") dplyr::dplyr_col_modify else
                .s8b_direct$dplyr_col_modify.dtatools_ref_data
            id <- paste(mode, route, sep = "/")
            events$values <- character()
            result <- record(id, fn(x, list(value = 7L)))
            saved <- store$.s8_records$values[[id]]
            saved$events <- events$values
            saved$before <- before; saved$after <- list(status = "pending")
            observed[[id]] <- saved
            saved$after <- .s8b_snapshot(list(x))
            observed[[id]] <- saved
            pair[[route]] <- saved
            expect_identical(saved$events, paste0("reconstruct:", mode), info = id)
            expect_identical(saved$status, if (mode == "error") "error" else "return", info = id)
            expect_identical(before$status, "complete", info = id)
            expect_identical(saved$snapshot_status,
                if (saved$status == "return") "complete" else "not_applicable", info = id)
            expect_identical(saved$after$status, "complete", info = id)
            expect_identical(saved$after$value, before$value, info = id)
        }
        expect_identical(pair$copied$value, pair$public$value)
        expect_identical(pair$copied$error$classes, pair$public$error$classes)
        expect_identical(pair$copied$error$message, pair$public$error$message)
        expect_identical(lapply(pair$copied$conditions, function(x) x[c("classes", "message")]),
                         lapply(pair$public$conditions, function(x) x[c("classes", "message")]))
    }
})
