# Copied entry calls only. Installed S3 registration and namespace stay intact.
.s8b_direct <- new.env(parent = asNamespace("dtatools"))
for (.s8b_file in c("dibble-join-plan.R", "group-builder-control.R",
    "dibble-column-modify.R", "dibble-rows-mutate.R",
    "dibble-base-bind-construction.R", "dibble-base-bind.R")) {
    sys.source(file.path(get("draft", .GlobalEnv), .s8b_file), envir = .s8b_direct)
}
.s8b_route <- new.env(parent = emptyenv())
.s8b_route$last <- NULL
.s8b_operation <- function(namespace, name) {
    public <- getExportedValue(namespace, name)
    method_name <- paste0(name, ".dtatools_ref_data")
    direct <- if (exists(method_name, envir = .s8b_direct, inherits = FALSE))
        get(method_name, envir = .s8b_direct, inherits = FALSE) else NULL
    function(...) {
        arguments <- list(...)
        selected <- !is.null(direct) && length(arguments) > 0L && is_dibble(arguments[[1L]])
        .s8b_route$last <- list(namespace = namespace, name = name, direct = selected)
        do.call(if (selected) direct else public, arguments, envir = parent.frame())
    }
}
