list(`plain/value/public` = list(id = "plain/value/public", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:3, 
            label = "column modification source", class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "integer", attributes = list(
            levels = c("a", "b", "c"), class = "factor"), values = c(1L, 
        1L, 2L)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(7, 
        7, 7)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `plain/value/copied` = list(
    id = "plain/value/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, label = "column modification source", 
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
        attributes = list(levels = c("a", "b", "c"), class = "factor"), 
        values = c(1L, 1L, 2L)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(7, 
        7, 7)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `plain/key/public` = list(
    id = "plain/key/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
        columns = list(k = list(kind = "integer", attributes = list(
            levels = c("a", "b", "c"), class = "factor"), values = c(2L, 
        1L, 1L)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `plain/key/copied` = list(
    id = "plain/key/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
        columns = list(k = list(kind = "integer", attributes = list(
            levels = c("a", "b", "c"), class = "factor"), values = c(2L, 
        1L, 1L)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `plain/delete_key/public` = list(
    id = "plain/delete_key/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = "value", 
        row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
        columns = list(value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `plain/delete_key/copied` = list(
    id = "plain/delete_key/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = "value", 
        row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
        columns = list(value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `plain/wrong_size/public` = list(
    id = "plain/wrong_size/public", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = "dplyr::dplyr_col_modify(.reference_snapshot(data), cols)", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))), `plain/wrong_size/copied` = list(
    id = "plain/wrong_size/copied", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = ".dibble_col_modify(data, cols)", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame"), label = "column modification source"), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))), `grouped/value/public` = list(
    id = "grouped/value/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(groups = structure(list(
        k = structure(1:3, levels = c("a", "b", "c"), class = "factor"), 
        .rows = structure(list(1:2, 3L, integer(0)), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
    -3L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
        names = c("k", "value"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", "data.frame"
        )), columns = list(k = list(kind = "integer", attributes = list(
        levels = c("a", "b", "c"), class = "factor"), values = c(1L, 
    1L, 2L)), value = list(kind = "double", attributes = list(
        stata.storage = "double", class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double")), values = c(7, 7, 7)))), events = "dplyr_regroup", 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `grouped/value/copied` = list(
    id = "grouped/value/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(groups = structure(list(
        k = structure(1:3, levels = c("a", "b", "c"), class = "factor"), 
        .rows = structure(list(1:2, 3L, integer(0)), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
    -3L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
        names = c("k", "value"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", "data.frame"
        )), columns = list(k = list(kind = "integer", attributes = list(
        levels = c("a", "b", "c"), class = "factor"), values = c(1L, 
    1L, 2L)), value = list(kind = "double", attributes = list(
        stata.storage = "double", class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double")), values = c(7, 7, 7)))), events = "dplyr_regroup", 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `grouped/key/public` = list(
    id = "grouped/key/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(groups = structure(list(
        k = structure(1:3, levels = c("a", "b", "c"), class = "factor"), 
        .rows = structure(list(2:3, 1L, integer(0)), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
    -3L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
        names = c("k", "value"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", "data.frame"
        )), columns = list(k = list(kind = "integer", attributes = list(
        levels = c("a", "b", "c"), class = "factor"), values = c(2L, 
    1L, 1L)), value = list(kind = "double", attributes = list(
        stata.storage = "double", class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double")), values = c(10, 20, 30)))), 
    events = "dplyr_regroup", before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(1:3, levels = c("a", 
                "b", "c"), class = "factor"), .rows = structure(list(
                  1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
                ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE)), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(1:3, levels = c("a", 
                "b", "c"), class = "factor"), .rows = structure(list(
                  1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
                ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE)), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `grouped/key/copied` = list(
    id = "grouped/key/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "grouped_df", "tbl_df", "tbl", "data.frame"), groups = structure(list(
        k = structure(1:3, levels = c("a", "b", "c"), class = "factor"), 
        .rows = structure(list(2:3, 1L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
    "tbl", "data.frame"), .drop = FALSE)), columns = list(k = list(
        kind = "integer", attributes = list(levels = c("a", "b", 
        "c"), class = "factor"), values = c(2L, 1L, 1L)), value = list(
        kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 30)))), events = "dplyr_regroup", 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(1:3, levels = c("a", 
                "b", "c"), class = "factor"), .rows = structure(list(
                  1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
                ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE)), 
            columns = list(k = list(kind = "integer", attributes = list(
                levels = c("a", "b", "c"), class = "factor"), 
                values = c(1L, 1L, 2L)), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `grouped/delete_key/public` = list(
    id = "grouped/delete_key/public", status = "error", conditions = list(), 
    error = list(classes = c("rlang_error", "error", "condition"
    ), message = "`vars` missing from `data`: `k`.", call = "compute_groups(data, vars, drop = drop)", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `grouped/delete_key/copied` = list(
    id = "grouped/delete_key/copied", status = "error", conditions = list(), 
    error = list(classes = c("rlang_error", "error", "condition"
    ), message = "`vars` missing from `data`: `k`.", call = ".dibble_col_modify(data, cols)", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `grouped/wrong_size/public` = list(
    id = "grouped/wrong_size/public", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = "dplyr_col_modify(as_tibble(data), cols)", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))), `grouped/wrong_size/copied` = list(
    id = "grouped/wrong_size/copied", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = ".dibble_col_modify(data, cols)", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(1:3, levels = c("a", 
            "b", "c"), class = "factor"), .rows = structure(list(
                1:2, 3L, integer(0)), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE)), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))), `rowwise/value/public` = list(
    id = "rowwise/value/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(groups = structure(list(
        k = structure(c(1L, 1L, 2L), levels = c("a", "b", "c"
        ), class = "factor"), .rows = structure(list(1L, 2L, 
            3L), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
    "tbl", "data.frame")), names = c("k", "value"), row.names = 1:3, 
        class = c("dibble", "dtatools_ref_data", "rowwise_df", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "integer", attributes = list(levels = c("a", "b", 
        "c"), class = "factor"), values = c(1L, 1L, 2L)), value = list(
        kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(7, 7, 7)))), events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `rowwise/value/copied` = list(
    id = "rowwise/value/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, groups = structure(list(k = structure(c(1L, 
    1L, 2L), levels = c("a", "b", "c"), class = "factor"), .rows = structure(list(
        1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
    "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
    "tbl", "data.frame")), class = c("dibble", "dtatools_ref_data", 
    "rowwise_df", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "integer", attributes = list(levels = c("a", 
        "b", "c"), class = "factor"), values = c(1L, 1L, 2L)), 
        value = list(kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(7, 7, 7)))), events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 7L)))))), `rowwise/key/public` = list(
    id = "rowwise/key/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(groups = structure(list(
        k = structure(c(2L, 1L, 1L), levels = c("a", "b", "c"
        ), class = "factor"), .rows = structure(list(1L, 2L, 
            3L), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
    "tbl", "data.frame")), names = c("k", "value"), row.names = 1:3, 
        class = c("dibble", "dtatools_ref_data", "rowwise_df", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "integer", attributes = list(levels = c("a", "b", 
        "c"), class = "factor"), values = c(2L, 1L, 1L)), value = list(
        kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 30)))), events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(c(1L, 1L, 
                2L), levels = c("a", "b", "c"), class = "factor"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(k = list(kind = "integer", 
                attributes = list(levels = c("a", "b", "c"), 
                  class = "factor"), values = c(1L, 1L, 2L)), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `rowwise/key/copied` = list(
    id = "rowwise/key/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "rowwise_df", "tbl_df", "tbl", "data.frame"), groups = structure(list(
        k = structure(c(2L, 1L, 1L), levels = c("a", "b", "c"
        ), class = "factor"), .rows = structure(list(1L, 2L, 
            3L), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
    "tbl", "data.frame"))), columns = list(k = list(kind = "integer", 
        attributes = list(levels = c("a", "b", "c"), class = "factor"), 
        values = c(2L, 1L, 1L)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = character(0), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(c(1L, 1L, 
                2L), levels = c("a", "b", "c"), class = "factor"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(k = list(kind = "integer", 
                attributes = list(levels = c("a", "b", "c"), 
                  class = "factor"), values = c(1L, 1L, 2L)), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
                groups = structure(list(k = structure(c(1L, 1L, 
                2L), levels = c("a", "b", "c"), class = "factor"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(k = list(kind = "integer", 
                attributes = list(levels = c("a", "b", "c"), 
                  class = "factor"), values = c(1L, 1L, 2L)), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "integer", 
            attributes = list(levels = c("a", "b", "c"), class = "factor"), 
            values = c(2L, 1L, 1L))))))), `rowwise/delete_key/public` = list(
    id = "rowwise/delete_key/public", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_subscript_oob", "vctrs_error_subscript", 
    "rlang_error", "error", "condition"), message = "Can't subset columns that don't exist.\nx Column `k` doesn't exist.", 
        call = "as_tibble(data)[group_vars]", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `rowwise/delete_key/copied` = list(
    id = "rowwise/delete_key/copied", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_subscript_oob", "vctrs_error_subscript", 
    "rlang_error", "error", "condition"), message = "Can't subset columns that don't exist.\nx Column `k` doesn't exist.", 
        call = "tibble::as_tibble(result)[keys]", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "k"), values = list(k = list(kind = "NULL", 
            attributes = NULL, values = NULL)))))), `rowwise/wrong_size/public` = list(
    id = "rowwise/wrong_size/public", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = "dplyr_col_modify(as_tibble(data), cols)", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))), `rowwise/wrong_size/copied` = list(
    id = "rowwise/wrong_size/copied", status = "error", conditions = list(), 
    error = list(classes = c("vctrs_error_incompatible_size", 
    "vctrs_error_recycle_incompatible_size", "vctrs_error", "rlang_error", 
    "error", "condition"), message = "Can't recycle `value` (size 2) to size 3.", 
        call = ".dibble_col_modify(data, cols)", parent = NULL), 
    snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = character(0), 
    before = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2))))), after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "rowwise_df", "tbl_df", "tbl", "data.frame"), label = "column modification source", 
            groups = structure(list(k = structure(c(1L, 1L, 2L
            ), levels = c("a", "b", "c"), class = "factor"), 
                .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -3L
            ), class = c("tbl_df", "tbl", "data.frame"))), columns = list(
            k = list(kind = "integer", attributes = list(levels = c("a", 
            "b", "c"), class = "factor"), values = c(1L, 1L, 
            2L)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 30)))), list(kind = "list", attributes = list(
            names = "value"), values = list(value = list(kind = "integer", 
            attributes = NULL, values = 1:2)))))))
