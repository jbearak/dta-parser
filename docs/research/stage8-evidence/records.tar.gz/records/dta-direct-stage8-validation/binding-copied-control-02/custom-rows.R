list(`update/events/public` = list(id = "update/events/public", 
    status = "return", conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:2, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(30, 
        40)))), events = c("events:1", "events:2"), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("stage8_rows_selection", "data.frame"
        ), row.names = 1:2, stage8_mode = "events"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(30, 40)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, NA)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("stage8_rows_selection", 
            "data.frame"), row.names = 1:2, stage8_mode = "events"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = NULL, values = c(30, 40))))))))
