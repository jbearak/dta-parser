list(selector = list(kind = "selector", warm_calls = 25L, measured_calls = 100L, 
    before_heap = c(Ncells = 655323, Vcells = 1154671), after_heap = c(Ncells = 655327, 
    Vcells = 1154675), before_physical = list(source = list(table_address = "0x80b3f4000", 
        names_address = "0x80af70000", v1_address = "0x80f1a7a80", 
        copy_address = NULL, column_capacity = 5008, column_count = 8L), 
        first = list(table_address = "0x80a40c000", names_address = "0x80a418000", 
            v1_address = "0x8104069a8", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), latest = list(
            table_address = "0x80a484000", names_address = "0x80a490000", 
            v1_address = "0x8108a1bd0", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L)), after_physical = list(
        source = list(table_address = "0x80b3f4000", names_address = "0x80af70000", 
            v1_address = "0x80f1a7a80", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0x80a40c000", names_address = "0x80a418000", 
            v1_address = "0x8104069a8", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), latest = list(
            table_address = "0x80a9ec000", names_address = "0x80a9f8000", 
            v1_address = "0x810c3d348", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L)), ncells = 4, 
    vector_bytes = 32, rows = 64L, columns = c("v1", "v2", "v3", 
    "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/candidate-8ffa5ac5-01/library/dtatools"), 
    duplicate = list(kind = "duplicate", warm_calls = 25L, measured_calls = 100L, 
        before_heap = c(Ncells = 655325, Vcells = 1154677), after_heap = c(Ncells = 655329, 
        Vcells = 1154681), before_physical = list(source = list(
            table_address = "0x9f87c8000", names_address = "0x9f87d4000", 
            v1_address = "0x9faee7a80", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0x9f7270000", names_address = "0x9f727c000", 
            v1_address = "0x9fc38ef20", copy_address = "0x9fc38ef20", 
            column_capacity = 5009, column_count = 9L), latest = list(
            table_address = "0x9f72e8000", names_address = "0x9f72f4000", 
            v1_address = "0x9fc7ac970", copy_address = "0x9fc7ac970", 
            column_capacity = 5009, column_count = 9L)), after_physical = list(
            source = list(table_address = "0x9f87c8000", names_address = "0x9f87d4000", 
                v1_address = "0x9faee7a80", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), first = list(
                table_address = "0x9f7270000", names_address = "0x9f727c000", 
                v1_address = "0x9fc38ef20", copy_address = "0x9fc38ef20", 
                column_capacity = 5009, column_count = 9L), latest = list(
                table_address = "0x9f7108000", names_address = "0x9f7114000", 
                v1_address = "0x9fceab0e0", copy_address = "0x9fceab0e0", 
                column_capacity = 5009, column_count = 9L)), 
        ncells = 4, vector_bytes = 32, rows = 64L, columns = c("v1", 
        "v2", "v3", "v4", "v5", "v6", "v7", "v8", "copy"), namespace_path = "/private/tmp/dta-direct-stage8-validation/candidate-8ffa5ac5-01/library/dtatools"), 
    constructor = list(kind = "constructor", warm_calls = 25L, 
        measured_calls = 100L, before_heap = c(Ncells = 597621, 
        Vcells = 1061825), after_heap = c(Ncells = 597625, Vcells = 1061829
        ), before_physical = list(source = list(table_address = "0x95e7c8000", 
            names_address = "0x95e7d4000", v1_address = "0x960ee7af0", 
            copy_address = NULL, column_capacity = 5008, column_count = 8L), 
            first = list(table_address = "0x95daac000", names_address = "0x95dab8000", 
                v1_address = "0x962f4eac0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), latest = list(
                table_address = "0x95dac4000", names_address = "0x95dad0000", 
                v1_address = "0x9630110e0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L)), 
        after_physical = list(source = list(table_address = "0x95e7c8000", 
            names_address = "0x95e7d4000", v1_address = "0x960ee7af0", 
            copy_address = NULL, column_capacity = 5008, column_count = 8L), 
            first = list(table_address = "0x95daac000", names_address = "0x95dab8000", 
                v1_address = "0x962f4eac0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), latest = list(
                table_address = "0x95d108000", names_address = "0x95d114000", 
                v1_address = "0x963b94740", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L)), 
        ncells = 4, vector_bytes = 32, rows = 64L, columns = c("v1", 
        "v2", "v3", "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/candidate-8ffa5ac5-01/library/dtatools"), 
    reserve = list(kind = "reserve", warm_calls = 25L, measured_calls = 100L, 
        before_heap = c(Ncells = 598509, Vcells = 1042858), after_heap = c(Ncells = 598513, 
        Vcells = 1042862), before_physical = list(source = list(
            table_address = "0xbfe7c8000", names_address = "0xbfe7d4000", 
            v1_address = "0xc00da7af0", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0xc0029c180", names_address = "0xc0029c480", 
            v1_address = "0xc02130bd8", copy_address = NULL, 
            column_capacity = 40, column_count = 8L), latest = list(
            table_address = "0xc0029d800", names_address = "0xc0029e100", 
            v1_address = "0xc0216c900", copy_address = NULL, 
            column_capacity = 40, column_count = 8L)), after_physical = list(
            source = list(table_address = "0xbfe7c8000", names_address = "0xbfe7d4000", 
                v1_address = "0xc00da7af0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), first = list(
                table_address = "0xc0029c180", names_address = "0xc0029c480", 
                v1_address = "0xc02130bd8", copy_address = NULL, 
                column_capacity = 40, column_count = 8L), latest = list(
                table_address = "0xc00ba1380", names_address = "0xc00ba1500", 
                v1_address = "0xc02d7ee40", copy_address = NULL, 
                column_capacity = 40, column_count = 8L)), ncells = 4, 
        vector_bytes = 32, rows = 64L, columns = c("v1", "v2", 
        "v3", "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/candidate-8ffa5ac5-01/library/dtatools"))
