# Diagnostic H01 alignment only. Original production draft and failed runs remain.
# Keep 25 total warm calls, 100 measured calls and both original budgets.
test_that("H01 selector construction and reserve do not retain address history", {
    skip_if_not_installed("callr")
    records <- list()
    save_records <- function() {
        directory <- get("out", envir = .GlobalEnv)
        saveRDS(records, file.path(directory, "history-alignment.rds"))
        dput(records, file.path(directory, "history-alignment.R"))
    }
    on.exit(save_records(), add = TRUE)
    for (kind in c("selector", "duplicate", "constructor", "reserve")) {
        observed <- callr::r(function(libraries, kind) {
            .libPaths(libraries)
            library(dtatools)
            rows <- 64L
            column_names <- paste0("v", seq_len(8L))
            fresh <- function() {
                columns <- lapply(seq_len(8L), function(i) as.double(seq_len(rows)) + i)
                names(columns) <- column_names
                tibble::new_tibble(columns, nrow = rows)
            }
            pipeline <- function(x) {
                x <- dplyr::rename(x, renamed = v1)
                selected <- c("renamed", column_names[-1L])
                if (kind == "duplicate") {
                    x <- dplyr::select(x, tidyselect::all_of(c(stats::setNames(selected, selected), copy = "renamed")))
                    x <- dplyr::relocate(x, copy, .before = renamed)
                } else {
                    x <- dplyr::select(x, tidyselect::all_of(selected))
                    x <- dplyr::relocate(x, v8, .before = renamed)
                }
                x <- dplyr::rename(x, v1 = renamed)
                if (kind == "duplicate") dplyr::relocate(x, copy, .after = v8)
                else dplyr::relocate(x, v8, .after = v7)
            }
            operation <- switch(kind, selector = pipeline, duplicate = pipeline,
                constructor = function(x) as_dibble(fresh()),
                reserve = function(x) reserve_columns(x, n = 32L))
            heap <- function() { invisible(gc(full = TRUE)); gc(full = TRUE)[, "used"] }
            physical <- function(source, first, latest) {
                lapply(list(source = source, first = first, latest = latest), function(data) {
                    list(table_address = rlang::obj_address(data),
                        names_address = rlang::obj_address(names(data)),
                        v1_address = rlang::obj_address(.subset2(data, match("v1", names(data)))),
                        copy_address = if ("copy" %in% names(data))
                            rlang::obj_address(.subset2(data, match("copy", names(data)))) else NULL,
                        column_capacity = column_capacity(data), column_count = length(data))
                })
            }
            source <- as_dibble(fresh())
            latest <- source
            for (i in seq_len(24L)) latest <- operation(latest)
            first <- latest
            latest <- operation(latest) # First is call 24; latest is call 25.
            before_physical <- physical(source, first, latest)
            before <- heap()
            for (i in seq_len(100L)) latest <- operation(latest)
            after <- heap()
            after_physical <- physical(source, first, latest)
            # Check values after the measured heap checkpoints, with both
            # source and earlier output still live throughout the sequence.
            expected_names <- c(column_names, if (kind == "duplicate") "copy")
            stopifnot(identical(names(latest), expected_names))
            for (value in list(source, first, latest)) {
                for (j in seq_len(8L)) stopifnot(identical(as.double(value[[column_names[[j]]]]),
                    as.double(seq_len(rows)) + j))
            }
            if (kind == "duplicate") stopifnot(identical(as.double(latest$copy), as.double(latest$v1)))
            list(kind = kind, warm_calls = 25L, measured_calls = 100L,
                before_heap = before, after_heap = after,
                before_physical = before_physical, after_physical = after_physical,
                ncells = unname(after[["Ncells"]] - before[["Ncells"]]),
                vector_bytes = unname((after[["Vcells"]] - before[["Vcells"]]) * 8),
                rows = nrow(latest), columns = names(latest),
                namespace_path = getNamespaceInfo(asNamespace("dtatools"), "path"))
        }, args = list(.libPaths(), kind), libpath = .libPaths(), timeout = 120)
        records[[kind]] <- observed
        save_records() # Actual raw child facts are durable before any expectation.
        expect_identical(normalizePath(observed$namespace_path),
            normalizePath(getNamespaceInfo(asNamespace("dtatools"), "path")))
        expect_identical(observed$rows, 64L)
        # The old per-address binding names grow by thousands of Ncells in
        # this interval. These budgets allow ordinary recorder/cache residue.
        expect_lt(observed$ncells, 1000)
        expect_lt(observed$vector_bytes, 40000)
    }
})
