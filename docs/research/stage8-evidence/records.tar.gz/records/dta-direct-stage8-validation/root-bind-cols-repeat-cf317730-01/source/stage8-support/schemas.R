list(`8-left_unique` = list(x = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL)))), `16-left_unique` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "r01", "r02", 
    "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", 
    "r12", "r13", "r14", "r15", "r16")), slots = list(list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-inner_double` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-inner_double` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "r01", "r02", 
    "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", 
    "r12", "r13", "r14", "r15", "r16")), slots = list(list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-full_padded` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str3"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str3"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-full_padded` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "r01", "r02", 
    "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", 
    "r12", "r13", "r14", "r15", "r16")), slots = list(list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str3"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str3"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str3"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str3"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-left_rolling` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key.x", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "key.y", "r01", "r02", "r03", "r04", "r05", "r06", "r07", 
        "r08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), stata.storage = "long"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
            stata.storage = "double"), slots = NULL), list(type = "logical", 
            metadata = list(label = "Payload 2"), slots = NULL), 
        list(type = "integer", metadata = list(class = "factor", 
            label = "Payload 3", levels = c("a", "b", "c", "unused"
            )), slots = NULL), list(type = "integer", metadata = list(
            class = c("ordered", "factor"), label = "Payload 4", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "character", metadata = list(class = c("dta_string", 
        "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-left_rolling` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key.x", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "key.y", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-semi_half` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-semi_half` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-anti_half` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-anti_half` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-base_rbind` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "integer", 
        metadata = list(class = c("ordered", "factor"), levels = c("a", 
        "b", "c", "unused")), slots = NULL), list(type = "character", 
        metadata = list(class = c("dta_string", "vctrs_vctr", 
        "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
            stata.storage = "double"), slots = NULL)))), `16-base_rbind` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "c09", "c10", "c11", "c12", "c13", "c14", "c15", "c16"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "c09", "c10", "c11", "c12", "c13", "c14", "c15", "c16"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "integer", 
        metadata = list(class = c("ordered", "factor"), levels = c("a", 
        "b", "c", "unused")), slots = NULL), list(type = "character", 
        metadata = list(class = c("dta_string", "vctrs_vctr", 
        "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
            stata.storage = "double"), slots = NULL), list(type = "double", 
            metadata = list(class = c("dta_numeric", "dta_double", 
            "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", levels = c("a", 
            "b", "c", "unused")), slots = NULL), list(type = "integer", 
            metadata = list(class = c("ordered", "factor"), levels = c("a", 
            "b", "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL)))), `8-base_cbind` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL))), result = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), names = c("key", "c01", "c02", 
    "c03", "c04", "c05", "c06", "c07", "c08", "r01", "r02", "r03", 
    "r04", "r05", "r06", "r07", "r08")), slots = list(list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_long", 
        "vctrs_vctr", "double"), stata.storage = "long"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
            stata.storage = "double"), slots = NULL), list(type = "logical", 
            metadata = list(label = "Payload 2"), slots = NULL), 
        list(type = "integer", metadata = list(class = "factor", 
            label = "Payload 3", levels = c("a", "b", "c", "unused"
            )), slots = NULL), list(type = "integer", metadata = list(
            class = c("ordered", "factor"), label = "Payload 4", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "character", metadata = list(class = c("dta_string", 
        "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-base_cbind` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", 
    "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), names = c("key", "c01", "c02", "c03", "c04", 
    "c05", "c06", "c07", "c08", "c09", "c10", "c11", "c12", "c13", 
    "c14", "c15", "c16", "r01", "r02", "r03", "r04", "r05", "r06", 
    "r07", "r08", "r09", "r10", "r11", "r12", "r13", "r14", "r15", 
    "r16")), slots = list(list(type = "double", metadata = list(
    class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
    ), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-bind_rows_wide` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c08")), slots = list(
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str40"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = NULL, 
        slots = NULL), list(type = "integer", metadata = list(
        class = "factor", levels = c("a", "b", "c", "unused")), 
        slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
        metadata = list(class = c("dta_string", "vctrs_vctr", 
        "character"), label = "Payload 5", stata.string.storage = "str40"), 
        slots = NULL), list(type = "character", metadata = list(
        stata.string.storage = "str3"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_long", 
        "vctrs_vctr", "double"), label = "Payload 7", stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL)))), `16-bind_rows_wide` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str40"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str40"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
            stata.storage = "double"), slots = NULL))), result = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = NULL, 
        slots = NULL), list(type = "integer", metadata = list(
        class = "factor", levels = c("a", "b", "c", "unused")), 
        slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
        metadata = list(class = c("dta_string", "vctrs_vctr", 
        "character"), label = "Payload 5", stata.string.storage = "str40"), 
        slots = NULL), list(type = "character", metadata = list(
        stata.string.storage = "str3"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_long", 
        "vctrs_vctr", "double"), label = "Payload 7", stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = NULL, 
        slots = NULL), list(type = "integer", metadata = list(
        class = "factor", levels = c("a", "b", "c", "unused")), 
        slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
        metadata = list(class = c("dta_string", "vctrs_vctr", 
        "character"), label = "Payload 13", stata.string.storage = "str40"), 
        slots = NULL), list(type = "character", metadata = list(
        stata.string.storage = "str3"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_long", 
        "vctrs_vctr", "double"), label = "Payload 15", stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-bind_cols` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL))), result = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "r01", "r02", "r03", "r04", "r05", "r06", 
        "r07", "r08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-bind_cols` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", 
    "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "r01", "r02", 
    "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", 
    "r12", "r13", "r14", "r15", "r16")), slots = list(list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-rows_update` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-rows_update` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-reconstruct` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-reconstruct` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-grouped_left` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "grouped_df", "tbl_df", "tbl", "data.frame"), groups = list(
        type = "list", metadata = list(.drop = TRUE, class = c("tbl_df", 
        "tbl", "data.frame"), names = c("g", ".rows")), slots = list(
            list(type = "character", metadata = list(stata.string.storage = "str4"), 
                slots = NULL), list(type = "list", metadata = list(
                class = c("vctrs_list_of", "vctrs_vctr", "list"
                ), ptype = list(type = "integer", metadata = NULL, 
                  slots = NULL)), slots = list(list(type = "integer", 
                metadata = NULL, slots = NULL))))), label = "Stage 8 input 1", 
        names = c("g", "key", "c01", "c02", "c03", "c04", "c05", 
        "c06", "c07", "c08")), slots = list(list(type = "character", 
        metadata = list(stata.string.storage = "str4"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08")), 
    slots = list(list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "grouped_df", "tbl_df", 
    "tbl", "data.frame"), groups = list(type = "list", metadata = list(
        .drop = TRUE, class = c("tbl_df", "tbl", "data.frame"
        ), names = c("g", ".rows")), slots = list(list(type = "character", 
        metadata = list(stata.string.storage = "str4"), slots = NULL), 
        list(type = "list", metadata = list(class = c("vctrs_list_of", 
        "vctrs_vctr", "list"), ptype = list(type = "integer", 
            metadata = NULL, slots = NULL)), slots = list(list(
            type = "integer", metadata = NULL, slots = NULL))))), 
    label = "Stage 8 input 1", names = c("g", "key", "c01", "c02", 
    "c03", "c04", "c05", "c06", "c07", "c08", "r01", "r02", "r03", 
    "r04", "r05", "r06", "r07", "r08")), slots = list(list(type = "character", 
    metadata = list(stata.string.storage = "str4"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL)))), `16-grouped_left` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "grouped_df", "tbl_df", "tbl", "data.frame"), groups = list(
        type = "list", metadata = list(.drop = TRUE, class = c("tbl_df", 
        "tbl", "data.frame"), names = c("g", ".rows")), slots = list(
            list(type = "character", metadata = list(stata.string.storage = "str4"), 
                slots = NULL), list(type = "list", metadata = list(
                class = c("vctrs_list_of", "vctrs_vctr", "list"
                ), ptype = list(type = "integer", metadata = NULL, 
                  slots = NULL)), slots = list(list(type = "integer", 
                metadata = NULL, slots = NULL))))), label = "Stage 8 input 1", 
        names = c("g", "key", "c01", "c02", "c03", "c04", "c05", 
        "c06", "c07", "c08", "c09", "c10", "c11", "c12", "c13", 
        "c14", "c15", "c16")), slots = list(list(type = "character", 
        metadata = list(stata.string.storage = "str4"), slots = NULL), 
        list(type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("key", 
    "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", 
    "r10", "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "grouped_df", "tbl_df", 
    "tbl", "data.frame"), groups = list(type = "list", metadata = list(
        .drop = TRUE, class = c("tbl_df", "tbl", "data.frame"
        ), names = c("g", ".rows")), slots = list(list(type = "character", 
        metadata = list(stata.string.storage = "str4"), slots = NULL), 
        list(type = "list", metadata = list(class = c("vctrs_list_of", 
        "vctrs_vctr", "list"), ptype = list(type = "integer", 
            metadata = NULL, slots = NULL)), slots = list(list(
            type = "integer", metadata = NULL, slots = NULL))))), 
    label = "Stage 8 input 1", names = c("g", "key", "c01", "c02", 
    "c03", "c04", "c05", "c06", "c07", "c08", "c09", "c10", "c11", 
    "c12", "c13", "c14", "c15", "c16", "r01", "r02", "r03", "r04", 
    "r05", "r06", "r07", "r08", "r09", "r10", "r11", "r12", "r13", 
    "r14", "r15", "r16")), slots = list(list(type = "character", 
    metadata = list(stata.string.storage = "str4"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_long", "vctrs_vctr", "double"), stata.storage = "long"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 4", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 5", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 6", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 7", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_double", "vctrs_vctr", 
        "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL)))), `8-cross_four` = list(x = list(type = "list", 
    metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL))), result = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "r01", "r02", "r03", "r04", "r05", "r06", 
        "r07", "r08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 1", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 2"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 3", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL)))), `16-cross_four` = list(x = list(
    type = "list", metadata = list(class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 2", names = c("r01", 
    "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", 
    "r11", "r12", "r13", "r14", "r15", "r16")), slots = list(
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
        stata.storage = "double"), slots = NULL), list(type = "logical", 
        metadata = list(label = "Payload 2"), slots = NULL), 
    list(type = "integer", metadata = list(class = "factor", 
        label = "Payload 3", levels = c("a", "b", "c", "unused"
        )), slots = NULL), list(type = "integer", metadata = list(
        class = c("ordered", "factor"), label = "Payload 4", 
        levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "character", metadata = list(class = c("dta_string", 
    "vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
        slots = NULL), list(type = "character", metadata = list(
        label = "Payload 6", stata.string.storage = "str12"), 
        slots = NULL), list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), label = "Payload 7", stata.storage = "long"), slots = NULL), 
    list(type = "double", metadata = list(class = c("dta_numeric", 
    "dta_double", "vctrs_vctr", "double"), label = "Payload 8", 
        stata.storage = "double"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 10"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 11", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
    list(type = "integer", metadata = list(class = c("ordered", 
    "factor"), label = "Payload 12", levels = c("a", "b", "c", 
    "unused")), slots = NULL), list(type = "character", metadata = list(
        class = c("dta_string", "vctrs_vctr", "character"), label = "Payload 13", 
        stata.string.storage = "str12"), slots = NULL), list(
        type = "character", metadata = list(label = "Payload 14", 
            stata.string.storage = "str12"), slots = NULL), list(
        type = "double", metadata = list(class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double"), label = "Payload 15", 
            stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 16", stata.storage = "double"), 
        slots = NULL))), result = list(type = "list", metadata = list(
    class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
    "data.frame"), label = "Stage 8 input 1", names = c("key", 
    "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", "c09", 
    "c10", "c11", "c12", "c13", "c14", "c15", "c16", "r01", "r02", 
    "r03", "r04", "r05", "r06", "r07", "r08", "r09", "r10", "r11", 
    "r12", "r13", "r14", "r15", "r16")), slots = list(list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), stata.storage = "long"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_double", "vctrs_vctr", 
    "double"), label = "Payload 1", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 2"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 3", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 4", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 5", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 6", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 7", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 8", stata.storage = "double"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 9", stata.storage = "double"), 
    slots = NULL), list(type = "logical", metadata = list(label = "Payload 10"), 
    slots = NULL), list(type = "integer", metadata = list(class = "factor", 
    label = "Payload 11", levels = c("a", "b", "c", "unused")), 
    slots = NULL), list(type = "integer", metadata = list(class = c("ordered", 
"factor"), label = "Payload 12", levels = c("a", "b", "c", "unused"
)), slots = NULL), list(type = "character", metadata = list(class = c("dta_string", 
"vctrs_vctr", "character"), label = "Payload 13", stata.string.storage = "str12"), 
    slots = NULL), list(type = "character", metadata = list(label = "Payload 14", 
    stata.string.storage = "str12"), slots = NULL), list(type = "double", 
    metadata = list(class = c("dta_numeric", "dta_long", "vctrs_vctr", 
    "double"), label = "Payload 15", stata.storage = "long"), 
    slots = NULL), list(type = "double", metadata = list(class = c("dta_numeric", 
"dta_double", "vctrs_vctr", "double"), label = "Payload 16", 
    stata.storage = "double"), slots = NULL)))), `8-nest_double` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "nested")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "list", metadata = NULL, 
            slots = list(list(type = "list", metadata = list(
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame"), label = "Stage 8 input 2", 
                names = c("r01", "r02", "r03", "r04", "r05", 
                "r06", "r07", "r08")), slots = list(list(type = "double", 
                metadata = list(class = c("dta_numeric", "dta_double", 
                "vctrs_vctr", "double"), label = "Payload 1", 
                  stata.storage = "double"), slots = NULL), list(
                type = "logical", metadata = list(label = "Payload 2"), 
                slots = NULL), list(type = "integer", metadata = list(
                class = "factor", label = "Payload 3", levels = c("a", 
                "b", "c", "unused")), slots = NULL), list(type = "integer", 
                metadata = list(class = c("ordered", "factor"
                ), label = "Payload 4", levels = c("a", "b", 
                "c", "unused")), slots = NULL), list(type = "character", 
                metadata = list(class = c("dta_string", "vctrs_vctr", 
                "character"), label = "Payload 5", stata.string.storage = "str12"), 
                slots = NULL), list(type = "character", metadata = list(
                label = "Payload 6", stata.string.storage = "str12"), 
                slots = NULL), list(type = "double", metadata = list(
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double"), label = "Payload 7", stata.storage = "long"), 
                slots = NULL), list(type = "double", metadata = list(
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double"), label = "Payload 8", stata.storage = "double"), 
                slots = NULL)))))))), `16-nest_double` = list(
    x = list(type = "list", metadata = list(class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame"), label = "Stage 8 input 1", 
        names = c("key", "c01", "c02", "c03", "c04", "c05", "c06", 
        "c07", "c08", "c09", "c10", "c11", "c12", "c13", "c14", 
        "c15", "c16")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), y = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 2", names = c("key", 
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", 
        "r09", "r10", "r11", "r12", "r13", "r14", "r15", "r16"
        )), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL))), result = list(type = "list", metadata = list(
        class = c("dibble", "dtatools_ref_data", "tbl_df", "tbl", 
        "data.frame"), label = "Stage 8 input 1", names = c("key", 
        "c01", "c02", "c03", "c04", "c05", "c06", "c07", "c08", 
        "c09", "c10", "c11", "c12", "c13", "c14", "c15", "c16", 
        "nested")), slots = list(list(type = "double", metadata = list(
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        ), stata.storage = "long"), slots = NULL), list(type = "double", 
        metadata = list(class = c("dta_numeric", "dta_double", 
        "vctrs_vctr", "double"), label = "Payload 1", stata.storage = "double"), 
        slots = NULL), list(type = "logical", metadata = list(
        label = "Payload 2"), slots = NULL), list(type = "integer", 
        metadata = list(class = "factor", label = "Payload 3", 
            levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 4", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 5", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 6", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 7", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 8", stata.storage = "double"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 9", stata.storage = "double"), 
            slots = NULL), list(type = "logical", metadata = list(
            label = "Payload 10"), slots = NULL), list(type = "integer", 
            metadata = list(class = "factor", label = "Payload 11", 
                levels = c("a", "b", "c", "unused")), slots = NULL), 
        list(type = "integer", metadata = list(class = c("ordered", 
        "factor"), label = "Payload 12", levels = c("a", "b", 
        "c", "unused")), slots = NULL), list(type = "character", 
            metadata = list(class = c("dta_string", "vctrs_vctr", 
            "character"), label = "Payload 13", stata.string.storage = "str12"), 
            slots = NULL), list(type = "character", metadata = list(
            label = "Payload 14", stata.string.storage = "str12"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double"), label = "Payload 15", stata.storage = "long"), 
            slots = NULL), list(type = "double", metadata = list(
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double"), label = "Payload 16", stata.storage = "double"), 
            slots = NULL), list(type = "list", metadata = NULL, 
            slots = list(list(type = "list", metadata = list(
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame"), label = "Stage 8 input 2", 
                names = c("r01", "r02", "r03", "r04", "r05", 
                "r06", "r07", "r08", "r09", "r10", "r11", "r12", 
                "r13", "r14", "r15", "r16")), slots = list(list(
                type = "double", metadata = list(class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double"), label = "Payload 1", 
                  stata.storage = "double"), slots = NULL), list(
                type = "logical", metadata = list(label = "Payload 2"), 
                slots = NULL), list(type = "integer", metadata = list(
                class = "factor", label = "Payload 3", levels = c("a", 
                "b", "c", "unused")), slots = NULL), list(type = "integer", 
                metadata = list(class = c("ordered", "factor"
                ), label = "Payload 4", levels = c("a", "b", 
                "c", "unused")), slots = NULL), list(type = "character", 
                metadata = list(class = c("dta_string", "vctrs_vctr", 
                "character"), label = "Payload 5", stata.string.storage = "str12"), 
                slots = NULL), list(type = "character", metadata = list(
                label = "Payload 6", stata.string.storage = "str12"), 
                slots = NULL), list(type = "double", metadata = list(
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double"), label = "Payload 7", stata.storage = "long"), 
                slots = NULL), list(type = "double", metadata = list(
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double"), label = "Payload 8", stata.storage = "double"), 
                slots = NULL), list(type = "double", metadata = list(
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double"), label = "Payload 9", stata.storage = "double"), 
                slots = NULL), list(type = "logical", metadata = list(
                label = "Payload 10"), slots = NULL), list(type = "integer", 
                metadata = list(class = "factor", label = "Payload 11", 
                  levels = c("a", "b", "c", "unused")), slots = NULL), 
                list(type = "integer", metadata = list(class = c("ordered", 
                "factor"), label = "Payload 12", levels = c("a", 
                "b", "c", "unused")), slots = NULL), list(type = "character", 
                  metadata = list(class = c("dta_string", "vctrs_vctr", 
                  "character"), label = "Payload 13", stata.string.storage = "str12"), 
                  slots = NULL), list(type = "character", metadata = list(
                  label = "Payload 14", stata.string.storage = "str12"), 
                  slots = NULL), list(type = "double", metadata = list(
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double"), label = "Payload 15", stata.storage = "long"), 
                  slots = NULL), list(type = "double", metadata = list(
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double"), label = "Payload 16", stata.storage = "double"), 
                  slots = NULL)))))))))
