list(blocks = 7L, passed = 305L, failed = 0L, errors = 0L, warnings = 0L, 
    skips = 0L)
