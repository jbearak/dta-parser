test_that("B00 snapshot failure retains the public outcome and conditions", {
    scope <- new.env(parent = environment(.s8_record))
    scope$.s8_records <- new.env(parent = emptyenv())
    scope$.s8_records$values <- list()
    scope$.s8_semantic <- function(value) {
        warning("snapshot warning")
        stop("snapshot failure")
    }
    record <- .s8_record
    environment(record) <- scope
    actual <- record("snapshot_failure", { warning("call warning"); 42L })
    saved <- scope$.s8_records$values$snapshot_failure
    expect_true(actual$ok)
    expect_identical(actual$value, 42L)
    expect_identical(saved$status, "return")
    expect_null(saved$error)
    expect_identical(saved$conditions[[1L]]$message, "call warning")
    expect_identical(saved$snapshot_status, "error")
    expect_identical(saved$snapshot_conditions[[1L]]$message, "snapshot warning")
    expect_identical(saved$snapshot_error$message, "snapshot failure")
    failed <- record("call_failure", { warning("before error"); stop("call failure") })
    saved <- scope$.s8_records$values$call_failure
    expect_false(failed$ok)
    expect_identical(saved$status, "error")
    expect_identical(saved$error$message, "call failure")
    expect_identical(saved$conditions[[1L]]$message, "before error")
    expect_identical(saved$snapshot_status, "not_applicable")
    expect_length(saved$snapshot_conditions, 0L)
    scope$.s8_semantic <- function(value) list(value = value)
    actual <- record("complete", 17L)
    saved <- scope$.s8_records$values$complete
    expect_true(actual$ok)
    expect_identical(saved$snapshot_status, "complete")
    expect_identical(saved$value, list(value = 17L))
})
