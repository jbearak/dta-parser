"""Run selected candidate functional tests on one accepted installed package; no timings."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
                bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    config_path = args.config.resolve(strict=True)
    config_identity = identity(config_path)
    config = json.loads(config_path.read_text())
    require(identity(config_path) == config_identity, "Config changed while reading")
    root = Path(__file__).resolve().parent
    install = Path(config["installation"]).resolve(strict=True)
    draft = Path(config["draft"]).resolve(strict=True)
    rroot = Path("/opt/homebrew/Cellar/r/4.6.1")
    site = Path("/opt/homebrew/lib/R/4.6/site-library")
    rscript = rroot / "bin/Rscript"
    output = args.output.absolute()
    require(output == output.resolve() and not output.exists() and not output.is_symlink(),
            "Fresh canonical output required")
    require(all(not output.is_relative_to(p) and not p.is_relative_to(output)
                for p in (root, install, draft, rroot, site)), "Output overlaps a selected input")
    require(len(config["source"]) == 40 and all(c in "0123456789abcdef" for c in config["source"]),
            "Full source commit required")
    require(type(config["blocks"]) is int and config["blocks"] > 0, "Positive block count required")
    output.mkdir(parents=True)
    status, before, changed = "failed", None, None
    errors, command_record = [], None
    selected, roots = [], [rroot, site, install / "library" / "dtatools"]

    def inventory():
        paths = set(selected)
        for directory in roots:
            require(directory.is_dir(), "Missing selected runtime root: " + str(directory))
            paths.update(p for p in directory.rglob("*")
                         if (p.is_file() or p.is_symlink()) and not p.is_dir())
        return [identity(p) for p in sorted(paths)]

    try:
        receipt = install / "completed-receipt.json"
        manifest = install / "output-manifest.json"
        index = install / "installed-files.json"
        receipt_identity = identity(receipt)
        require(receipt_identity["sha256"] == config["receipt_sha256"], "Wrong accepted receipt")
        accepted = json.loads(receipt.read_text())
        require(accepted["status"] == "complete" and accepted["revision"] == config["source"]
                and accepted["package_tree"] == config["package_tree"], "Wrong accepted source/package")
        manifest_identity = identity(manifest)
        index_identity = identity(index)
        require(manifest_identity == accepted["manifest"], "Changed accepted product manifest")
        require(index_identity in json.loads(manifest.read_text())["products"], "Unbound installed index")
        expected = json.loads(index.read_text())["files"]
        expected_paths = {row["path"] for row in expected}
        require(len(expected_paths) == len(expected) and len(expected) > 0, "Invalid installed membership")
        require(all(Path(row["path"]).is_relative_to(roots[-1]) and identity(Path(row["path"])) == row
                    for row in expected), "Changed accepted installed files")
        draft_files = sorted(draft.iterdir())
        require(all(p.is_file() and not p.is_symlink() for p in draft_files), "Flat regular draft files required")
        draft_records = [identity(p) for p in draft_files]
        draft_identity = [dict(name=Path(row["path"]).name, bytes=row["bytes"],
            mode=row["mode"], sha256=row["sha256"]) for row in draft_records]
        require(draft_identity == config["draft_files"], "Changed reviewed draft membership/bytes/modes")
        selected = [config_path, Path(__file__).resolve(), root / "entry-v1.R",
            root / "README.md", receipt, manifest, index, rscript, rscript.resolve(),
            Path(sys.executable).resolve(), Path(sys.orig_argv[0]).absolute(), *draft_files]
        before = inventory()
        write(output / "inputs-before.json", before)
        bound_initial = {row["path"]: row for row in before}
        validated = [config_identity, receipt_identity, manifest_identity, index_identity,
                     *expected, *draft_records]
        require(all(bound_initial.get(row["path"]) == row for row in validated),
                "Validated config, installation or draft changed before binding")
        require({row["path"] for row in before if Path(row["path"]).is_relative_to(roots[-1])}
                == expected_paths, "Changed accepted installed membership")
        source = output / "input-sources"
        source.mkdir()
        copies = [(p, source / p.name) for p in
                  [config_path, Path(__file__).resolve(), root / "entry-v1.R", root / "README.md"]]
        (source / "draft").mkdir()
        copies.extend((p, source / "draft" / p.name) for p in draft_files)
        copy_records = []
        for original, destination in copies:
            require(not destination.exists(), "Copied source basename collision")
            shutil.copyfile(original, destination)
            destination.chmod(original.stat().st_mode & 0o777)
            row, copied = identity(original), identity(destination)
            require(all(row[k] == copied[k] for k in ["bytes", "mode", "sha256"]), "Source copy differs")
            copy_records.append(dict(original=row, copied=copied))
        write(output / "source-copies.json", copy_records)
        write(output / "installation-binding.json", dict(receipt=identity(receipt), manifest=identity(manifest),
            index=identity(index), source=config["source"], package_tree=config["package_tree"], files=len(expected)))
        environment = dict(os.environ)
        environment["PATH"] = config["PATH"]
        command = [str(rscript), "--vanilla", str(source / "entry-v1.R"), str(output),
            str(install / "library"), config["source"], str(source / "draft"), str(config["blocks"])]
        command_record = dict(requested_command=["Rscript", *command[1:]], command=command,
            selected_rscript=identity(rscript), python_invocation=sys.orig_argv,
            PATH=environment["PATH"], cwd=str(source), started_utc=now())
        write(output / "command-before.json", command_record)
        require(inventory() == before, "Selected inputs changed before launch")
        require(all(identity(Path(row["copied"]["path"])) == row["copied"] for row in copy_records),
                "Copied sources changed before launch")
        with (output / "witness.log").open("x") as log:
            command_record["returncode"] = subprocess.run(command, cwd=source, env=environment,
                stdout=log, stderr=subprocess.STDOUT, timeout=300).returncode
        command_record["completed_utc"] = now()
        write(output / "command-result.json", command_record)
        require(all(identity(Path(row["copied"]["path"])) == row["copied"] for row in copy_records),
                "Copied sources changed during launch")
        bound = {row["resolved"] for row in before}
        coverage = {}
        for suffix in ["before", "after"]:
            namespaces = (output / ("namespaces-" + suffix + ".tsv")).read_text().splitlines()[1:]
            for line in namespaces:
                package, path = line.split("\t")
                require(str((Path(path) / "DESCRIPTION").resolve(strict=True)) in bound,
                        "Unbound namespace: " + package)
            dlls = (output / ("dlls-" + suffix + ".txt")).read_text().splitlines()
            for path in dlls:
                require(path == "base" or str(Path(path).resolve(strict=True)) in bound, "Unbound DLL: " + path)
            coverage[suffix] = dict(namespaces=len(namespaces), file_dlls=sum(x != "base" for x in dlls),
                                    non_file_dlls=[x for x in dlls if x == "base"])
        write(output / "runtime-coverage.json", coverage)
        require(command_record["returncode"] == 0, "Draft subprocess failed; all observations retained")
        status = "complete"
    except Exception as error:
        errors.append(dict(type=type(error).__name__, message=str(error)))
    finally:
        if before is not None:
            try:
                after = inventory()
                write(output / "inputs-after.json", after)
                changed = before != after
            except Exception as error:
                changed = True
                errors.append(dict(type=type(error).__name__, message=str(error)))
        if changed is not False or errors:
            status = "failed"
        write(output / "result.json", dict(status=status, accepted=False, inputs_unchanged=changed is False,
            command=command_record, errors=errors, scope=config["scope"]))
        products = [identity(p) for p in sorted(output.rglob("*")) if p.is_file()
                    and p not in (output / "products.json", output / "receipt.json")]
        write(output / "products.json", dict(products=products, excluded=["products.json", "receipt.json"]))
        write(output / "receipt.json", dict(status=status, products=identity(output / "products.json")))
    print(json.dumps(dict(status=status, receipt=identity(output / "receipt.json"))))
    return 0 if status == "complete" else 1


if __name__ == "__main__":
    sys.exit(main())
