# Selected installed-source functional tests. See README.md.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
out <- normalizePath(args[[1L]], mustWork = TRUE)
library_path <- normalizePath(args[[2L]], mustWork = TRUE)
draft <- normalizePath(args[[4L]], mustWork = TRUE)
expected_blocks <- as.integer(args[[5L]])
.libPaths(c(library_path, "/opt/homebrew/lib/R/4.6/site-library", .Library))

runtime <- function(suffix) {
    packages <- sort(loadedNamespaces())
    paths <- vapply(packages, function(p) if (p == "base") file.path(.Library, "base") else
        getNamespaceInfo(asNamespace(p), "path"), "")
    write.table(data.frame(package = packages, path = paths),
        file.path(out, paste0("namespaces-", suffix, ".tsv")),
        sep = "\t", row.names = FALSE, quote = FALSE)
    writeLines(vapply(getLoadedDLLs(), function(x) x[["path"]], ""),
        file.path(out, paste0("dlls-", suffix, ".txt")))
    dput(list(libraries = .libPaths(), session = sessionInfo()),
        file.path(out, paste0("runtime-", suffix, ".R")))
}

run <- function() {
    on.exit(runtime("after"), add = TRUE)
    runtime("before")
    library(dtatools)
    package_path <- normalizePath(file.path(library_path, "dtatools"))
    stopifnot(identical(normalizePath(getNamespaceInfo(asNamespace("dtatools"), "path")), package_path),
        length(getNamespaceExports("dtatools")) == 106L,
        as.character(packageVersion("dplyr")) == "1.2.1")
    provenance <- readRDS(file.path(package_path, "Meta", "benchmark-provenance.rds"))
    stopifnot(identical(provenance$source_sha, args[[3L]]))
    dll <- normalizePath(getLoadedDLLs()[["dtatools"]][["path"]])
    stopifnot(startsWith(dll, paste0(package_path, "/")))
    dput(list(source = args[[3L]], package_path = package_path, dll = dll,
        provenance = provenance, exports = sort(getNamespaceExports("dtatools"))),
        file.path(out, "selected-package.R"))
    testthat::set_max_fails(Inf)
    results <- testthat::test_dir(draft, reporter = "summary", load_helpers = TRUE,
        package = "dtatools", load_package = "installed", stop_on_failure = FALSE)
    frame <- as.data.frame(results)
    saveRDS(results, file.path(out, "test-results.rds"))
    dput(results, file.path(out, "test-results.R"))
    write.csv(frame[setdiff(names(frame), "result")], file.path(out, "test-results.csv"), row.names = FALSE)
    counts <- list(blocks = nrow(frame), passed = sum(frame$passed), failed = sum(frame$failed),
        errors = sum(frame$error), warnings = sum(frame$warning), skips = sum(frame$skipped))
    dput(counts, file.path(out, "counts.R"))
    print(counts)
    if (nrow(frame) != expected_blocks) stop("Missing or extra draft test blocks")
    if (sum(frame$failed) || any(frame$error)) stop("Draft expectations failed; observations retained")
    cat("All selected draft blocks completed without failure or error. Warnings and skips remain recorded.\n")
}
run()
