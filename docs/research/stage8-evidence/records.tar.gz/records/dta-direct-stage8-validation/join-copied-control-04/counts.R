list(blocks = 9L, passed = 1860L, failed = 41L, errors = 0L, 
    warnings = 0L, skips = 0L)
