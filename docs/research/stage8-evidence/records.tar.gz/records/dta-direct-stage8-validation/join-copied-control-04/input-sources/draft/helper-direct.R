.s8_direct <- new.env(parent = asNamespace("dtatools"))
for (.s8_module in c("dibble-join-plan.R", "dibble-join-matches.R", "dibble-joins.R")) {
    sys.source(file.path(get("draft", envir = .GlobalEnv), .s8_module), envir = .s8_direct)
}
.s8_join <- function(name) {
    public <- getExportedValue("dplyr", name)
    direct <- get(paste0(name, ".dtatools_ref_data"), envir = .s8_direct)
    function(x, y, ...) {
        args <- list(x = x, y = y, ...)
        do.call(if (is_dibble(x)) direct else public, args)
    }
}
