test_that("J08 custom input conversion retains values size conditions and callbacks", {
    method_name <- "as_tibble.s8_join_conversion"
    stopifnot(!exists(method_name, envir = .GlobalEnv, inherits = FALSE))
    trace <- new.env(parent = emptyenv())
    trace$events <- character()
    convert <- function(x, ..., .name_repair = "check_unique") {
        trace$events <- c(trace$events, paste0("convert:", attr(x, "mode")))
        mode <- attr(x, "mode")
        if (mode == "error") rlang::abort("conversion failed", class = "s8_conversion_error")
        if (mode == "warning") warning("conversion warning")
        class(x) <- "data.frame"
        x$value <- x$value + 100L
        if (mode == "shrink") x <- x[1L, , drop = FALSE]
        tibble::as_tibble(x, ..., .name_repair = .name_repair)
    }
    assign(method_name, convert, envir = .GlobalEnv)
    on.exit(rm(list = method_name, envir = .GlobalEnv), add = TRUE)
    scope <- new.env(parent = environment(.s8_record))
    scope$.s8_records <- new.env(parent = emptyenv())
    scope$.s8_records$values <- list()
    record <- .s8_record
    environment(record) <- scope
    observed <- list()
    on.exit({
        directory <- get("out", envir = .GlobalEnv)
        saveRDS(observed, file.path(directory, "custom-conversion.rds"))
        dput(observed, file.path(directory, "custom-conversion.R"))
    }, add = TRUE)
    for (type in c("left", "semi", "cross", "nest"))
        for (mode in c("transform", "shrink", "warning", "error")) {
            pair <- list()
            for (route in c("public", "copied")) {
                x <- dibble(k = 1:2, source = 3:4)
                y <- structure(data.frame(k = 1:2, value = 7:8),
                    class = c("s8_join_conversion", "data.frame"), mode = mode)
                before <- .s8_control_snapshot(list(x = x, y = y))
                expect_identical(before$status, "complete")
                args <- list(x, y)
                if (type != "cross") args$by <- "k"
                if (type == "nest") args$name <- "matched"
                trace$events <- character()
                fn <- if (route == "public") getExportedValue("dplyr", paste0(type, "_join")) else
                    get(paste0(type, "_join.dtatools_ref_data"), envir = .s8_direct)
                id <- paste(type, mode, route, sep = "/")
                result <- record(id, do.call(fn, args))
                saved <- scope$.s8_records$values[[id]]
                saved$events <- trace$events
                saved$inputs_before <- before
                saved$inputs_after <- list(status = "pending")
                observed[[id]] <- saved
                saved$inputs_after <- .s8_control_snapshot(list(x = x, y = y))
                pair[[route]] <- saved
                observed[[id]] <- saved
                expect_identical(saved$inputs_after$status, "complete", info = id)
                expect_identical(saved$inputs_after$value, before$value, info = id)
                expect_identical(saved$events, paste0("convert:", mode), info = id)
                expect_identical(saved$status, if (mode == "error") "error" else "return", info = id)
                expect_identical(saved$snapshot_status,
                    if (mode == "error") "not_applicable" else "complete", info = id)
            }
            id <- paste(type, mode, sep = "/")
            expect_identical(pair$copied$value, pair$public$value, info = id)
            expect_identical(pair$copied$error$classes, pair$public$error$classes, info = id)
            expect_identical(pair$copied$error$message, pair$public$error$message, info = id)
            expect_identical(pair$copied$events, pair$public$events, info = id)
            expect_identical(lapply(pair$copied$conditions, function(x) x[c("classes", "message")]),
                             lapply(pair$public$conditions, function(x) x[c("classes", "message")]), info = id)
        }
})
