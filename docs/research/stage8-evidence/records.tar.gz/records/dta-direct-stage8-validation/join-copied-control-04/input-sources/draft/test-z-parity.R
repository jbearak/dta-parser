test_that("J07 copied join outcomes match the actual predecessor records", {
    on.exit(.s8_flush())
    prior <- readRDS(file.path(get("draft", envir = .GlobalEnv), "predecessor-observations.rds"))
    expect_identical(names(.s8_records$values), names(prior))
    for (id in names(prior)) {
        before <- prior[[id]]; actual <- .s8_records$values[[id]]
        expect_identical(actual$status, before$status, info = id)
        expect_identical(actual$snapshot_status, before$snapshot_status, info = id)
        if (before$status == "return") {
            expect_identical(actual$value, before$value, info = id)
        } else {
            expect_identical(actual$error$classes, before$error$classes, info = id)
        }
        expect_identical(lapply(actual$conditions, `[[`, "classes"),
                         lapply(before$conditions, `[[`, "classes"), info = id)
    }
})
