list(`left/transform/public` = list(id = "left/transform/public", 
    status = "return", conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source", "value"), 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
            108)))), events = "convert:transform", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/transform/copied` = list(
    id = "left/transform/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "value"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
        108)))), events = "convert:transform", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/shrink/public` = list(
    id = "left/shrink/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "value"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
        NA)))), events = "convert:shrink", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/shrink/copied` = list(
    id = "left/shrink/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "value"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
        NA)))), events = "convert:shrink", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/warning/public` = list(
    id = "left/warning/public", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(y, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source", "value"), 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
            108)))), events = "convert:warning", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/warning/copied` = list(
    id = "left/warning/copied", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(data, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source", "value"), 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
            108)))), events = "convert:warning", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/error/public` = list(
    id = "left/error/public", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "as_tibble(y, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `left/error/copied` = list(
    id = "left/error/copied", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "tibble::as_tibble(data, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/transform/public` = list(
    id = "semi/transform/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = c(3, 4
        )))), events = "convert:transform", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/transform/copied` = list(
    id = "semi/transform/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = c(3, 4
        )))), events = "convert:transform", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/shrink/public` = list(
    id = "semi/shrink/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = 1), source = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = 3))), 
    events = "convert:shrink", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `semi/shrink/copied` = list(
    id = "semi/shrink/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = 1), source = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = 3))), 
    events = "convert:shrink", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `semi/warning/public` = list(
    id = "semi/warning/public", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(y, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source"), row.names = 1:2, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), events = "convert:warning", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/warning/copied` = list(
    id = "semi/warning/copied", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(data, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source"), row.names = 1:2, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), events = "convert:warning", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/error/public` = list(
    id = "semi/error/public", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "as_tibble(y, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `semi/error/copied` = list(
    id = "semi/error/copied", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "tibble::as_tibble(data, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `cross/transform/public` = list(
    id = "cross/transform/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k.x", 
    "source", "k.y", "value"), row.names = 1:4, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k.x = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 1, 2, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 3, 4, 4)), k.y = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 1, 2)), value = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(107, 108, 107, 108)))), 
    events = "convert:transform", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `cross/transform/copied` = list(
    id = "cross/transform/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k.x", 
    "source", "k.y", "value"), row.names = 1:4, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k.x = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 1, 2, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 3, 4, 4)), k.y = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 1, 2)), value = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(107, 108, 107, 108)))), 
    events = "convert:transform", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `cross/shrink/public` = list(
    id = "cross/shrink/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k.x", 
    "source", "k.y", "value"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k.x = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), k.y = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        1)), value = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
        107)))), events = "convert:shrink", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `cross/shrink/copied` = list(
    id = "cross/shrink/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k.x", 
    "source", "k.y", "value"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k.x = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), k.y = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        1)), value = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(107, 
        107)))), events = "convert:shrink", inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `cross/warning/public` = list(
    id = "cross/warning/public", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(y, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k.x", "source", "k.y", "value"
        ), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k.x = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 1, 2, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 3, 4, 4)), k.y = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 1, 2)), value = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(107, 108, 107, 108)))), 
    events = "convert:warning", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `cross/warning/copied` = list(
    id = "cross/warning/copied", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(data, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k.x", "source", "k.y", "value"
        ), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k.x = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 1, 2, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 3, 4, 4)), k.y = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 1, 2)), value = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(107, 108, 107, 108)))), 
    events = "convert:warning", inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8))))), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8)))))), `cross/error/public` = list(
    id = "cross/error/public", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "as_tibble(y, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `cross/error/copied` = list(
    id = "cross/error/copied", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "tibble::as_tibble(data, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/transform/public` = list(
    id = "nest/transform/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "matched"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), matched = list(kind = "list", attributes = NULL, 
            values = list(list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "transform"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "transform"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 108L))))))), events = "convert:transform", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/transform/copied` = list(
    id = "nest/transform/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "matched"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), matched = list(kind = "list", attributes = NULL, 
            values = list(list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "transform"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "transform"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 108L))))))), events = "convert:transform", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "transform"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "transform"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/shrink/public` = list(
    id = "nest/shrink/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "matched"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), matched = list(kind = "list", attributes = NULL, 
            values = list(list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "shrink"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = integer(0), class = c("s8_join_conversion", 
                "data.frame"), mode = "shrink"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = integer(0)))))))), events = "convert:shrink", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/shrink/copied` = list(
    id = "nest/shrink/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "source", "matched"), row.names = 1:2, class = c("dibble", 
    "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), columns = list(
        k = list(kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), source = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), matched = list(kind = "list", attributes = NULL, 
            values = list(list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "shrink"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = integer(0), class = c("s8_join_conversion", 
                "data.frame"), mode = "shrink"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = integer(0)))))))), events = "convert:shrink", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "shrink"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "shrink"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/warning/public` = list(
    id = "nest/warning/public", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(y, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source", "matched"), 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), matched = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "frame", attributes = list(names = "value", 
                  row.names = 1L, class = c("s8_join_conversion", 
                  "data.frame"), mode = "warning"), columns = list(
                  value = list(kind = "integer", attributes = NULL, 
                    values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "warning"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 108L))))))), events = "convert:warning", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/warning/copied` = list(
    id = "nest/warning/copied", status = "return", conditions = list(
        list(classes = c("simpleWarning", "warning", "condition"
        ), message = "conversion warning", call = "as_tibble.s8_join_conversion(data, .name_repair = \"minimal\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "source", "matched"), 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), source = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), matched = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "frame", attributes = list(names = "value", 
                  row.names = 1L, class = c("s8_join_conversion", 
                  "data.frame"), mode = "warning"), columns = list(
                  value = list(kind = "integer", attributes = NULL, 
                    values = 107L))), list(kind = "frame", attributes = list(
                names = "value", row.names = 1L, class = c("s8_join_conversion", 
                "data.frame"), mode = "warning"), columns = list(
                value = list(kind = "integer", attributes = NULL, 
                  values = 108L))))))), events = "convert:warning", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "warning"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "warning"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/error/public` = list(
    id = "nest/error/public", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "as_tibble(y, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))), `nest/error/copied` = list(
    id = "nest/error/copied", status = "error", conditions = list(), 
    error = list(classes = c("s8_conversion_error", "rlang_error", 
    "error", "condition"), message = "conversion failed", call = "tibble::as_tibble(data, .name_repair = \"minimal\")", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = "convert:error", 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(x = list(kind = "frame", attributes = list(
            names = c("k", "source"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), source = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)))), y = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("s8_join_conversion", "data.frame"
        ), row.names = 1:2, mode = "error"), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "integer", attributes = NULL, 
                values = 7:8))))), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(x = list(
            kind = "frame", attributes = list(names = c("k", 
            "source"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), source = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), y = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("s8_join_conversion", 
            "data.frame"), row.names = 1:2, mode = "error"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = 7:8)))))))
