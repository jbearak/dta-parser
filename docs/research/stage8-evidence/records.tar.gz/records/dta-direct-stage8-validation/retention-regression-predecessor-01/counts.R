list(blocks = 2L, passed = 20L, failed = 7L, errors = 0L, warnings = 0L, 
    skips = 0L)
