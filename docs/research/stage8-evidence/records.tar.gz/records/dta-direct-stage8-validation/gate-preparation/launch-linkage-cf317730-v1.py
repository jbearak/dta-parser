from pathlib import Path
import datetime, hashlib, json, subprocess, sys

v = Path('/private/tmp/dta-direct-stage8-validation')
w = Path('/private/tmp/dta-direct-stage8')
script = Path('/private/tmp/dta-direct-stage6-validation/implementation/linkage-preparation/check-installed-linkage-v1.py')
source = 'cf317730d3110568c72862719424e01c2876141b'
def fact(path):
    p = Path(path); r = p.resolve(strict=True); s = r.stat()
    return dict(path=str(p), resolved=str(r), bytes=s.st_size, mode=oct(s.st_mode & 0o7777), sha256=hashlib.sha256(r.read_bytes()).hexdigest())
tools = [fact(script), fact(sys.executable), fact(__file__)]
if tools[0]['sha256'] != 'c76672b985672f7fd73b56bf96610d642931353e8ba4d66e74d5180decbba67f':
    raise RuntimeError('Reviewed linkage runner changed')
for kind, dirname, receipt_name, digest, dll_suffix in [
    ('host','candidate-cf317730-01','completed-receipt.json','fd19cba85a531184d8d812a4a7ff556554917d380741b4ff191eb86972fad4b4','library/dtatools/libs/dtatools.so'),
    ('binary','package-cf317730-01','receipt.json','0e3f36fa429df26e62e4e6f02a3629d19d9cc609123b2ed373f4389c050f039b','binary/library/dtatools/libs/dtatools.so')]:
    base = v / dirname; receipt_path = base / receipt_name; selected = [*tools, fact(receipt_path)]
    if selected[-1]['sha256'] != digest: raise RuntimeError('Accepted receipt mismatch')
    receipt = json.loads(receipt_path.read_text()); manifest_path = Path(receipt['manifest']['path'])
    mf = fact(manifest_path); selected.append(mf)
    if mf != receipt['manifest'] or receipt['status'] != 'complete': raise RuntimeError('Manifest/status mismatch')
    revision = receipt.get('revision', receipt.get('source_sha'))
    if revision != source: raise RuntimeError('Receipt source mismatch')
    manifest = json.loads(manifest_path.read_text()); dll = base / dll_suffix; df = fact(dll)
    rows = [x for x in manifest['products'] if x['path'] == str(dll)]
    if rows != [df]: raise RuntimeError('DLL absent/changed in exact accepted manifest')
    selected.append(df)
    out = v / ('linkage-cf317730-' + kind + '-01')
    argv = [str(sys.executable), '-I', '-B', str(script), str(w), source, str(dll), str(out)]
    record = dict(kind=kind, source=source, argv=argv, selected_before=selected,
                  started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    target = v / 'gate-preparation' / ('linkage-' + kind + '-cf317730-launch-01.json')
    with target.open('x') as stream: stream.write(json.dumps(record, indent=2) + '\n')
    result = subprocess.run(argv, cwd=w, text=True, capture_output=True)
    after = [fact(x['path']) for x in selected]
    record.update(exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr,
                  selected_after=after, changed=[a['path'] for a,b in zip(selected,after) if a != b],
                  completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    with target.with_name(target.stem.replace('launch-', 'launch-result-') + '.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    if result.returncode or record['changed']: raise RuntimeError('Linkage execution failed or input changed')
    print(json.dumps(dict(kind=kind, receipt=fact(out / 'receipt.json'), stdout=result.stdout)))
