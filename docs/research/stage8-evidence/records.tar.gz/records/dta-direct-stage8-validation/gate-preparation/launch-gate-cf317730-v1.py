from pathlib import Path
import json,hashlib,subprocess,os,datetime,sys
v=Path('/private/tmp/dta-direct-stage8-validation');w=Path('/private/tmp/dta-direct-stage8');ins=v/'candidate-cf317730-01';prep=v/'gate-preparation'
phase=sys.argv[1]
if phase not in ['full','package']:raise RuntimeError('Expected full/package')
def fact(p):
 p=Path(p);r=p.resolve(strict=True);s=r.stat();return {'path':str(p),'resolved':str(r),'bytes':s.st_size,'mode':oct(s.st_mode&0o777),'sha256':hashlib.sha256(r.read_bytes()).hexdigest()}
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
native=json.loads((prep/'native-cf317730-launch-01.json').read_text())
fixed=[x for x in native['selected_before'] if x['path'] in ['/Users/jmb/.pyenv/versions/3.14.7/bin/python3.14','/opt/homebrew/bin/git',str(w/'benchmarks/r-dibble-dplyr/run-expression-checks.py')]]
if len(fixed)!=3 or [fact(x['path']) for x in fixed]!=fixed:raise RuntimeError('Selected gate tools changed')
source='cf317730d3110568c72862719424e01c2876141b';qualified='3db15d44f2b557f5282fb7a30fd59c7980a4484c'
old=Path('/private/tmp/dta-direct-stage7-validation/implementation')/(phase+'-3db15d44-01')
rp=old/'receipt.json';receipt=json.loads(rp.read_text())
if receipt['status']!='complete' or receipt['source_sha']!=qualified or receipt['runner_sha']!=qualified:raise RuntimeError('Prior gate not complete on qualified source')
if fact(old/'manifest.json')!=receipt['manifest']:raise RuntimeError('Prior gate manifest mismatch')
git_argv=['/opt/homebrew/bin/git','diff','--name-status',qualified,source,'--','benchmarks','scripts']
git_result=subprocess.run(git_argv,cwd=w,text=True,capture_output=True)
if git_result.returncode or git_result.stdout:raise RuntimeError('Qualification scripts changed: '+git_result.stdout+git_result.stderr)
rp2=ins/'completed-receipt.json'
if fact(rp2)['sha256']!='fd19cba85a531184d8d812a4a7ff556554917d380741b4ff191eb86972fad4b4':raise RuntimeError('Installation receipt mismatch')
accepted=json.loads(rp2.read_text())
if accepted['status']!='complete' or accepted['revision']!=source or fact(ins/'output-manifest.json')!=accepted['manifest']:raise RuntimeError('Installation binding mismatch')
selected=[*fixed,fact(rp),fact(old/'manifest.json'),fact(rp2),fact(ins/'output-manifest.json'),fact(ins/'installed-files.json'),fact(v/'history-lifetime-correction-commit-01.json'),fact(Path(__file__))]
out=v/(phase+'-cf317730-01')
if out.exists():raise RuntimeError('Fresh output required')
argv=[fixed[0]['path'],'-I','-B',str(w/'benchmarks/r-dibble-dplyr/run-expression-checks.py'),phase,str(w),source,source,str(ins/'library'),str(out)]
# Select the explicit interpreter, independent of the preserved fact-list order.
argv[0]='/Users/jmb/.pyenv/versions/3.14.7/bin/python3.14'
record={'source':source,'runner_source':source,'phase':phase,'argv':argv,'selected_before':selected,'qualified_script_scope':{'source':qualified,'git_argv':git_argv,'returncode':git_result.returncode,'stdout':git_result.stdout,'stderr':git_result.stderr},'PATH':native['PATH'],'started_utc':stamp()}
with (prep/(phase+'-cf317730-launch-01.json')).open('x') as stream:stream.write(json.dumps(record,indent=2)+'\n')
env=dict(os.environ);env['PATH']=native['PATH']
with (prep/(phase+'-cf317730-launch-01.log')).open('x') as log:run=subprocess.run(argv,cwd=w,env=env,stdout=log,stderr=subprocess.STDOUT)
after=[fact(x['path']) for x in selected];changed=[a['path'] for a,b in zip(selected,after) if a!=b]
with (prep/(phase+'-cf317730-launch-result-01.json')).open('x') as stream:stream.write(json.dumps({'argv':argv,'exit_code':run.returncode,'completed_utc':stamp(),'selected_after':after,'changed':changed},indent=2)+'\n')
print(json.dumps({'phase':phase,'exit_code':run.returncode,'changed':changed,'output':str(out)}));raise SystemExit(run.returncode or bool(changed))
