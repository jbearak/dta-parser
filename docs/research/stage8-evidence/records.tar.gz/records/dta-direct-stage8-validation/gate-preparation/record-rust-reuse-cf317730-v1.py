from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/private/tmp/dta-direct-stage8')
OUT = Path('/private/tmp/dta-direct-stage8-validation/rust-reuse-cf317730-01.json')
SOURCE = 'cf317730d3110568c72862719424e01c2876141b'
RUST = '7b614c6dfc3eef920dd763d48cc9f30039c9f8ca'
RUNNER = '7272e9ea9d201bc4706f6e2064484988eff4842e'
GIT = Path('/opt/homebrew/bin/git')
OLD = Path('/private/tmp/dta-direct-stage6-validation/implementation/rust-7b614c6d-01')
PATHS = ['Cargo.toml', 'Cargo.lock', 'src/dta-tools', 'src/rust',
         'r-package/dtatools/src/rust', 'r-package/dtatools/vendor', 'tests']
HELPER = 'benchmarks/r-dibble-dplyr/run-expression-checks.py'

def fact(path):
    path = Path(path)
    resolved = path.resolve(strict=True)
    stat = resolved.stat()
    return dict(path=str(path), resolved=str(resolved), bytes=stat.st_size,
                mode=oct(stat.st_mode & 0o777),
                sha256=hashlib.sha256(resolved.read_bytes()).hexdigest())

selected = [fact(GIT), fact(__file__), fact(sys.executable),
            fact(OLD / 'receipt.json'), fact(OLD / 'manifest.json'),
            fact(OLD / 'execution-result.json')]
if selected[0]['sha256'] != '9048038886ac36210fbb616b49b0707465f63683cb04e33a2013baf95f746938':
    raise RuntimeError('Selected Git identity changed')
if selected[3]['sha256'] != '194fa87e0db4409aa3716fca6a61737b804566811e9e70c26a7e40e5f157a514':
    raise RuntimeError('Original Rust receipt changed')
receipt = json.loads((OLD / 'receipt.json').read_text())
if receipt['status'] != 'complete' or receipt['source_sha'] != RUST or receipt['runner_sha'] != RUNNER or receipt['manifest'] != selected[4]:
    raise RuntimeError('Original Rust qualification identity mismatch')
execution = json.loads((OLD / 'execution-result.json').read_text())
if execution['status'] != 'complete' or execution['changed_inputs'] or not execution['input_binding_complete'] or any(x['exit_code'] != 0 for x in execution['records']):
    raise RuntimeError('Original Rust execution was not complete')
commands = []

def run(*args):
    argv = [str(GIT), '-C', str(ROOT), *args]
    result = subprocess.run(argv, text=True, capture_output=True)
    commands.append(dict(argv=argv, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
    if result.returncode:
        raise RuntimeError('Git observation failed')
    return result.stdout

record = dict(status='incomplete', source=SOURCE, rust_executed_source=RUST,
              rust_executed_runner=RUNNER, selected_paths=PATHS,
              selected_before=selected, argv=sys.orig_argv, PATH=os.environ['PATH'],
              started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
error = None
try:
    trees = {sha: run('ls-tree', '-r', sha, '--', *PATHS) for sha in [RUST, SOURCE]}
    if not trees[RUST] or trees[RUST] != trees[SOURCE]:
        raise RuntimeError('Selected Rust leaf paths, blobs, types or modes differ')
    lines = trees[RUST].splitlines()
    leaf_paths = [x.split('\t', 1)[1] for x in lines]
    if len(leaf_paths) != len(set(leaf_paths)):
        raise RuntimeError('Duplicate Rust leaf path')
    helpers = {sha: run('ls-tree', sha, '--', HELPER) for sha in [RUNNER, SOURCE]}
    if not helpers[RUNNER] or helpers[RUNNER] != helpers[SOURCE]:
        raise RuntimeError('Executed Rust runner differs')
    record.update(status='selected_source_equality_observed', leaf_count=len(lines),
                  selected_git_trees=trees, runner_git_entries=helpers,
                  original_commands=[dict(command=x['command'], exit_code=x['exit_code'], label=x['label']) for x in execution['records']],
                  scope='Historical six-command Rust qualification is reused only for equal selected Rust and runner Git leaf paths/blobs/types/modes. No new Cargo execution, current runtime equivalence, rebuilt product identity or whole-package equivalence is claimed. Fresh cf317 R/native/full/minimum/performance/history/write/package gates qualify the changed R implementation separately.')
except BaseException as exc:
    error = repr(exc)
finally:
    record['commands'] = commands
    record['error'] = error
    record['selected_after'] = [fact(x['path']) for x in selected]
    record['changed_inputs'] = [a['path'] for a, b in zip(selected, record['selected_after']) if a != b]
    record['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with OUT.open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
if error or record['changed_inputs']:
    raise RuntimeError(error or 'Selected inputs changed')
print(json.dumps(dict(output=str(OUT), sha256=fact(OUT)['sha256'], leaf_count=record['leaf_count'], commands=len(commands))))
