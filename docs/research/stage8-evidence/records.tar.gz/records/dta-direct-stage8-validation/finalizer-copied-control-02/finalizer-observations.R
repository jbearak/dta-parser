list(`FC00/routing` = list(id = "FC00/routing", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "list", 
        attributes = list(names = c("original", "lineage", "repeated", 
        "combined", "original_bodies")), values = list(original = list(
            kind = "list", attributes = list(names = c("parent_namespace", 
            "routed", "installed_entry_bodies")), values = list(
                parent_namespace = list(kind = "logical", attributes = NULL, 
                  values = TRUE), routed = list(kind = "logical", 
                  attributes = list(names = c("select.dtatools_ref_data", 
                  "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                  "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                  ".dibble_group_result", ".begin_dibble_result", 
                  ".finish_dibble_result", ".dibble_select_columns", 
                  ".capture_dibble_nested", ".type_dibble_columns", 
                  "as_dibble", ".as_dibble", "dibble", ".isolate_shared_columns", 
                  "reserve_columns")), values = c(TRUE, TRUE, 
                  TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                  TRUE, TRUE, TRUE, TRUE, TRUE, TRUE)), installed_entry_bodies = list(
                  kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
                  "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                  "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                  ".dibble_group_result", "as_dibble", ".as_dibble", 
                  "dibble", "reserve_columns")), values = c(TRUE, 
                  TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                  TRUE)))), lineage = list(kind = "list", attributes = list(
            names = c("parent_namespace", "routed", "installed_entry_bodies"
            )), values = list(parent_namespace = list(kind = "logical", 
            attributes = NULL, values = TRUE), routed = list(
            kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
            "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
            "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
            ".dibble_group_result", ".begin_dibble_result", ".finish_dibble_result", 
            ".dibble_select_columns", ".capture_dibble_nested", 
            ".type_dibble_columns", "as_dibble", ".as_dibble", 
            "dibble", ".isolate_shared_columns", "reserve_columns"
            )), values = c(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
            TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
            TRUE)), installed_entry_bodies = list(kind = "logical", 
            attributes = list(names = c("select.dtatools_ref_data", 
            "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
            "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
            ".dibble_group_result", "as_dibble", ".as_dibble", 
            "dibble", "reserve_columns")), values = c(TRUE, TRUE, 
            TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE)))), 
            repeated = list(kind = "list", attributes = list(
                names = c("parent_namespace", "routed", "installed_entry_bodies"
                )), values = list(parent_namespace = list(kind = "logical", 
                attributes = NULL, values = TRUE), routed = list(
                kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
                "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                ".dibble_group_result", ".begin_dibble_result", 
                ".finish_dibble_result", ".dibble_select_columns", 
                ".capture_dibble_nested", ".type_dibble_columns", 
                "as_dibble", ".as_dibble", "dibble", ".isolate_shared_columns", 
                "reserve_columns")), values = c(TRUE, TRUE, TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE)), installed_entry_bodies = list(
                kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
                "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                ".dibble_group_result", "as_dibble", ".as_dibble", 
                "dibble", "reserve_columns")), values = c(TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                TRUE)))), combined = list(kind = "list", attributes = list(
                names = c("parent_namespace", "routed", "installed_entry_bodies"
                )), values = list(parent_namespace = list(kind = "logical", 
                attributes = NULL, values = TRUE), routed = list(
                kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
                "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                ".dibble_group_result", ".begin_dibble_result", 
                ".finish_dibble_result", ".dibble_select_columns", 
                ".capture_dibble_nested", ".type_dibble_columns", 
                "as_dibble", ".as_dibble", "dibble", ".isolate_shared_columns", 
                "reserve_columns")), values = c(TRUE, TRUE, TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE)), installed_entry_bodies = list(
                kind = "logical", attributes = list(names = c("select.dtatools_ref_data", 
                "rename.dtatools_ref_data", "relocate.dtatools_ref_data", 
                "ungroup.dtatools_ref_data", "rowwise.dtatools_ref_data", 
                ".dibble_group_result", "as_dibble", ".as_dibble", 
                "dibble", "reserve_columns")), values = c(TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, 
                TRUE)))), original_bodies = list(kind = "logical", 
                attributes = list(names = c(".begin_dibble_result", 
                ".finish_dibble_result", ".prepare_dibble_result_column", 
                ".capture_dibble_nested", ".type_dibble_columns", 
                ".isolate_shared_columns")), values = c(TRUE, 
                TRUE, TRUE, TRUE, TRUE, TRUE)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list()), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list())), 
    `FC01/plain/select/public` = list(id = "FC01/plain/select/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("g", 
        "x"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(g = list(
            kind = "character", attributes = list(stata.string.storage = "str1"), 
            values = c("a", "b", "a")), x = list(kind = "double", 
            attributes = list(label = "payload", stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/select/original` = list(
        id = "FC01/plain/select/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/select/lineage` = list(
        id = "FC01/plain/select/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/select/repeated` = list(
        id = "FC01/plain/select/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/select/combined` = list(
        id = "FC01/plain/select/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rename/public` = list(
        id = "FC01/plain/rename/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("g", 
        "value", "z"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(g = list(
            kind = "character", attributes = list(stata.string.storage = "str1"), 
            values = c("a", "b", "a")), value = list(kind = "double", 
            attributes = list(label = "payload", stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)), z = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rename/original` = list(
        id = "FC01/plain/rename/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rename/lineage` = list(
        id = "FC01/plain/rename/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rename/repeated` = list(
        id = "FC01/plain/rename/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rename/combined` = list(
        id = "FC01/plain/rename/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/relocate/public` = list(
        id = "FC01/plain/relocate/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(label = "payload", 
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("a", 
            "b", "a")), z = list(kind = "list", attributes = NULL, 
                values = list(list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 1L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 2L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/relocate/original` = list(
        id = "FC01/plain/relocate/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(label = "payload", 
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("a", 
            "b", "a")), z = list(kind = "list", attributes = NULL, 
                values = list(list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 1L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 2L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/relocate/lineage` = list(
        id = "FC01/plain/relocate/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(label = "payload", 
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("a", 
            "b", "a")), z = list(kind = "list", attributes = NULL, 
                values = list(list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 1L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 2L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/relocate/repeated` = list(
        id = "FC01/plain/relocate/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(label = "payload", 
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("a", 
            "b", "a")), z = list(kind = "list", attributes = NULL, 
                values = list(list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 1L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 2L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/relocate/combined` = list(
        id = "FC01/plain/relocate/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(label = "payload", 
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("a", 
            "b", "a")), z = list(kind = "list", attributes = NULL, 
                values = list(list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 1L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 2L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/ungroup/public` = list(
        id = "FC01/plain/ungroup/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/ungroup/original` = list(
        id = "FC01/plain/ungroup/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/ungroup/lineage` = list(
        id = "FC01/plain/ungroup/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/ungroup/repeated` = list(
        id = "FC01/plain/ungroup/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/ungroup/combined` = list(
        id = "FC01/plain/ungroup/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rowwise/public` = list(
        id = "FC01/plain/rowwise/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rowwise/original` = list(
        id = "FC01/plain/rowwise/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rowwise/lineage` = list(
        id = "FC01/plain/rowwise/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rowwise/repeated` = list(
        id = "FC01/plain/rowwise/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/plain/rowwise/combined` = list(
        id = "FC01/plain/rowwise/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/select/public` = list(
        id = "FC01/grouped/select/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/select/original` = list(
        id = "FC01/grouped/select/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/select/lineage` = list(
        id = "FC01/grouped/select/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/select/repeated` = list(
        id = "FC01/grouped/select/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/select/combined` = list(
        id = "FC01/grouped/select/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rename/public` = list(
        id = "FC01/grouped/rename/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rename/original` = list(
        id = "FC01/grouped/rename/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rename/lineage` = list(
        id = "FC01/grouped/rename/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rename/repeated` = list(
        id = "FC01/grouped/rename/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rename/combined` = list(
        id = "FC01/grouped/rename/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/relocate/public` = list(
        id = "FC01/grouped/relocate/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/relocate/original` = list(
        id = "FC01/grouped/relocate/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/relocate/lineage` = list(
        id = "FC01/grouped/relocate/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/relocate/repeated` = list(
        id = "FC01/grouped/relocate/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/relocate/combined` = list(
        id = "FC01/grouped/relocate/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "grouped_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/ungroup/public` = list(
        id = "FC01/grouped/ungroup/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/ungroup/original` = list(
        id = "FC01/grouped/ungroup/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/ungroup/lineage` = list(
        id = "FC01/grouped/ungroup/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/ungroup/repeated` = list(
        id = "FC01/grouped/ungroup/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/ungroup/combined` = list(
        id = "FC01/grouped/ungroup/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rowwise/public` = list(
        id = "FC01/grouped/rowwise/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rowwise/original` = list(
        id = "FC01/grouped/rowwise/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rowwise/lineage` = list(
        id = "FC01/grouped/rowwise/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rowwise/repeated` = list(
        id = "FC01/grouped/rowwise/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/grouped/rowwise/combined` = list(
        id = "FC01/grouped/rowwise/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b"), stata.string.storage = "str1"), 
                  .rows = structure(list(c(1L, 3L), 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/select/public` = list(
        id = "FC01/rowwise/select/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/select/original` = list(
        id = "FC01/rowwise/select/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/select/lineage` = list(
        id = "FC01/rowwise/select/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/select/repeated` = list(
        id = "FC01/rowwise/select/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/select/combined` = list(
        id = "FC01/rowwise/select/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rename/public` = list(
        id = "FC01/rowwise/rename/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rename/original` = list(
        id = "FC01/rowwise/rename/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rename/lineage` = list(
        id = "FC01/rowwise/rename/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rename/repeated` = list(
        id = "FC01/rowwise/rename/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rename/combined` = list(
        id = "FC01/rowwise/rename/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), value = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/relocate/public` = list(
        id = "FC01/rowwise/relocate/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/relocate/original` = list(
        id = "FC01/rowwise/relocate/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/relocate/lineage` = list(
        id = "FC01/rowwise/relocate/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/relocate/repeated` = list(
        id = "FC01/rowwise/relocate/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/relocate/combined` = list(
        id = "FC01/rowwise/relocate/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), z = list(kind = "list", 
                attributes = NULL, values = list(list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 1L))), list(kind = "list", attributes = list(
                  names = "v"), values = list(v = list(kind = "integer", 
                  attributes = NULL, values = 2L))), list(kind = "list", 
                  attributes = list(names = "v"), values = list(
                    v = list(kind = "integer", attributes = NULL, 
                      values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/ungroup/public` = list(
        id = "FC01/rowwise/ungroup/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/ungroup/original` = list(
        id = "FC01/rowwise/ungroup/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/ungroup/lineage` = list(
        id = "FC01/rowwise/ungroup/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/ungroup/repeated` = list(
        id = "FC01/rowwise/ungroup/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/ungroup/combined` = list(
        id = "FC01/rowwise/ungroup/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rowwise/public` = list(
        id = "FC01/rowwise/rowwise/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rowwise/original` = list(
        id = "FC01/rowwise/rowwise/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rowwise/lineage` = list(
        id = "FC01/rowwise/rowwise/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rowwise/repeated` = list(
        id = "FC01/rowwise/rowwise/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/rowwise/rowwise/combined` = list(
        id = "FC01/rowwise/rowwise/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "rowwise_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  g = structure(c("a", "b", "a"), stata.string.storage = "str1"), 
                  .rows = structure(list(1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ))), columns = list(g = list(kind = "character", 
                attributes = list(stata.string.storage = "str1"), 
                values = c("a", "b", "a")), x = list(kind = "double", 
                attributes = list(label = "payload", stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), z = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/select/public` = list(
        id = "FC01/empty/select/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("g", 
        "x"), row.names = integer(0), class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(g = list(
            kind = "character", attributes = list(stata.string.storage = "str1"), 
            values = character(0)), x = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = numeric(0)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/select/original` = list(
        id = "FC01/empty/select/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/select/lineage` = list(
        id = "FC01/empty/select/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/select/repeated` = list(
        id = "FC01/empty/select/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/select/combined` = list(
        id = "FC01/empty/select/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rename/public` = list(
        id = "FC01/empty/rename/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("g", 
        "value", "z"), row.names = integer(0), class = c("dibble", 
        "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rename/original` = list(
        id = "FC01/empty/rename/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), value = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rename/lineage` = list(
        id = "FC01/empty/rename/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), value = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rename/repeated` = list(
        id = "FC01/empty/rename/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), value = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rename/combined` = list(
        id = "FC01/empty/rename/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "value", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), value = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/relocate/public` = list(
        id = "FC01/empty/relocate/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), z = list(kind = "list", 
                attributes = NULL, values = list()))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/relocate/original` = list(
        id = "FC01/empty/relocate/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), z = list(kind = "list", 
                attributes = NULL, values = list()))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/relocate/lineage` = list(
        id = "FC01/empty/relocate/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), z = list(kind = "list", 
                attributes = NULL, values = list()))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/relocate/repeated` = list(
        id = "FC01/empty/relocate/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), z = list(kind = "list", 
                attributes = NULL, values = list()))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/relocate/combined` = list(
        id = "FC01/empty/relocate/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("x", "g", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(x = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), z = list(kind = "list", 
                attributes = NULL, values = list()))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/ungroup/public` = list(
        id = "FC01/empty/ungroup/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/ungroup/original` = list(
        id = "FC01/empty/ungroup/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/ungroup/lineage` = list(
        id = "FC01/empty/ungroup/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/ungroup/repeated` = list(
        id = "FC01/empty/ungroup/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/ungroup/combined` = list(
        id = "FC01/empty/ungroup/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rowwise/public` = list(
        id = "FC01/empty/rowwise/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                0L), class = c("tbl_df", "tbl", "data.frame"))), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                x = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), z = list(
                  kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rowwise/original` = list(
        id = "FC01/empty/rowwise/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                0L), class = c("tbl_df", "tbl", "data.frame"))), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                x = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), z = list(
                  kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rowwise/lineage` = list(
        id = "FC01/empty/rowwise/lineage", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                0L), class = c("tbl_df", "tbl", "data.frame"))), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                x = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), z = list(
                  kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rowwise/repeated` = list(
        id = "FC01/empty/rowwise/repeated", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                0L), class = c("tbl_df", "tbl", "data.frame"))), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                x = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), z = list(
                  kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC01/empty/rowwise/combined` = list(
        id = "FC01/empty/rowwise/combined", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "rowwise_df", 
                "tbl_df", "tbl", "data.frame"), groups = structure(list(
                  .rows = structure(list(), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                0L), class = c("tbl_df", "tbl", "data.frame"))), 
            columns = list(g = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = character(0)), 
                x = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), z = list(
                  kind = "list", attributes = NULL, values = list()))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("g", "x", "z"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(g = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = character(0)), x = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = numeric(0)), 
                z = list(kind = "list", attributes = NULL, values = list()))))), 
        details = list(dibble = TRUE, valid = TRUE)), `FC02/numeric/original` = list(
        id = "FC02/numeric/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "atomic sibling", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "atomic sibling", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), c = list(kind = "double", 
            attributes = list(label = "atomic sibling", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), details = list(
            preparation_names = c("a", "c"), repeated_identity = TRUE)), 
    `FC02/numeric/lineage` = list(id = "FC02/numeric/lineage", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "atomic sibling", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "atomic sibling", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), c = list(kind = "double", 
            attributes = list(label = "atomic sibling", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), details = list(
            preparation_names = c("a", "c"), repeated_identity = TRUE)), 
    `FC02/numeric/repeated` = list(id = "FC02/numeric/repeated", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "atomic sibling", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "atomic sibling", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), c = list(kind = "double", 
            attributes = list(label = "atomic sibling", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), details = list(
            preparation_names = c("a", "c"), repeated_identity = TRUE)), 
    `FC02/numeric/combined` = list(id = "FC02/numeric/combined", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "atomic sibling", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "atomic sibling", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), c = list(kind = "double", 
            attributes = list(label = "atomic sibling", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)), c = list(kind = "double", 
                attributes = list(label = "atomic sibling"), 
                values = c(1, 2, 3)))), list(kind = "frame", 
                attributes = list(names = "seed", row.names = 1:3, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(seed = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2, 3)))))), details = list(
            preparation_names = c("a", "c"), repeated_identity = TRUE)), 
    `FC02/owned/original` = list(id = "FC02/owned/original", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "logical", attributes = NULL, values = c(TRUE, 
            FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
            values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
            attributes = NULL, values = c(TRUE, FALSE, TRUE)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "logical", attributes = NULL, values = c(TRUE, 
                FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                attributes = NULL, values = c(TRUE, FALSE, TRUE
                )))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "logical", attributes = NULL, values = c(TRUE, 
                  FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                  values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                  attributes = NULL, values = c(TRUE, FALSE, 
                  TRUE)))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/owned/lineage` = list(
        id = "FC02/owned/lineage", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "logical", attributes = NULL, values = c(TRUE, 
            FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
            values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
            attributes = NULL, values = c(TRUE, FALSE, TRUE)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "logical", attributes = NULL, values = c(TRUE, 
                FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                attributes = NULL, values = c(TRUE, FALSE, TRUE
                )))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "logical", attributes = NULL, values = c(TRUE, 
                  FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                  values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                  attributes = NULL, values = c(TRUE, FALSE, 
                  TRUE)))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/owned/repeated` = list(
        id = "FC02/owned/repeated", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "logical", attributes = NULL, values = c(TRUE, 
            FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
            values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
            attributes = NULL, values = c(TRUE, FALSE, TRUE)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "logical", attributes = NULL, values = c(TRUE, 
                FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                attributes = NULL, values = c(TRUE, FALSE, TRUE
                )))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "logical", attributes = NULL, values = c(TRUE, 
                  FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                  values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                  attributes = NULL, values = c(TRUE, FALSE, 
                  TRUE)))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/owned/combined` = list(
        id = "FC02/owned/combined", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "logical", attributes = NULL, values = c(TRUE, 
            FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
            values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
            attributes = NULL, values = c(TRUE, FALSE, TRUE)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "logical", attributes = NULL, values = c(TRUE, 
                FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                attributes = NULL, values = c(TRUE, FALSE, TRUE
                )))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "logical", attributes = NULL, values = c(TRUE, 
                  FALSE, TRUE)), b = list(kind = "logical", attributes = NULL, 
                  values = c(TRUE, FALSE, TRUE)), c = list(kind = "logical", 
                  attributes = NULL, values = c(TRUE, FALSE, 
                  TRUE)))), list(kind = "frame", attributes = list(
                names = "seed", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(seed = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/nested/original` = list(
        id = "FC02/nested/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "list", attributes = list(names = "v"), 
                values = list(v = list(kind = "integer", attributes = NULL, 
                  values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), b = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), c = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), b = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), c = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  b = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  c = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/nested/lineage` = list(
        id = "FC02/nested/lineage", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "list", attributes = list(names = "v"), 
                values = list(v = list(kind = "integer", attributes = NULL, 
                  values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), b = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), c = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), b = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), c = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  b = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  c = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/nested/repeated` = list(
        id = "FC02/nested/repeated", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "list", attributes = list(names = "v"), 
                values = list(v = list(kind = "integer", attributes = NULL, 
                  values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), b = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), c = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), b = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), c = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  b = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  c = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/nested/combined` = list(
        id = "FC02/nested/combined", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b", "c"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "list", attributes = NULL, values = list(list(
                kind = "list", attributes = list(names = "v"), 
                values = list(v = list(kind = "integer", attributes = NULL, 
                  values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), b = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))), c = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 1L))), list(kind = "list", attributes = list(
                names = "v"), values = list(v = list(kind = "integer", 
                attributes = NULL, values = 2L))), list(kind = "list", 
                attributes = list(names = "v"), values = list(
                  v = list(kind = "integer", attributes = NULL, 
                    values = 3L))))))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), b = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))), c = list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 2L))), list(
                    kind = "list", attributes = list(names = "v"), 
                    values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b", "c"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  b = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))), 
                  c = list(kind = "list", attributes = NULL, 
                    values = list(list(kind = "list", attributes = list(
                      names = "v"), values = list(v = list(kind = "integer", 
                      attributes = NULL, values = 1L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 2L))), list(
                      kind = "list", attributes = list(names = "v"), 
                      values = list(v = list(kind = "integer", 
                        attributes = NULL, values = 3L))))))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = c("a", 
        "c"), repeated_identity = TRUE)), `FC02/zero/original` = list(
        id = "FC02/zero/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = character(0), 
            row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = character(0), 
                  row.names = 1:3, class = c("tbl_df", "tbl", 
                  "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = character(0), 
            repeated_identity = NULL)), `FC02/zero/lineage` = list(
        id = "FC02/zero/lineage", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = character(0), 
            row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = character(0), 
                  row.names = 1:3, class = c("tbl_df", "tbl", 
                  "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = character(0), 
            repeated_identity = NULL)), `FC02/zero/repeated` = list(
        id = "FC02/zero/repeated", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = character(0), 
            row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = character(0), 
                  row.names = 1:3, class = c("tbl_df", "tbl", 
                  "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = character(0), 
            repeated_identity = NULL)), `FC02/zero/combined` = list(
        id = "FC02/zero/combined", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = character(0), 
            row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = character(0), 
                  row.names = 1:3, class = c("tbl_df", "tbl", 
                  "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = "seed", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  seed = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))))), details = list(preparation_names = character(0), 
            repeated_identity = NULL)), `FC03/numeric/original` = list(
        id = "FC03/numeric/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "double"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "double"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "double"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "atomic metadata"))), values = list(
                  kind = "double", attributes = NULL, values = c(1, 
                  2)))), expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "double"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "atomic metadata"))), values = list(
                  kind = "double", attributes = NULL, values = c(1, 
                  2)))), sibling_identity = list(kind = "NULL", 
                attributes = NULL, values = NULL))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list()), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list())), 
    `FC03/character/original` = list(id = "FC03/character/original", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "character"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "character"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "character"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "character metadata"))), values = list(
                  kind = "character", attributes = NULL, values = c("a", 
                  "b")))), expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "character"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "character metadata"))), values = list(
                  kind = "character", attributes = NULL, values = c("a", 
                  "b")))), sibling_identity = list(kind = "NULL", 
                attributes = NULL, values = NULL))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list()), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list())), 
    `FC03/pairlist/original` = list(id = "FC03/pairlist/original", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "pairlist"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "pairlist"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "list", 
                  attributes = list(names = "names"), values = list(
                    names = list(kind = "character", attributes = NULL, 
                      values = c("a", "b")))), values = list(
                  kind = "list", attributes = list(names = c("a", 
                  "b")), values = list(a = list(kind = "list", 
                    attributes = list(names = c("kind", "attributes", 
                    "values")), values = list(kind = list(kind = "character", 
                      attributes = NULL, values = "integer"), 
                      attributes = list(kind = "NULL", attributes = NULL, 
                        values = NULL), values = list(kind = "integer", 
                        attributes = NULL, values = 1L))), b = list(
                    kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "integer"), attributes = list(
                      kind = "NULL", attributes = NULL, values = NULL), 
                      values = list(kind = "integer", attributes = NULL, 
                        values = 2L))))))), expected = list(kind = "list", 
                attributes = list(names = c("kind", "attributes", 
                "values")), values = list(kind = list(kind = "character", 
                  attributes = NULL, values = "list"), attributes = list(
                  kind = "list", attributes = list(names = "names"), 
                  values = list(names = list(kind = "character", 
                    attributes = NULL, values = c("a", "b")))), 
                  values = list(kind = "list", attributes = list(
                    names = c("a", "b")), values = list(a = list(
                    kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "integer"), attributes = list(
                      kind = "NULL", attributes = NULL, values = NULL), 
                      values = list(kind = "integer", attributes = NULL, 
                        values = 1L))), b = list(kind = "list", 
                    attributes = list(names = c("kind", "attributes", 
                    "values")), values = list(kind = list(kind = "character", 
                      attributes = NULL, values = "integer"), 
                      attributes = list(kind = "NULL", attributes = NULL, 
                        values = NULL), values = list(kind = "integer", 
                        attributes = NULL, values = 2L))))))), 
            sibling_identity = list(kind = "NULL", attributes = NULL, 
                values = NULL))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC03/environment/original` = list(
        id = "FC03/environment/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "list", 
            attributes = list(names = c("opaque", "input_typeof", 
            "output_typeof", "same_identity", "semantic", "expected", 
            "sibling_identity")), values = list(opaque = list(
                kind = "logical", attributes = NULL, values = TRUE), 
                input_typeof = list(kind = "character", attributes = NULL, 
                  values = "environment"), output_typeof = list(
                  kind = "character", attributes = NULL, values = "environment"), 
                same_identity = list(kind = "logical", attributes = NULL, 
                  values = TRUE), semantic = list(kind = "NULL", 
                  attributes = NULL, values = NULL), expected = list(
                  kind = "NULL", attributes = NULL, values = NULL), 
                sibling_identity = list(kind = "NULL", attributes = NULL, 
                  values = NULL))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC03/closure/original` = list(
        id = "FC03/closure/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = TRUE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "closure"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "closure"), same_identity = list(
                kind = "logical", attributes = NULL, values = TRUE), 
            semantic = list(kind = "NULL", attributes = NULL, 
                values = NULL), expected = list(kind = "NULL", 
                attributes = NULL, values = NULL), sibling_identity = list(
                kind = "NULL", attributes = NULL, values = NULL))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list()), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list())), `FC03/siblings/original` = list(
        id = "FC03/siblings/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "list"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "list"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "NULL", 
                  attributes = NULL, values = NULL), values = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "list"), attributes = list(kind = "NULL", 
                      attributes = NULL, values = NULL), values = list(
                      kind = "list", attributes = NULL, values = list(
                        list(kind = "list", attributes = list(
                          names = c("kind", "attributes", "values"
                          )), values = list(kind = list(kind = "character", 
                          attributes = NULL, values = "list"), 
                          attributes = list(kind = "list", attributes = list(
                            names = "names"), values = list(names = list(
                            kind = "character", attributes = NULL, 
                            values = "value"))), values = list(
                            kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))), list(
                      kind = "list", attributes = list(names = c("kind", 
                      "attributes", "values")), values = list(
                        kind = list(kind = "character", attributes = NULL, 
                          values = "list"), attributes = list(
                          kind = "NULL", attributes = NULL, values = NULL), 
                        values = list(kind = "list", attributes = NULL, 
                          values = list(list(kind = "list", attributes = list(
                            names = c("kind", "attributes", "values"
                            )), values = list(kind = list(kind = "character", 
                            attributes = NULL, values = "list"), 
                            attributes = list(kind = "list", 
                              attributes = list(names = "names"), 
                              values = list(names = list(kind = "character", 
                                attributes = NULL, values = "value"))), 
                            values = list(kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))))))), 
            expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "NULL", 
                  attributes = NULL, values = NULL), values = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "list"), attributes = list(kind = "NULL", 
                      attributes = NULL, values = NULL), values = list(
                      kind = "list", attributes = NULL, values = list(
                        list(kind = "list", attributes = list(
                          names = c("kind", "attributes", "values"
                          )), values = list(kind = list(kind = "character", 
                          attributes = NULL, values = "list"), 
                          attributes = list(kind = "list", attributes = list(
                            names = "names"), values = list(names = list(
                            kind = "character", attributes = NULL, 
                            values = "value"))), values = list(
                            kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))), list(
                      kind = "list", attributes = list(names = c("kind", 
                      "attributes", "values")), values = list(
                        kind = list(kind = "character", attributes = NULL, 
                          values = "list"), attributes = list(
                          kind = "NULL", attributes = NULL, values = NULL), 
                        values = list(kind = "list", attributes = NULL, 
                          values = list(list(kind = "list", attributes = list(
                            names = c("kind", "attributes", "values"
                            )), values = list(kind = list(kind = "character", 
                            attributes = NULL, values = "list"), 
                            attributes = list(kind = "list", 
                              attributes = list(names = "names"), 
                              values = list(names = list(kind = "character", 
                                attributes = NULL, values = "value"))), 
                            values = list(kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))))))), 
            sibling_identity = list(kind = "logical", attributes = NULL, 
                values = TRUE))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC03/numeric/atomic` = list(
        id = "FC03/numeric/atomic", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "double"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "double"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "double"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "atomic metadata"))), values = list(
                  kind = "double", attributes = NULL, values = c(1, 
                  2)))), expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "double"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "atomic metadata"))), values = list(
                  kind = "double", attributes = NULL, values = c(1, 
                  2)))), sibling_identity = list(kind = "NULL", 
                attributes = NULL, values = NULL))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list()), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list())), 
    `FC03/character/atomic` = list(id = "FC03/character/atomic", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "character"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "character"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "character"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "character metadata"))), values = list(
                  kind = "character", attributes = NULL, values = c("a", 
                  "b")))), expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "character"), attributes = list(kind = "list", 
                  attributes = list(names = "label"), values = list(
                    label = list(kind = "character", attributes = NULL, 
                      values = "character metadata"))), values = list(
                  kind = "character", attributes = NULL, values = c("a", 
                  "b")))), sibling_identity = list(kind = "NULL", 
                attributes = NULL, values = NULL))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list()), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list())), 
    `FC03/pairlist/atomic` = list(id = "FC03/pairlist/atomic", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "pairlist"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "pairlist"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "list", 
                  attributes = list(names = "names"), values = list(
                    names = list(kind = "character", attributes = NULL, 
                      values = c("a", "b")))), values = list(
                  kind = "list", attributes = list(names = c("a", 
                  "b")), values = list(a = list(kind = "list", 
                    attributes = list(names = c("kind", "attributes", 
                    "values")), values = list(kind = list(kind = "character", 
                      attributes = NULL, values = "integer"), 
                      attributes = list(kind = "NULL", attributes = NULL, 
                        values = NULL), values = list(kind = "integer", 
                        attributes = NULL, values = 1L))), b = list(
                    kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "integer"), attributes = list(
                      kind = "NULL", attributes = NULL, values = NULL), 
                      values = list(kind = "integer", attributes = NULL, 
                        values = 2L))))))), expected = list(kind = "list", 
                attributes = list(names = c("kind", "attributes", 
                "values")), values = list(kind = list(kind = "character", 
                  attributes = NULL, values = "list"), attributes = list(
                  kind = "list", attributes = list(names = "names"), 
                  values = list(names = list(kind = "character", 
                    attributes = NULL, values = c("a", "b")))), 
                  values = list(kind = "list", attributes = list(
                    names = c("a", "b")), values = list(a = list(
                    kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "integer"), attributes = list(
                      kind = "NULL", attributes = NULL, values = NULL), 
                      values = list(kind = "integer", attributes = NULL, 
                        values = 1L))), b = list(kind = "list", 
                    attributes = list(names = c("kind", "attributes", 
                    "values")), values = list(kind = list(kind = "character", 
                      attributes = NULL, values = "integer"), 
                      attributes = list(kind = "NULL", attributes = NULL, 
                        values = NULL), values = list(kind = "integer", 
                        attributes = NULL, values = 2L))))))), 
            sibling_identity = list(kind = "NULL", attributes = NULL, 
                values = NULL))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC03/environment/atomic` = list(
        id = "FC03/environment/atomic", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = TRUE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "environment"), output_typeof = list(
                kind = "character", attributes = NULL, values = "environment"), 
            same_identity = list(kind = "logical", attributes = NULL, 
                values = TRUE), semantic = list(kind = "NULL", 
                attributes = NULL, values = NULL), expected = list(
                kind = "NULL", attributes = NULL, values = NULL), 
            sibling_identity = list(kind = "NULL", attributes = NULL, 
                values = NULL))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC03/closure/atomic` = list(
        id = "FC03/closure/atomic", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = TRUE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "closure"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "closure"), same_identity = list(
                kind = "logical", attributes = NULL, values = TRUE), 
            semantic = list(kind = "NULL", attributes = NULL, 
                values = NULL), expected = list(kind = "NULL", 
                attributes = NULL, values = NULL), sibling_identity = list(
                kind = "NULL", attributes = NULL, values = NULL))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list()), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list())), `FC03/siblings/atomic` = list(id = "FC03/siblings/atomic", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("opaque", 
        "input_typeof", "output_typeof", "same_identity", "semantic", 
        "expected", "sibling_identity")), values = list(opaque = list(
            kind = "logical", attributes = NULL, values = FALSE), 
            input_typeof = list(kind = "character", attributes = NULL, 
                values = "list"), output_typeof = list(kind = "character", 
                attributes = NULL, values = "list"), same_identity = list(
                kind = "logical", attributes = NULL, values = FALSE), 
            semantic = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "NULL", 
                  attributes = NULL, values = NULL), values = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "list"), attributes = list(kind = "NULL", 
                      attributes = NULL, values = NULL), values = list(
                      kind = "list", attributes = NULL, values = list(
                        list(kind = "list", attributes = list(
                          names = c("kind", "attributes", "values"
                          )), values = list(kind = list(kind = "character", 
                          attributes = NULL, values = "list"), 
                          attributes = list(kind = "list", attributes = list(
                            names = "names"), values = list(names = list(
                            kind = "character", attributes = NULL, 
                            values = "value"))), values = list(
                            kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))), list(
                      kind = "list", attributes = list(names = c("kind", 
                      "attributes", "values")), values = list(
                        kind = list(kind = "character", attributes = NULL, 
                          values = "list"), attributes = list(
                          kind = "NULL", attributes = NULL, values = NULL), 
                        values = list(kind = "list", attributes = NULL, 
                          values = list(list(kind = "list", attributes = list(
                            names = c("kind", "attributes", "values"
                            )), values = list(kind = list(kind = "character", 
                            attributes = NULL, values = "list"), 
                            attributes = list(kind = "list", 
                              attributes = list(names = "names"), 
                              values = list(names = list(kind = "character", 
                                attributes = NULL, values = "value"))), 
                            values = list(kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))))))), 
            expected = list(kind = "list", attributes = list(
                names = c("kind", "attributes", "values")), values = list(
                kind = list(kind = "character", attributes = NULL, 
                  values = "list"), attributes = list(kind = "NULL", 
                  attributes = NULL, values = NULL), values = list(
                  kind = "list", attributes = NULL, values = list(
                    list(kind = "list", attributes = list(names = c("kind", 
                    "attributes", "values")), values = list(kind = list(
                      kind = "character", attributes = NULL, 
                      values = "list"), attributes = list(kind = "NULL", 
                      attributes = NULL, values = NULL), values = list(
                      kind = "list", attributes = NULL, values = list(
                        list(kind = "list", attributes = list(
                          names = c("kind", "attributes", "values"
                          )), values = list(kind = list(kind = "character", 
                          attributes = NULL, values = "list"), 
                          attributes = list(kind = "list", attributes = list(
                            names = "names"), values = list(names = list(
                            kind = "character", attributes = NULL, 
                            values = "value"))), values = list(
                            kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))), list(
                      kind = "list", attributes = list(names = c("kind", 
                      "attributes", "values")), values = list(
                        kind = list(kind = "character", attributes = NULL, 
                          values = "list"), attributes = list(
                          kind = "NULL", attributes = NULL, values = NULL), 
                        values = list(kind = "list", attributes = NULL, 
                          values = list(list(kind = "list", attributes = list(
                            names = c("kind", "attributes", "values"
                            )), values = list(kind = list(kind = "character", 
                            attributes = NULL, values = "list"), 
                            attributes = list(kind = "list", 
                              attributes = list(names = "names"), 
                              values = list(names = list(kind = "character", 
                                attributes = NULL, values = "value"))), 
                            values = list(kind = "list", attributes = list(
                              names = "value"), values = list(
                              value = list(kind = "list", attributes = list(
                                names = c("kind", "attributes", 
                                "values")), values = list(kind = list(
                                kind = "character", attributes = NULL, 
                                values = "integer"), attributes = list(
                                kind = "NULL", attributes = NULL, 
                                values = NULL), values = list(
                                kind = "integer", attributes = NULL, 
                                values = 1:2))))))))))))))), 
            sibling_identity = list(kind = "logical", attributes = NULL, 
                values = TRUE))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC04/original` = list(
        id = "FC04/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("message", 
        "healthy", "constants", "R", "R_home", "package_path", 
        "namespaces")), values = list(message = list(kind = "character", 
            attributes = NULL, values = "Cyclic nested list or data frame values are not supported."), 
            healthy = list(kind = "list", attributes = list(names = "value"), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 1:2))), constants = list(
                kind = "integer", attributes = NULL, values = 1:0), 
            R = list(kind = "character", attributes = NULL, values = "R version 4.6.1 (2026-06-24)"), 
            R_home = list(kind = "character", attributes = NULL, 
                values = "/opt/homebrew/Cellar/r/4.6.1/lib/R"), 
            package_path = list(kind = "character", attributes = NULL, 
                values = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"), 
            namespaces = list(kind = "character", attributes = NULL, 
                values = c("dtatools", "compiler", "cli", "graphics", 
                "pillar", "glue", "utils", "grDevices", "stats", 
                "datasets", "vctrs", "methods", "lifecycle", 
                "rlang", "base")))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC04/atomic` = list(
        id = "FC04/atomic", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = list(names = c("message", 
        "healthy", "constants", "R", "R_home", "package_path", 
        "namespaces")), values = list(message = list(kind = "character", 
            attributes = NULL, values = "Cyclic nested list or data frame values are not supported."), 
            healthy = list(kind = "list", attributes = list(names = "value"), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 1:2))), constants = list(
                kind = "integer", attributes = NULL, values = 1:0), 
            R = list(kind = "character", attributes = NULL, values = "R version 4.6.1 (2026-06-24)"), 
            R_home = list(kind = "character", attributes = NULL, 
                values = "/opt/homebrew/Cellar/r/4.6.1/lib/R"), 
            package_path = list(kind = "character", attributes = NULL, 
                values = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"), 
            namespaces = list(kind = "character", attributes = NULL, 
                values = c("dtatools", "compiler", "cli", "graphics", 
                "pillar", "glue", "utils", "grDevices", "stats", 
                "datasets", "vctrs", "methods", "lifecycle", 
                "rlang", "base")))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list()), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list())), `FC05/frame/public` = list(
        id = "FC05/frame/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "same source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "same source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), details = list(valid = TRUE, alias = FALSE)), 
    `FC05/frame/original` = list(id = "FC05/frame/original", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "same source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "same source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), details = list(valid = TRUE, alias = FALSE)), 
    `FC05/frame/hash` = list(id = "FC05/frame/hash", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("a", "b"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "same source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "same source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), class = "data.frame", row.names = 1:3), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)), 
                  b = list(kind = "double", attributes = list(
                    label = "same source"), values = c(1, 2, 
                  3)))))), details = list(valid = TRUE, alias = FALSE)), 
    `FC05/tibble/public` = list(id = "FC05/tibble/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("a", "b"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "same source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "same source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "same source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "same source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(a = list(kind = "double", 
                  attributes = list(label = "same source"), values = c(1, 
                  2, 3)), b = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)))))), 
        details = list(valid = TRUE, alias = FALSE)), `FC05/tibble/original` = list(
        id = "FC05/tibble/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "same source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "same source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "same source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "same source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(a = list(kind = "double", 
                  attributes = list(label = "same source"), values = c(1, 
                  2, 3)), b = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)))))), 
        details = list(valid = TRUE, alias = FALSE)), `FC05/tibble/hash` = list(
        id = "FC05/tibble/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "same source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "same source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "same source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "same source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(a = list(kind = "double", 
                  attributes = list(label = "same source"), values = c(1, 
                  2, 3)), b = list(kind = "double", attributes = list(
                  label = "same source"), values = c(1, 2, 3)))))), 
        details = list(valid = TRUE, alias = FALSE)), `FC05/grouped/public` = list(
        id = "FC05/grouped/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(groups = structure(list(
            g = structure(1:2, levels = c("a", "b"), class = "factor"), 
            .rows = structure(list(1:2, integer(0)), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
        -2L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
            names = c("g", "x"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", 
            "data.frame")), columns = list(g = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = "factor"), 
            values = c(1L, 1L)), x = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(1, 
        2)))), inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), details = list(
            valid = TRUE, alias = FALSE)), `FC05/grouped/original` = list(
        id = "FC05/grouped/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(groups = structure(list(
            g = structure(1:2, levels = c("a", "b"), class = "factor"), 
            .rows = structure(list(1:2, integer(0)), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
        -2L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
            names = c("g", "x"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", 
            "data.frame")), columns = list(g = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = "factor"), 
            values = c(1L, 1L)), x = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(1, 
        2)))), inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), details = list(
            valid = TRUE, alias = FALSE)), `FC05/grouped/hash` = list(
        id = "FC05/grouped/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(groups = structure(list(
            g = structure(1:2, levels = c("a", "b"), class = "factor"), 
            .rows = structure(list(1:2, integer(0)), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
        -2L), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
            names = c("g", "x"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "grouped_df", "tbl_df", "tbl", 
            "data.frame")), columns = list(g = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = "factor"), 
            values = c(1L, 1L)), x = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(1, 
        2)))), inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(g = structure(1:2, levels = c("a", 
                "b"), class = "factor"), .rows = structure(list(
                  1:2, integer(0)), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"), ptype = integer(0))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = FALSE), names = c("g", "x"), row.names = 1:2, 
                class = c("grouped_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(g = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = c(1L, 1L)), x = list(kind = "double", 
                attributes = NULL, values = c(1, 2)))))), details = list(
            valid = TRUE, alias = FALSE)), `FC05/stale/public` = list(
        id = "FC05/stale/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")), b = list(kind = "character", 
            attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), details = list(
            valid = TRUE, alias = FALSE)), `FC05/stale/original` = list(
        id = "FC05/stale/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")), b = list(kind = "character", 
            attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), details = list(
            valid = TRUE, alias = FALSE)), `FC05/stale/hash` = list(
        id = "FC05/stale/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")), b = list(kind = "character", 
            attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), details = list(
            valid = TRUE, alias = FALSE)), `FC06/original` = list(
        id = "FC06/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")), b = list(kind = "character", 
            attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), details = list(
            list(index = 1L, same_physical = TRUE, value = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("", "widened"))), list(index = 2L, 
                same_physical = TRUE, value = list(kind = "character", 
                  attributes = list(stata.string.storage = "str7"), 
                  values = c("", "widened"))))), `FC06/hash` = list(
        id = "FC06/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")), b = list(kind = "character", 
            attributes = list(stata.string.storage = "str7"), 
            values = c("", "widened")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "character", attributes = list(class = "dta_string", 
                  stata.string.storage = "str1"), values = c(NA, 
                "widened")), b = list(kind = "character", attributes = list(
                class = "dta_string", stata.string.storage = "str1"), 
                values = c(NA, "widened")))))), details = list(
            list(index = 1L, same_physical = TRUE, value = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("", "widened"))), list(index = 2L, 
                same_physical = TRUE, value = list(kind = "character", 
                  attributes = list(stata.string.storage = "str7"), 
                  values = c("", "widened"))))), `FC07/frame/public` = list(
        id = "FC07/frame/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = "data.frame"), columns = list(
            a = list(kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), details = list(alias = TRUE, capacity = TRUE)), 
    `FC07/frame/original` = list(id = "FC07/frame/original", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = "data.frame"), columns = list(
            a = list(kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), details = list(alias = TRUE, capacity = TRUE)), 
    `FC07/frame/hash` = list(id = "FC07/frame/hash", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("a", "b"), row.names = 1:3, 
                class = "data.frame"), columns = list(a = list(
                kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = "data.frame"), 
                columns = list(a = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                  label = "shared reserve source"), values = c(1, 
                2, 3)))))), details = list(alias = TRUE, capacity = TRUE)), 
    `FC07/tibble/public` = list(id = "FC07/tibble/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("a", "b"), row.names = 1:3, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                a = list(kind = "double", attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)), b = list(kind = "double", 
                  attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))))), details = list(alias = TRUE, 
            capacity = TRUE)), `FC07/tibble/original` = list(
        id = "FC07/tibble/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("tbl_df", "tbl", "data.frame"
        )), columns = list(a = list(kind = "double", attributes = list(
            label = "shared reserve source"), values = c(1, 2, 
        3)), b = list(kind = "double", attributes = list(label = "shared reserve source"), 
            values = c(1, 2, 3)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(a = list(kind = "double", 
                  attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)), b = list(kind = "double", 
                  attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))))), details = list(alias = TRUE, 
            capacity = TRUE)), `FC07/tibble/hash` = list(id = "FC07/tibble/hash", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("tbl_df", "tbl", "data.frame"
        )), columns = list(a = list(kind = "double", attributes = list(
            label = "shared reserve source"), values = c(1, 2, 
        3)), b = list(kind = "double", attributes = list(label = "shared reserve source"), 
            values = c(1, 2, 3)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("a", 
                "b"), row.names = 1:3, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(a = list(kind = "double", 
                  attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)), b = list(kind = "double", 
                  attributes = list(label = "shared reserve source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(a = list(
                kind = "double", attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)), b = list(kind = "double", 
                attributes = list(label = "shared reserve source"), 
                values = c(1, 2, 3)))))), details = list(alias = TRUE, 
            capacity = TRUE)), `FC07/dibble/public` = list(id = "FC07/dibble/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "shared reserve source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC07/dibble/original` = list(
        id = "FC07/dibble/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "shared reserve source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC07/dibble/hash` = list(
        id = "FC07/dibble/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(a = list(
            kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
            label = "shared reserve source", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC07/grouped/public` = list(
        id = "FC07/grouped/public", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), groups = structure(list(
            a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = TRUE)), columns = list(
            a = list(kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC07/grouped/original` = list(
        id = "FC07/grouped/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), groups = structure(list(
            a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = TRUE)), columns = list(
            a = list(kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC07/grouped/hash` = list(
        id = "FC07/grouped/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("a", 
        "b"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "grouped_df", "tbl_df", "tbl", "data.frame"), groups = structure(list(
            a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -3L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = TRUE)), columns = list(
            a = list(kind = "double", attributes = list(label = "shared reserve source", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("a", "b"), row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "grouped_df", "tbl_df", 
                "tbl", "data.frame"), groups = structure(list(
                  a = structure(c(1, 2, 3), label = "shared reserve source", stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), .rows = structure(list(
                    1L, 2L, 3L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -3L), class = c("tbl_df", "tbl", "data.frame"
                ), .drop = TRUE)), columns = list(a = list(kind = "double", 
                attributes = list(label = "shared reserve source", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(1, 
                2, 3)), b = list(kind = "double", attributes = list(
                label = "shared reserve source", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)))))), details = list(
            alias = FALSE, capacity = TRUE)), `FC08/aliases/original` = list(
        id = "FC08/aliases/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = NULL, values = list(
            list(kind = "double", attributes = list(label = "source"), 
                values = c(1, 2, 3)), list(kind = "double", attributes = list(
                label = "source"), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), details = list(column_copies = 1L, 
            null_copies = 0L, injected = FALSE, alias = TRUE)), 
    `FC08/aliases/hash` = list(id = "FC08/aliases/hash", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "double", 
                attributes = list(label = "source"), values = c(1, 
                2, 3)), list(kind = "double", attributes = list(
                label = "source"), values = c(1, 2, 3)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), details = list(column_copies = 1L, 
            null_copies = 0L, injected = FALSE, alias = TRUE)), 
    `FC08/null/original` = list(id = "FC08/null/original", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "list", 
            attributes = NULL, values = list(list(kind = "NULL", 
                attributes = NULL, values = NULL), list(kind = "NULL", 
                attributes = NULL, values = NULL))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "NULL", attributes = NULL, 
                  values = NULL), list(kind = "NULL", attributes = NULL, 
                  values = NULL))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "NULL", attributes = NULL, values = NULL), 
                  list(kind = "NULL", attributes = NULL, values = NULL))))), 
        details = list(column_copies = 1L, null_copies = 1L, 
            injected = FALSE, alias = TRUE)), `FC08/null/hash` = list(
        id = "FC08/null/hash", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = NULL, values = list(
            list(kind = "NULL", attributes = NULL, values = NULL), 
            list(kind = "NULL", attributes = NULL, values = NULL))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "NULL", attributes = NULL, 
                  values = NULL), list(kind = "NULL", attributes = NULL, 
                  values = NULL))))), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "list", attributes = NULL, values = list(
                  list(kind = "NULL", attributes = NULL, values = NULL), 
                  list(kind = "NULL", attributes = NULL, values = NULL))))), 
        details = list(column_copies = 1L, null_copies = 1L, 
            injected = FALSE, alias = TRUE)), `FC08/later_slot/original` = list(
        id = "FC08/later_slot/original", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = NULL, values = list(
            list(kind = "double", attributes = list(label = "source"), 
                values = c(1, 2, 3)), list(kind = "double", attributes = list(
                label = "later slot"), values = c(7, 8, 9)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), details = list(column_copies = 1L, 
            null_copies = 0L, injected = TRUE, alias = FALSE)), 
    `FC08/later_slot/hash` = list(id = "FC08/later_slot/hash", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "list", attributes = NULL, values = list(
            list(kind = "double", attributes = list(label = "source"), 
                values = c(1, 2, 3)), list(kind = "double", attributes = list(
                label = "later slot"), values = c(7, 8, 9)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "list", attributes = NULL, 
                values = list(list(kind = "double", attributes = list(
                  label = "source"), values = c(1, 2, 3)), list(
                  kind = "double", attributes = list(label = "source"), 
                  values = c(1, 2, 3)))))), details = list(column_copies = 1L, 
            null_copies = 0L, injected = TRUE, alias = FALSE)))
