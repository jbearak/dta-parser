# Diagnostic routing only: no installed namespace or S3 table is modified.
.fc_namespace <- asNamespace("dtatools")
.fc_draft <- get("draft", envir = .GlobalEnv)
.fc_rebind <- function(name, scope) {
    fn <- get(name, envir = .fc_namespace, inherits = FALSE)
    environment(fn) <- scope
    assign(name, fn, envir = scope)
    invisible(fn)
}
.fc_scope <- function(result = "original", capture = NULL,
                      constructor = NULL, reserve = NULL) {
    scope <- new.env(parent = .fc_namespace)
    sys.source(file.path(.fc_draft, paste0(result, "-result.R")), envir = scope)
    for (name in c("select.dtatools_ref_data", "rename.dtatools_ref_data",
        "relocate.dtatools_ref_data", "ungroup.dtatools_ref_data",
        "rowwise.dtatools_ref_data", ".dibble_group_result")) .fc_rebind(name, scope)
    if (!is.null(capture)) {
        sys.source(file.path(.fc_draft, paste0(capture, "-capture.R")), envir = scope)
    }
    if (!is.null(constructor)) {
        sys.source(file.path(.fc_draft, paste0(constructor, "-constructor.R")), envir = scope)
        for (name in c("as_dibble", ".as_dibble", "dibble")) .fc_rebind(name, scope)
    }
    if (!is.null(reserve)) {
        sys.source(file.path(.fc_draft, paste0(reserve, "-reserve.R")), envir = scope)
        .fc_rebind("reserve_columns", scope)
    }
    scope
}
.fc_routes <- c("public", "original", "lineage", "repeated", "combined")
.fc_condition_values <- function(record) {
    lapply(record$conditions, function(value) value[c("classes", "message")])
}
.fc_run <- function(id, expr, inputs = NULL, expected_error = FALSE) {
    # Inputs here are acyclic semantic fixtures, never closures or environments.
    before <- .s8_control_snapshot(inputs)
    if (!identical(before$status, "complete")) {
        .s8_records$values[[id]] <- list(id = id, status = "not_called",
            inputs_before = before)
        .s8_flush()
        stop("Input snapshot failed before ", id)
    }
    on.exit(.s8_flush(), add = TRUE)
    observed <- .s8_record(id, expr)
    saved <- .s8_records$values[[id]]
    saved$inputs_before <- before
    saved$inputs_after <- list(status = "pending")
    .s8_records$values[[id]] <- saved
    .s8_flush() # The completed call is durable before post-input inspection.
    saved$inputs_after <- .s8_control_snapshot(inputs)
    .s8_records$values[[id]] <- saved
    .s8_flush()
    expect_identical(saved$inputs_after$status, "complete", info = id)
    expect_identical(saved$inputs_after$value, before$value, info = id)
    expect_identical(saved$status, if (expected_error) "error" else "return", info = id)
    expect_identical(saved$snapshot_status,
        if (expected_error) "not_applicable" else "complete", info = id)
    observed$value
}
.fc_note <- function(id, details) {
    stopifnot(id %in% names(.s8_records$values))
    .s8_records$values[[id]]$details <- details
    .s8_flush()
}
.fc_parity <- function(id, reference) {
    actual <- .s8_records$values[[id]]
    expected <- .s8_records$values[[reference]]
    expect_identical(actual$status, expected$status, info = id)
    expect_identical(actual$value, expected$value, info = id)
    expect_identical(actual$error, expected$error, info = id)
    expect_identical(.fc_condition_values(actual), .fc_condition_values(expected), info = id)
}
.fc_selector_input <- function(shape) {
    data <- if (shape == "empty") dibble(g = character(), x = integer(), z = list()) else
        dibble(g = c("a", "b", "a"), x = structure(1:3, label = "payload"),
               z = list(list(v = 1L), list(v = 2L), list(v = 3L)))
    switch(shape, grouped = dplyr::group_by(data, g),
        rowwise = dplyr::rowwise(data, g), data)
}
.fc_selector_call <- function(verb, data, route, scope = NULL) {
    fn <- if (route == "public") getExportedValue("dplyr", verb) else
        get(paste0(verb, ".dtatools_ref_data"), envir = scope, inherits = FALSE)
    switch(verb,
        select = fn(data, g, x),
        rename = fn(data, value = x),
        relocate = fn(data, x, .before = g),
        ungroup = fn(data),
        rowwise = fn(data))
}
.fc_constructor_input <- function(shape) {
    shared <- structure(c(1, 2, 3), label = "same source")
    columns <- list(a = shared, b = shared)
    if (shape == "frame") return(as.data.frame(columns))
    if (shape == "tibble") return(tibble::new_tibble(columns, nrow = 3L))
    if (shape == "grouped") return(dplyr::group_by(tibble::tibble(
        g = factor(c("a", "a"), levels = c("a", "b")), x = c(1, 2)), g, .drop = FALSE))
    stale <- structure(c(NA_character_, "widened"), class = "dta_string",
        stata.string.storage = "str1")
    tibble::new_tibble(list(a = stale, b = stale), nrow = 2L)
}
.fc_reserve_input <- function(shape) {
    shared <- structure(c(1, 2, 3), label = "shared reserve source")
    data <- tibble::new_tibble(list(a = shared, b = shared), nrow = 3L)
    switch(shape, frame = as.data.frame(data), tibble = data,
        dibble = as_dibble(data), grouped = dplyr::group_by(as_dibble(data), a))
}
