Unexecuted shared-finalizer semantic controls

This diagnostic draft uses the accepted Stage8 predecessor namespace and exact copied draft02 finalizer variants. It changes no repository, installed namespace, or S3 table. No R, parsing, test, benchmark, source hashing, or config construction was performed to prepare this draft. A fresh selected-source freeze and config for the unchanged focused runner must be created after source review; this directory is not launch authorization or an accepted artifact.

All ten original/variant R files were copied as bytes from `../draft-02`. `helper-01-observations.R` is the reviewed binding draft02 recorder with only its two output basenames changed to `finalizer-observations`; `helper-02-input-snapshot.R` is the same guarded snapshot helper used by join control06. New helper/test source is original package diagnostic code. Original result/capture/constructor/reserve provenance and the source-freeze02 declarations remain in the parent preparation. No upstream attribution is added beyond those original source notices.

Nine planned blocks produce 163 top-level observation records if callr is available, or 161 plus an explicit capability skip if it is absent:

| Block | Scope | Records |
| --- | --- | ---: |
| FC00 | Copied entry/helper environments and unchanged entry/original bodies | 1 |
| FC01 | Five real selector entry bodies, four input shapes, public plus four copied result variants | 100 |
| FC02 | Repeated numeric/owned/list physical slots and zero-column results, four result variants | 16 |
| FC03 | Atomic metadata, opaque environment/closure identity, pairlist policy, shared list descendants | 12 |
| FC04 | Original/atomic cycle rejection in separate callr children, each followed by a healthy capture | 2 |
| FC05 | Public/original/hash full constructor entry, ordinary/grouped/stale-string inputs | 12 |
| FC06 | Original/hash capture argument versus actual post-normalization physical slot | 2 |
| FC07 | Public/original/hash reserve entry for ordinary/tibble/dibble/grouped inputs | 12 |
| FC08 | Original/hash direct reserve aliases, cached NULL, and a later-slot discriminator | 6 |

These are observation records, not total internal helper invocations. FC04 invokes capture twice in each of its two children. No elapsed, allocation, retention-history, or RSS measurement is included. Forced GC in a few controls checks live roots only; it is not evidence of bounded long-term retention.

The five selector methods and `.dibble_group_result` are copied into each local environment without changing their bodies. Their existing columns-context calls use `sources=NULL`; lineage removal is assessed only for that current caller contract. Constructor controls copy `as_dibble`, `.as_dibble`, and `dibble` into the same environment as the selected `.type_dibble_columns`; reserve controls copy `reserve_columns` with the selected `.isolate_shared_columns`. Body/environment assertions make those routes explicit. Returned dibbles retain the installed public methods.

Three deliberately instrumented private seams are separate from public parity. FC02 wraps only the local column-preparation helper to count preparations and force GC. FC06 intercepts only local `.Call` resolution, records capture inputs against the constructor's current physical slot, then forwards the original invocation; it makes no general forcing claim. FC08 wraps local metadata copy: the cached-NULL case uses an ordinary list, not a claim that NULL is a valid public frame column; the later-slot case writes a newly allocated numeric vector into the disposable result shell while preparing its first slot. This distinguishes per-iteration reads from an eager column snapshot. It checks the original input remains unchanged and does not modify foreign data or logical constants.

The recorder retains each completed call before post-input inspection and flushes raw RDS/readable observations before assertions. Failed snapshots remain explicit. Snapshot inputs are acyclic semantic fixtures. Environments and closures in FC03 are reduced to identity booleans before recording. Cycles stay entirely inside FC04 children and are never serialized. Each cycle child selects the parent's library paths, asserts the actual dtatools namespace path, returns its R/package/namespace observations, and retains separate stdout/stderr. This is narrower than the focused runner's outer runtime inventory: there is no independently complete child-image closure or new loader guarantee. Do not call a skipped, failed, or incomplete cycle block a pass.

Unknown callback behavior, arbitrary graphs, metadata classes beyond these fixtures, foreign-write isolation, and all performance effects remain outside this draft. The parent owns source selection/configuration and execution after independent semantic review.

Additive control-draft02 preserves unexecuted draft01. FC03 now records input/output `typeof` and explicitly checks representation, so pairlists cannot silently become ordinary lists under the generic semantic snapshot. FC05/FC07 compare recorded physical-alias booleans against each actual public route; they do not assume every grouped or normalization fixture must alias. Each FC04 child has a 60-second timeout; timeout errors pass through the existing parent recorder with child logs retained. Sources, matrices and planned counts are unchanged. No execution is implied.
