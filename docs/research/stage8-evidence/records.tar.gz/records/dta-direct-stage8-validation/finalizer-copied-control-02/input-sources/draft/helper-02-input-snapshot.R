# Exact guarded snapshot body from reviewed binding draft02, renamed locally.
.s8_control_snapshot <- function(inputs) {
    conditions <- list()
    failed <- FALSE
    value <- tryCatch(withCallingHandlers(lapply(inputs, .s8_semantic),
        warning = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleWarning")
        }, message = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleMessage")
        }), error = function(cnd) { failed <<- TRUE; cnd })
    list(status = if (failed) "error" else "complete", conditions = conditions,
         error = if (failed) .s8_condition(value) else NULL,
         value = if (failed) NULL else value)
}
