# Stage8 observations authored for this package; no upstream test text copied.
.s8_records <- new.env(parent = emptyenv())
.s8_records$values <- list()
.s8_condition <- function(cnd, depth = 0L) {
    if (is.null(cnd)) return(NULL)
    if (depth >= 8L) return(list(depth_limit = 8L))
    list(classes = class(cnd), message = conditionMessage(cnd),
         call = if (is.null(conditionCall(cnd))) NULL else
             paste(deparse(conditionCall(cnd)), collapse = "\n"),
         parent = .s8_condition(cnd$parent, depth + 1L))
}
.s8_semantic <- function(value) {
    if (is.data.frame(value)) {
        cols <- dtatools:::.data_columns(value)
        attrs <- attributes(value)
        attrs$.dtatools_ref_state <- NULL
        attrs$.internal.selfref <- NULL
        attrs$names <- names(cols)
        return(list(kind = "frame", attributes = attrs,
                    columns = lapply(cols, .s8_semantic)))
    }
    if (is.list(value)) return(list(kind = "list", attributes = attributes(value),
                                  values = lapply(value, .s8_semantic)))
    attrs <- attributes(value)
    values <- if (inherits(value, "dta_numeric")) as.double(value) else value
    attributes(values) <- NULL
    list(kind = typeof(value), attributes = attrs, values = values)
}
.s8_record <- function(id, expr) {
    stopifnot(!id %in% names(.s8_records$values))
    conditions <- list()
    value <- tryCatch(withCallingHandlers(force(expr),
        warning = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleWarning")
        }, message = function(cnd) {
            conditions[[length(conditions) + 1L]] <<- .s8_condition(cnd)
            invokeRestart("muffleMessage")
        }), error = identity)
    failed <- inherits(value, "error")
    # Save the public outcome before attempting a semantic snapshot.
    record <- list(id = id, status = if (failed) "error" else "return",
        conditions = conditions,
        error = if (failed) .s8_condition(value) else NULL,
        snapshot_status = if (failed) "not_applicable" else "pending",
        snapshot_conditions = list(), snapshot_error = NULL, value = NULL)
    .s8_records$values[[id]] <- record
    if (!failed) {
        snapshot_conditions <- list()
        snapshot_failed <- FALSE
        snapshot <- tryCatch(withCallingHandlers(.s8_semantic(value),
            warning = function(cnd) {
                snapshot_conditions[[length(snapshot_conditions) + 1L]] <<-
                    .s8_condition(cnd)
                invokeRestart("muffleWarning")
            }, message = function(cnd) {
                snapshot_conditions[[length(snapshot_conditions) + 1L]] <<-
                    .s8_condition(cnd)
                invokeRestart("muffleMessage")
            }), error = function(cnd) {
                snapshot_failed <<- TRUE
                cnd
            })
        record$snapshot_status <- if (snapshot_failed) "error" else "complete"
        record$snapshot_conditions <- snapshot_conditions
        record$snapshot_error <- if (snapshot_failed) .s8_condition(snapshot) else NULL
        record$value <- if (snapshot_failed) NULL else snapshot
        .s8_records$values[[id]] <- record
    }
    list(ok = !failed, value = value)
}
.s8_flush <- function() {
    # The unchanged guarded test entry supplies this retained output directory.
    directory <- get("out", envir = .GlobalEnv)
    saveRDS(.s8_records$values, file.path(directory, "finalizer-observations.rds"))
    dput(.s8_records$values, file.path(directory, "finalizer-observations.R"))
    incomplete <- vapply(.s8_records$values, function(record) {
        identical(record$status, "return") &&
            !identical(record$snapshot_status, "complete")
    }, logical(1))
    if (any(incomplete)) stop("Incomplete semantic snapshots: ",
        paste(names(.s8_records$values)[incomplete], collapse = ", "))
}
.s8_frame <- function(kind, columns) {
    switch(kind, dibble = do.call(dibble, columns),
        tibble = tibble::as_tibble(columns),
        frame = as.data.frame(columns, stringsAsFactors = FALSE))
}
.s8_rows <- function(x, y, type, matching = outer(x, y, "==")) {
    left <- right <- integer()
    for (i in seq_along(x)) {
        matches <- which(matching[i, ])
        if (length(matches)) {
            left <- c(left, rep.int(i, length(matches)))
            right <- c(right, matches)
        } else if (type %in% c("left", "full")) {
            left <- c(left, i); right <- c(right, NA_integer_)
        }
    }
    if (type %in% c("right", "full")) {
        missing <- which(!seq_along(y) %in% right)
        left <- c(left, rep.int(NA_integer_, length(missing)))
        right <- c(right, missing)
    }
    if (type == "semi") return(list(x = which(rowSums(matching) > 0L)))
    if (type == "anti") return(list(x = which(rowSums(matching) == 0L)))
    list(x = left, y = right)
}
