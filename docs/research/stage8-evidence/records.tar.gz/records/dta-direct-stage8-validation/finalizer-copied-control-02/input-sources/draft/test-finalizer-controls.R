test_that("FC00 copied closure routing selects the declared helpers", {
    methods <- c("select.dtatools_ref_data", "rename.dtatools_ref_data",
        "relocate.dtatools_ref_data", "ungroup.dtatools_ref_data",
        "rowwise.dtatools_ref_data", ".dibble_group_result")
    facts <- list()
    for (route in .fc_routes[-1L]) {
        scope <- .fc_scope(route, capture = "atomic", constructor = "hash", reserve = "hash")
        local_names <- c(methods, ".begin_dibble_result", ".finish_dibble_result",
            ".dibble_select_columns", ".capture_dibble_nested", ".type_dibble_columns",
            "as_dibble", ".as_dibble", "dibble", ".isolate_shared_columns", "reserve_columns")
        routed <- vapply(local_names, function(name) identical(
            environment(get(name, envir = scope, inherits = FALSE)), scope), logical(1))
        bodies <- vapply(c(methods, "as_dibble", ".as_dibble", "dibble", "reserve_columns"),
            function(name) identical(body(get(name, envir = scope, inherits = FALSE)),
                body(get(name, envir = .fc_namespace, inherits = FALSE))), logical(1))
        facts[[route]] <- list(parent_namespace = identical(parent.env(scope), .fc_namespace),
            routed = routed, installed_entry_bodies = bodies)
        expect_true(all(routed)); expect_true(all(bodies))
    }
    original <- .fc_scope("original", "original", "original", "original")
    originals <- c(".begin_dibble_result", ".finish_dibble_result",
        ".prepare_dibble_result_column", ".capture_dibble_nested",
        ".type_dibble_columns", ".isolate_shared_columns")
    facts$original_bodies <- vapply(originals, function(name)
        identical(body(get(name, original)), body(get(name, .fc_namespace))), logical(1))
    .fc_run("FC00/routing", facts)
    expect_true(all(facts$original_bodies))
})

test_that("FC01 real selector entry methods retain column-context behavior", {
    for (shape in c("plain", "grouped", "rowwise", "empty"))
        for (verb in c("select", "rename", "relocate", "ungroup", "rowwise"))
            for (route in .fc_routes) {
                data <- .fc_selector_input(shape)
                scope <- if (route == "public") NULL else .fc_scope(route)
                id <- paste("FC01", shape, verb, route, sep = "/")
                value <- .fc_run(id, .fc_selector_call(verb, data, route, scope), list(data))
                .fc_note(id, list(dibble = is_dibble(value),
                    valid = dtatools:::.reference_state_valid(value)))
                expect_true(is_dibble(value))
                expect_true(dtatools:::.reference_state_valid(value))
                if (route != "public") .fc_parity(id, paste("FC01", shape, verb, "public", sep = "/"))
            }
})

test_that("FC02 repeated output slots reuse a prepared physical value after GC", {
    for (shape in c("numeric", "owned", "nested", "zero")) for (route in .fc_routes[-1L]) {
        fresh <- function() switch(shape,
            numeric = structure(c(1, 2, 3), label = "atomic sibling"),
            owned = .subset2(dibble(x = c(TRUE, FALSE, TRUE)), 1L),
            nested = list(list(v = 1L), list(v = 2L), list(v = 3L)))
        if (shape == "zero") columns <- list() else {
            shared <- fresh(); other <- fresh()
            columns <- list(a = shared, b = shared, c = other)
            expect_identical(rlang::obj_address(columns[[1L]]), rlang::obj_address(columns[[2L]]))
            expect_false(identical(rlang::obj_address(columns[[1L]]), rlang::obj_address(columns[[3L]])))
        }
        result <- tibble::new_tibble(columns, nrow = 3L)
        data <- dibble(seed = 1:3)
        scope <- .fc_scope(route)
        trace <- new.env(parent = emptyenv()); trace$names <- character()
        implementation <- get(".prepare_dibble_result_column", envir = scope)
        scope$.prepare_dibble_result_column <- local({
            impl <- implementation; events <- trace
            function(column, isolate, row_count, caller, name) {
                events$names <- c(events$names, name)
                invisible(gc())
                impl(column, isolate, row_count, caller, name)
            }
        })
        context <- scope$.begin_dibble_result(data, "finalizer control", "unknown")
        id <- paste("FC02", shape, route, sep = "/")
        value <- .fc_run(id, scope$.finish_dibble_result(context, result), list(result, data))
        same <- if (shape == "zero") NULL else identical(
            rlang::obj_address(.subset2(value, 1L)), rlang::obj_address(.subset2(value, 2L)))
        .fc_note(id, list(preparation_names = trace$names, repeated_identity = same))
        expect_identical(trace$names, if (shape == "zero") character() else c("a", "c"))
        if (shape != "zero") {
            expect_true(same)
            expect_identical(.s8_semantic(value[[1L]]), .s8_semantic(value[[2L]]))
        }
        if (route != "original") .fc_parity(id, paste("FC02", shape, "original", sep = "/"))
    }
})

test_that("FC03 atomic metadata and opaque identities retain their separate policies", {
    for (route in c("original", "atomic")) for (shape in c(
        "numeric", "character", "pairlist", "environment", "closure", "siblings")) {
        scope <- .fc_scope(capture = route)
        id <- paste("FC03", shape, route, sep = "/")
        facts <- .fc_run(id, {
            input <- switch(shape,
                numeric = structure(c(1, 2), label = "atomic metadata"),
                character = structure(c("a", "b"), label = "character metadata"),
                pairlist = pairlist(a = 1L, b = 2L),
                environment = new.env(parent = emptyenv()),
                closure = function(x) x,
                siblings = { shared <- list(value = 1:2); list(list(shared), list(shared)) })
            output <- scope$.capture_dibble_nested(input)
            opaque <- shape %in% c("environment", "closure")
            list(opaque = opaque, input_typeof = typeof(input), output_typeof = typeof(output),
                same_identity = identical(rlang::obj_address(input), rlang::obj_address(output)),
                semantic = if (opaque) NULL else .s8_semantic(output),
                expected = if (opaque) NULL else .s8_semantic(input),
                sibling_identity = if (shape == "siblings") identical(
                    rlang::obj_address(output[[1L]][[1L]]), rlang::obj_address(output[[2L]][[1L]])) else NULL)
        })
        expect_identical(facts$output_typeof, facts$input_typeof, info = id)
        if (facts$opaque) expect_true(facts$same_identity) else {
            expect_identical(facts$semantic, facts$expected)
            if (shape == "siblings") expect_true(facts$sibling_identity)
        }
        if (route == "atomic") .fc_parity(id, paste("FC03", shape, "original", sep = "/"))
    }
})

test_that("FC04 unchanged cycle rejection is isolated in fresh children", {
    skip_if_not_installed("callr")
    for (route in c("original", "atomic")) {
        source <- file.path(.fc_draft, paste0(route, "-capture.R"))
        output <- get("out", envir = .GlobalEnv)
        id <- paste("FC04", route, sep = "/")
        result <- .fc_run(id, callr::r(function(source, libraries, expected_path) {
            .libPaths(libraries)
            loadNamespace("dtatools", lib.loc = dirname(expected_path))
            ns <- asNamespace("dtatools")
            stopifnot(identical(normalizePath(getNamespaceInfo(ns, "path")), normalizePath(expected_path)))
            local <- new.env(parent = ns); sys.source(source, envir = local)
            cycle <- list(NULL)
            invisible(.Call(get("C_dtatools_set_data_column", ns), cycle, 1L, cycle))
            message <- tryCatch({local$.capture_dibble_nested(cycle); NULL}, error = conditionMessage)
            rm(cycle); invisible(gc())
            healthy <- local$.capture_dibble_nested(list(value = 1:2))
            list(message = message, healthy = healthy, constants = as.integer(c(TRUE, FALSE)),
                R = R.version.string, R_home = R.home(), package_path = getNamespaceInfo(ns, "path"),
                namespaces = loadedNamespaces())
        }, args = list(source, .libPaths(), getNamespaceInfo(.fc_namespace, "path")),
            libpath = .libPaths(), timeout = 60,
            stdout = file.path(output, paste0("cycle-", route, ".stdout")),
            stderr = file.path(output, paste0("cycle-", route, ".stderr"))))
        expect_match(result$message, "Cyclic nested list or data frame")
        expect_identical(result$healthy, list(value = 1:2))
        expect_identical(result$constants, c(1L, 0L))
    }
})

test_that("FC05 full constructor entries retain normalization and grouping", {
    for (shape in c("frame", "tibble", "grouped", "stale")) for (route in c("public", "original", "hash")) {
        input <- .fc_constructor_input(shape)
        scope <- if (route == "public") NULL else .fc_scope(constructor = route)
        fn <- if (route == "public") dtatools::as_dibble else scope$as_dibble
        id <- paste("FC05", shape, route, sep = "/")
        result <- .fc_run(id, fn(input), list(input))
        .fc_note(id, list(valid = dtatools:::.reference_state_valid(result),
            alias = identical(rlang::obj_address(.subset2(result, 1L)), rlang::obj_address(.subset2(result, 2L)))))
        expect_true(is_dibble(result)); expect_true(dtatools:::.reference_state_valid(result))
        if (shape == "stale") {
            expect_identical(as.character(result$a), c("", "widened"))
            expect_identical(attr(result$a, "stata.string.storage"), "str7")
        }
        if (route != "public") {
            reference <- paste("FC05", shape, "public", sep = "/")
            .fc_parity(id, reference)
            expect_identical(.s8_records$values[[id]]$details$alias,
                .s8_records$values[[reference]]$details$alias, info = id)
        }
    }
})

test_that("FC06 constructor capture reads the actual normalized physical slot", {
    for (route in c("original", "hash")) {
        scope <- .fc_scope(constructor = route)
        trace <- new.env(parent = emptyenv()); trace$events <- list()
        capture_symbol <- get("C_dtatools_capture_column", envir = .fc_namespace)
        scope$.Call <- local({
            target <- capture_symbol; events <- trace
            function(.NAME, ...) {
                args <- list(...)
                if (identical(.NAME, target)) {
                    frame <- parent.frame()
                    physical <- .subset2(get("data", frame), get("index", frame))
                    events$events[[length(events$events) + 1L]] <- list(
                        index = get("index", frame),
                        same_physical = identical(rlang::obj_address(args[[1L]]), rlang::obj_address(physical)),
                        value = .s8_semantic(args[[1L]]))
                    invisible(gc())
                }
                base::.Call(.NAME, ...)
            }
        })
        input <- .fc_constructor_input("stale")
        id <- paste("FC06", route, sep = "/")
        result <- .fc_run(id, scope$as_dibble(input), list(input))
        .fc_note(id, trace$events)
        expect_gt(length(trace$events), 0L)
        expect_true(all(vapply(trace$events, `[[`, logical(1), "same_physical")))
        expect_identical(as.character(result$a), c("", "widened"))
        if (route == "hash") .fc_parity(id, "FC06/original")
    }
})

test_that("FC07 real reserve entries preserve classes grouping and alias values", {
    for (shape in c("frame", "tibble", "dibble", "grouped")) for (route in c("public", "original", "hash")) {
        input <- .fc_reserve_input(shape)
        scope <- if (route == "public") NULL else .fc_scope(reserve = route)
        fn <- if (route == "public") dtatools::reserve_columns else scope$reserve_columns
        id <- paste("FC07", shape, route, sep = "/")
        result <- .fc_run(id, fn(input, n = 8L), list(input))
        .fc_note(id, list(alias = identical(rlang::obj_address(.subset2(result, 1L)),
            rlang::obj_address(.subset2(result, 2L))), capacity = dtatools::can_add_columns(result, 8L)))
        expect_identical(.s8_semantic(result[[1L]]), .s8_semantic(result[[2L]]))
        expect_true(dtatools::can_add_columns(result, 8L))
        if (route != "public") {
            reference <- paste("FC07", shape, "public", sep = "/")
            .fc_parity(id, reference)
            expect_identical(.s8_records$values[[id]]$details$alias,
                .s8_records$values[[reference]]$details$alias, info = id)
        }
    }
})

test_that("FC08 direct reserve helpers retain per-iteration reads and cached NULL", {
    for (shape in c("aliases", "null", "later_slot")) for (route in c("original", "hash")) {
        scope <- .fc_scope(reserve = route)
        trace <- new.env(parent = emptyenv()); trace$null_copies <- 0L
        trace$column_copies <- 0L; trace$injected <- FALSE
        original_copy <- get(".metadata_copy", envir = .fc_namespace)
        source <- structure(c(1, 2, 3), label = "source")
        replacement <- structure(c(7, 8, 9), label = "later slot")
        input <- if (shape == "null") list(NULL, NULL) else list(source, source)
        scope$.metadata_copy <- local({
            impl <- original_copy; events <- trace; selected_shape <- shape; later <- replacement
            function(value) {
                frame <- parent.frame()
                column_call <- exists("index", envir = frame, inherits = FALSE)
                if (column_call) {
                    events$column_copies <- events$column_copies + 1L
                    if (is.null(value)) events$null_copies <- events$null_copies + 1L
                    if (selected_shape == "later_slot" && !events$injected) {
                        # Mutates only the disposable result shell inside this helper.
                        invisible(.Call(dtatools:::C_dtatools_set_data_column,
                            get("result", frame), 2L, later))
                        events$injected <- TRUE
                    }
                    invisible(gc())
                }
                impl(value)
            }
        })
        id <- paste("FC08", shape, route, sep = "/")
        result <- .fc_run(id, scope$.isolate_shared_columns(input,
            if (shape == "later_slot") list(source) else NULL), list(input))
        .fc_note(id, list(column_copies = trace$column_copies, null_copies = trace$null_copies,
            injected = trace$injected,
            alias = identical(rlang::obj_address(result[[1L]]), rlang::obj_address(result[[2L]]))))
        expect_identical(trace$column_copies, 1L)
        if (shape == "null") {
            expect_identical(trace$null_copies, 1L); expect_identical(result, list(NULL, NULL))
        } else if (shape == "later_slot") {
            expect_true(trace$injected); expect_identical(result[[2L]], replacement)
        } else {
            expect_identical(result[[1L]], result[[2L]])
            expect_identical(rlang::obj_address(result[[1L]]), rlang::obj_address(result[[2L]]))
        }
        if (route == "hash") .fc_parity(id, paste("FC08", shape, "original", sep = "/"))
    }
})
