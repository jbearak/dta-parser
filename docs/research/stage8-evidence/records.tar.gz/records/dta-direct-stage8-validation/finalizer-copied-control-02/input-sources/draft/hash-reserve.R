.isolate_shared_columns <- function(result, sources) {
    isolate_all <- is.null(sources)
    source_addresses <- if (!isolate_all) {
        unlist(lapply(sources, function(source) {
            if (is.data.frame(source)) {
                vapply(
                    .data_columns(source), rlang::obj_address, character(1)
                )
            } else {
                rlang::obj_address(source)
            }
        }))
    }
    result <- .metadata_copy(result)
    detached <- utils::hashtab(type = "address")
    absent_capture <- new.env(parent = emptyenv())
    for (index in seq_len(length(result))) {
        column <- .subset2(result, index)
        address <- rlang::obj_address(column)
        if (isolate_all || address %in% source_addresses) {
            captured <- utils::gethash(detached, column, nomatch = absent_capture)
            if (identical(captured, absent_capture)) {
                captured <- .metadata_copy(column)
                utils::sethash(detached, column, captured)
            }
            .Call(C_dtatools_set_data_column, result, as.integer(index), captured)
        }
    }
    result
}
