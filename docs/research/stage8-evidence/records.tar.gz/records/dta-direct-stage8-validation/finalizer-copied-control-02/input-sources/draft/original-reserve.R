.isolate_shared_columns <- function(result, sources) {
    isolate_all <- is.null(sources)
    source_addresses <- if (!isolate_all) {
        unlist(lapply(sources, function(source) {
            if (is.data.frame(source)) {
                vapply(
                    .data_columns(source), rlang::obj_address, character(1)
                )
            } else {
                rlang::obj_address(source)
            }
        }))
    }
    result <- .metadata_copy(result)
    detached <- new.env(parent = emptyenv())
    for (index in seq_len(length(result))) {
        column <- .subset2(result, index)
        address <- rlang::obj_address(column)
        if (isolate_all || address %in% source_addresses) {
            if (!exists(address, envir = detached, inherits = FALSE)) {
                detached[[address]] <- .metadata_copy(column)
            }
            .Call(C_dtatools_set_data_column, result, as.integer(index), detached[[address]])
        }
    }
    result
}
