.type_dibble_columns <- function(data, caller = "as_dibble()") {
    row_count <- nrow(data)
    column_names <- names(data)
    captured_columns <- new.env(parent = emptyenv())
    for (index in seq_along(column_names)) {
        column <- .subset2(data, index)
        typed <- .typed_column_named(
            column, row_count, caller, column_names[[index]]
        )
        if (!identical(rlang::obj_address(typed), rlang::obj_address(column))) {
            data[[index]] <- typed
        }
        # Value normalization above keeps the existing replacement/regrouping
        # policy. Capturing identical values only changes their private handle;
        # dispatching [[<- here would trim preserved empty grouping keys.
        normalized <- .subset2(data, index)
        address <- rlang::obj_address(normalized)
        captured <- captured_columns[[address]]
        if (is.null(captured)) {
            captured <- .Call(C_dtatools_capture_column, normalized)
            captured_columns[[address]] <- captured
        }
        .Call(C_dtatools_set_data_column, data, as.integer(index), captured)
    }
    data
}
