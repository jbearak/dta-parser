test_that("J09 copied caller policy distinguishes wrapper evaluation frames", {
    scope <- new.env(parent = .s8_direct)
    for (name in c("left_join.dtatools_ref_data", ".dibble_join_mutate", ".dibble_join_matches")) {
        fn <- get(name, envir = .s8_direct)
        environment(fn) <- scope
        assign(name, fn, envir = scope)
    }
    trace <- new.env(parent = emptyenv())
    trace$values <- list()
    policy <- get(".dibble_join_direct", envir = .s8_direct)
    scope$.dibble_join_direct <- function(env) {
        result <- policy(env)
        top <- topenv(env)
        trace$values[[length(trace$values) + 1L]] <- list(
            caller_is_empty = identical(env, emptyenv()),
            top_is_global = identical(top, globalenv()),
            top_is_namespace = isNamespace(top), top_name = environmentName(top),
            namespace = if (isNamespace(top)) getNamespaceName(top) else NULL,
            tested_package = Sys.getenv("TESTTHAT_PKG"), eligible = result,
            rlang_namespace = rlang::is_namespace(top),
            upstream_eligible = getFromNamespace("is_direct", "dplyr")(env))
        result
    }
    direct <- get("left_join.dtatools_ref_data", envir = scope)
    old_wrapper <- function(x, y, ...) do.call(direct, list(x = x, y = y, ...))
    forwarded_wrapper <- function(x, y, ...) {
        do.call(direct, list(x = x, y = y, ...), envir = parent.frame())
    }
    store <- new.env(parent = environment(.s8_record))
    store$.s8_records <- new.env(parent = emptyenv())
    store$.s8_records$values <- list()
    record <- .s8_record
    environment(record) <- store
    observed <- list()
    on.exit({
        directory <- get("out", envir = .GlobalEnv)
        saveRDS(observed, file.path(directory, "caller-policy.rds"))
        dput(observed, file.path(directory, "caller-policy.R"))
    })
    operations <- list(public = dplyr::left_join, old_wrapper = old_wrapper,
                       forwarded_wrapper = forwarded_wrapper)
    for (name in names(operations)) {
        x <- dibble(k = c(1L, 1L, 2L), value = 1:3)
        y <- dibble(k = c(1L, 1L, 3L), other = 1:3)
        trace$values <- list()
        actual <- record(name, operations[[name]](x, y, by = "k"))
        saved <- store$.s8_records$values[[name]]
        saved$policy_trace <- trace$values
        observed[[name]] <- saved
        expect_true(actual$ok)
        expect_identical(saved$snapshot_status, "complete")
        if (name != "public") {
            expect_length(saved$policy_trace, 1L)
            expect_identical(saved$policy_trace[[1L]]$eligible,
                             saved$policy_trace[[1L]]$upstream_eligible)
        }
    }
    expect_identical(observed$forwarded_wrapper$value, observed$public$value)
    expect_identical(lapply(observed$forwarded_wrapper$conditions, `[[`, "classes"),
                     lapply(observed$public$conditions, `[[`, "classes"))
})
