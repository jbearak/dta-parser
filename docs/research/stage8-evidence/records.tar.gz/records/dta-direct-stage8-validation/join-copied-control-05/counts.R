list(blocks = 10L, passed = 1927L, failed = 4L, errors = 0L, 
    warnings = 0L, skips = 0L)
