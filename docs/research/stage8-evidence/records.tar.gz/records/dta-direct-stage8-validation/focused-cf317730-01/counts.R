list(blocks = 165L, passed = 3612L, failed = 0L, errors = 0L, 
    warnings = 0L, skips = 0L)
