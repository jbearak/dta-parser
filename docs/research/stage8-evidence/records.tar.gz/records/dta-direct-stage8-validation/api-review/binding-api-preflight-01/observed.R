list(R = "R version 4.6.1 (2026-06-24)", R_home = "/opt/homebrew/Cellar/r/4.6.1/lib/R", 
    library_paths = c("/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library", 
    "/opt/homebrew/lib/R/4.6/site-library", "/opt/homebrew/Cellar/r/4.6.1/lib/R/library"
    ), packages = list(list(name = "rlang", path = "/opt/homebrew/lib/R/4.6/site-library/rlang", 
        version = "1.3.0"), list(name = "testthat", path = "/opt/homebrew/lib/R/4.6/site-library/testthat", 
        version = "3.3.2")), functions = list(arg_match0 = list(
        formals = as.pairlist(alist(arg = , values = , arg_nm = caller_arg(arg), error_call = caller_env())), 
        body = {
            .External(ffi_arg_match0, arg, values, environment())
        }), expect_gt = list(formals = as.pairlist(alist(object = , expected = , label = NULL, expected.label = NULL)), 
        body = {
            act <- quasi_label(enquo(object), label)
            exp <- quasi_label(enquo(expected), expected.label)
            expect_compare_(">", act, exp)
            invisible(act$val)
        }), expect_true = list(formals = as.pairlist(alist(object = , info = NULL, label = NULL)), 
        body = {
            act <- quasi_label(enquo(object), label)
            exp <- labelled_value(TRUE, "TRUE")
            expect_waldo_constant_(act, exp, info = info, ignore_attr = TRUE)
            invisible(act$val)
        }), identical = list(formals = as.pairlist(alist(x = , y = , num.eq = TRUE, single.NA = TRUE, attrib.as.set = TRUE, ignore.bytecode = TRUE, ignore.environment = FALSE, ignore.srcref = TRUE, extptr.as.ref = FALSE)), 
        body = .Internal(identical(x, y, num.eq, single.NA, attrib.as.set, 
            ignore.bytecode, ignore.environment, ignore.srcref, 
            extptr.as.ref)))), namespaces = c("compiler", "magrittr", 
    "R6", "cli", "graphics", "otel", "utils", "grDevices", "stats", 
    "methods", "brio", "testthat", "lifecycle", "rlang", "base"
    ), dlls = list(base = "base", methods = "/opt/homebrew/Cellar/r/4.6.1/lib/R/library/methods/libs/methods.so", 
        utils = "/opt/homebrew/Cellar/r/4.6.1/lib/R/library/utils/libs/utils.so", 
        grDevices = "/opt/homebrew/Cellar/r/4.6.1/lib/R/library/grDevices/libs/grDevices.so", 
        graphics = "/opt/homebrew/Cellar/r/4.6.1/lib/R/library/graphics/libs/graphics.so", 
        stats = "/opt/homebrew/Cellar/r/4.6.1/lib/R/library/stats/libs/stats.so", 
        rlang = "/opt/homebrew/lib/R/4.6/site-library/rlang/libs/rlang.so", 
        cli = "/opt/homebrew/lib/R/4.6/site-library/cli/libs/cli.so", 
        brio = "/opt/homebrew/lib/R/4.6/site-library/brio/libs/brio.so", 
        magrittr = "/opt/homebrew/lib/R/4.6/site-library/magrittr/libs/magrittr.so", 
        testthat = "/opt/homebrew/lib/R/4.6/site-library/testthat/libs/testthat.so"))
