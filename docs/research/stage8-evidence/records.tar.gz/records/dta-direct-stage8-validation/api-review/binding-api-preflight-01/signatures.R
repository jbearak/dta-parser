args <- commandArgs(TRUE)
stopifnot(length(args) == 2L)
.libPaths(c(args[[1L]], .libPaths()))
observed <- list(
    R = R.version.string,
    R_home = R.home(),
    library_paths = .libPaths(),
    packages = lapply(c("rlang", "testthat"), function(pkg) {
        ns <- asNamespace(pkg)
        list(name = pkg, path = getNamespaceInfo(ns, "path"),
             version = as.character(utils::packageVersion(pkg)))
    }),
    functions = lapply(list(
        arg_match0 = rlang::arg_match0,
        expect_gt = testthat::expect_gt,
        expect_true = testthat::expect_true,
        identical = base::identical), function(fn) {
            list(formals = formals(fn), body = body(fn))
        }),
    namespaces = loadedNamespaces(),
    dlls = lapply(getLoadedDLLs(), function(dll) dll[["path"]])
)
stopifnot(!"dtatools" %in% loadedNamespaces())
stopifnot(identical(observed$packages[[1L]]$path,
    "/opt/homebrew/lib/R/4.6/site-library/rlang"))
stopifnot(identical(observed$packages[[2L]]$path,
    "/opt/homebrew/lib/R/4.6/site-library/testthat"))
dput(observed, file.path(args[[2L]], "observed.R"))
print(lapply(observed$functions, `[[`, "formals"))
