from pathlib import Path
import csv
import hashlib
import io
import json
import re
import subprocess
import tarfile

V = Path('/private/tmp/dta-direct-stage8-validation')
P = V / 'predecessor-af0bed0b-01'
W = Path('/private/tmp/dta-direct-stage8')
OUT = V / 'api-review/predecessor-selected-chain-01.json'
PIN = 'af0bed0b9c200f82d37891902266d200a1819196'
TREE = 'fd8642daf27875e5cece5822e1ac9cd5615ff3c6'
EXPECTED_RECEIPT = '05494bd135b50c3b95827409727f5d2626e407cbe289528c4fb11b58ffdf9f72'
report = {'status': 'incomplete', 'scope': 'Selected source, installation, runtime and saved command chain; no R or build execution and no complete live runtime inventory rehash', 'checks': {}, 'failure': None}
def need(ok, message):
    if not ok:
        raise RuntimeError(message)
def ident(path):
    path = Path(path)
    resolved = path.resolve(strict=True)
    b = resolved.read_bytes()
    return {'path': str(path), 'resolved': str(resolved), 'bytes': len(b), 'mode': oct(resolved.stat().st_mode & 0o777), 'sha256': hashlib.sha256(b).hexdigest()}
def read(name):
    return json.loads((P / name).read_text())
def same(record):
    now = ident(record['path'])
    need(all(now[k] == record[k] for k in now), 'Changed selected product/input: ' + record['path'])
    return now
def git(*args):
    argv = ['/usr/bin/git', '-C', str(W), *args]
    r = subprocess.run(argv, capture_output=True)
    need(r.returncode == 0, 'Reviewer Git read failed: ' + r.stderr.decode())
    return r.stdout
def dcf(text):
    out = {}; key = None
    for line in text.splitlines():
        if line[:1].isspace() and key:
            out[key] += ' ' + line.strip()
        elif ':' in line:
            key, value = line.split(':', 1); out[key] = value.strip()
    return out
try:
    receipt_id = ident(P/'completed-receipt.json')
    need(receipt_id['sha256'] == EXPECTED_RECEIPT, 'Unexpected accepted receipt')
    receipt = read('completed-receipt.json'); result = read('execution-result.json'); before = read('inputs-before.json')
    need(receipt['status'] == result['status'] == 'complete', 'Incomplete install')
    need(receipt['revision'] == before['revision'] == PIN and receipt['package_tree'] == before['package_tree'] == TREE, 'Wrong source/tree')
    need(result['input_binding_complete'] and result['export_inventory_available'] and result['error'] is None, 'Incomplete input binding')
    need(not receipt['changed_bound_inputs'] and not result['changed_bound_inputs'] and not result['generated_export_files'], 'Changed inputs/exports')
    same(receipt['manifest'])
    products = read('output-manifest.json')['products']; product = {r['path']: r for r in products}
    inputs = {r['path']: r for r in before['inputs']}
    need(len(product) == len(products) and len(inputs) == len(before['inputs']), 'Duplicate saved paths')
    selected = ['inputs-before.json','execution-result.json','installed-files.json','built-source-before-install.json','installed-identity.R','loaded-namespaces.tsv','loaded-dlls.txt','finish-install.log']
    for name in selected:
        same(product[str(P/name)])
    report['checks']['receipt'] = receipt_id
    report['checks']['saved_counts'] = {'inputs': len(inputs), 'exports': len(before['export_inventory']), 'products': len(products), 'dependencies': len(before['dependencies'])}

    launch = json.loads((V/'predecessor-launch-01.json').read_text())
    launch_end = json.loads((V/'predecessor-launch-result-01.json').read_text())
    launch_selected = json.loads((V/'predecessor-launch-selected-01.json').read_text())['selected']
    need(launch['source'] == PIN and launch['package_tree'] == TREE, 'Wrong outer launch source')
    need(launch_end['returncode'] == 0 and not launch_end['changed_selected_endpoints'], 'Outer launch failure/change')
    for r in launch_selected:
        same(r)
    need(launch['argv'] == ['/Users/jmb/.pyenv/versions/3.14.7/bin/python3.14','-I','-B',str(W/'benchmarks/r-dibble-dplyr/install-expression-source.py'),str(W),str(P),PIN], 'Wrong outer argv')
    need(str(Path(launch['argv'][0]).resolve()) in inputs, 'Actual interpreter not bound')
    commands = result['commands']
    need([r['label'] for r in commands] == ['r-version','rustc-version','cargo-version','clang-version','build','install','finish-install'], 'Unexpected command sequence')
    for command in commands:
        need(command == read(command['label']+'-command.json') and command['returncode'] == 0, 'Command record/exit mismatch')
        same(product[str(P/(command['label']+'-command.json'))]); same(command['log'])
    report['checks']['launch'] = {'argv': launch['argv'], 'cwd': launch['cwd'], 'PATH': launch['PATH'], 'environment_overrides': before['environment_overrides'], 'selected_endpoints': len(launch_selected), 'changed_endpoints': [], 'commands': commands}

    need(git('rev-parse', PIN+':r-package/dtatools').decode().strip() == TREE, 'Actual package tree differs')
    helpers = ['benchmarks/r-dibble-dplyr/'+n for n in ['install-expression-source.py','expression-install-finish.R','helpers.R']]
    export_records = {str(Path(r['path']).relative_to(P/'export')): r for r in before['export_inventory']}
    tree_rows = git('ls-tree','-r','-z',PIN,'--','r-package/dtatools',*helpers).split(b'\0')
    expected = {}
    for row in tree_rows:
        if row:
            meta,name = row.split(b'\t'); mode,kind,blob = meta.decode().split(); expected[name.decode()] = (mode,kind,blob)
    need(set(expected) == set(export_records), 'Saved export membership differs from Git')
    for name,r in export_records.items():
        mode,kind,blob = expected[name]
        need(kind == 'blob' and r['git_blob'] == blob and r['git_mode'] == mode, 'Saved export Git identity mismatch')
    selected_sources = json.loads((V/'api-review/integration-sources/predecessor-source-identities-01.json').read_text())
    selected_paths = [r['path'] for r in selected_sources] + helpers
    same(before['source_archive']); same(read('built-source-before-install.json'))
    with tarfile.open(P/'source.tar') as archive:
        members = {m.name:m for m in archive if m.isfile()}
        need(set(members) == set(expected), 'Source tar membership differs')
        for name in selected_paths:
            b = git('show',PIN+':'+name)
            need(archive.extractfile(members[name]).read() == b == (P/'export'/name).read_bytes(), 'Selected source bytes differ')
            same(export_records[name])
    helper_blobs = {}
    for name in helpers:
        b = git('show',PIN+':'+name)
        need(b == (W/name).read_bytes() == git('show','3db15d44f2b557f5282fb7a30fd59c7980a4484c:'+name), 'Previously reviewed helper changed')
        helper_blobs[name] = expected[name][2]
    report['checks']['source'] = {'package_tree': TREE, 'saved_git_export_membership': len(expected), 'selected_git_tar_export_files_checked': selected_paths, 'helpers_equal_previously_reviewed_3db': helper_blobs}

    installed = read('installed-files.json')['files']; library = P/'library/dtatools'
    actual_paths = {str(p) for p in library.rglob('*') if p.is_file()}
    need(actual_paths == {r['path'] for r in installed}, 'Installed membership changed')
    for r in installed:
        same(r); need(r == product[r['path']], 'Installed index differs from manifest')
    with tarfile.open(P/'build/dtatools_0.8.0.tar.gz') as archive:
        for name in selected_paths:
            if name.startswith('r-package/dtatools/') and not name.endswith('DESCRIPTION'):
                suffix = name.removeprefix('r-package/dtatools/')
                need(archive.extractfile('dtatools/'+suffix).read() == (P/'export'/name).read_bytes(), 'Built selected source differs')
        built_desc = dcf(archive.extractfile('dtatools/DESCRIPTION').read().decode())
        exported_desc = dcf((P/'export/r-package/dtatools/DESCRIPTION').read_text())
        diff = {k:{'export':exported_desc.get(k),'built':built_desc.get(k)} for k in sorted(set(built_desc)|set(exported_desc)) if built_desc.get(k) != exported_desc.get(k)}
        need(set(diff) <= {'Author','Maintainer','Packaged'}, 'Unexpected DESCRIPTION change')
        need(archive.extractfile('dtatools/inst/NOTICE').read() == (library/'NOTICE').read_bytes(), 'Installed NOTICE differs')
        need(archive.extractfile('dtatools/NAMESPACE').read() == (library/'NAMESPACE').read_bytes(), 'Installed NAMESPACE differs')
    dll = library/'libs/dtatools.so'
    finish_text = (P/'finish-install.log').read_text(); identity_text = (P/'installed-identity.R').read_text()
    need('exports 106' in finish_text and PIN in finish_text and TREE in finish_text, 'Missing finish assertions')
    need(hashlib.md5(dll.read_bytes()).hexdigest() in finish_text, 'Recorded DLL MD5 differs')
    need('exports = 106L' in identity_text and str(library) in identity_text and str(dll) in identity_text, 'Missing runtime identity fields')
    report['checks']['installed'] = {'files_verified': len(installed), 'dll': ident(dll), 'namespace_export_lines': sum(line.startswith('export(') for line in (library/'NAMESPACE').read_text().splitlines()), 'runtime_exports':106, 'DESCRIPTION_source_to_build_changes':diff, 'sidecar_scope':'Stored RDS identity checked as installed product; not deserialized by this reviewer. Finish helper validates its file MD5s before and after tiny load.'}

    namespaces = list(csv.DictReader((P/'loaded-namespaces.tsv').open(), delimiter='\t'))
    resolved_inputs = {r['resolved']:r for r in before['inputs']}
    for ns in namespaces:
        if ns['name'] == 'dtatools':
            need(Path(ns['path']).resolve() == library, 'Wrong dtatools namespace')
        else:
            desc = str((Path(ns['path'])/'DESCRIPTION').resolve())
            need(desc in resolved_inputs, 'Unbound namespace DESCRIPTION')
            same(resolved_inputs[desc])
    dlls = (P/'loaded-dlls.txt').read_text().splitlines()
    for value in dlls:
        if value == 'base': continue
        resolved = str(Path(value).resolve())
        need(resolved == str(dll) or resolved in resolved_inputs, 'Unbound loaded DLL endpoint')
    for path in ['/opt/homebrew/Cellar/r/4.6.1/bin/R','/opt/homebrew/Cellar/r/4.6.1/bin/Rscript','/opt/homebrew/Cellar/r/4.6.1/lib/R/bin/exec/R','/opt/homebrew/Cellar/r/4.6.1/lib/R/lib/libR.dylib']:
        same(inputs[path])
    for dep in before['dependencies']:
        if dep['package'] in ['dplyr','vctrs','rlang']:
            same(inputs[str(Path(dep['path'])/'DESCRIPTION')])
    warnings = [line for line in (P/'install.log').read_text().splitlines() if 'warning:' in line]
    need(len(warnings) == 28 and all("was built for newer 'macOS' version (26.5) than being linked (26.0)" in line for line in warnings), 'Unexpected install warning class')
    report['checks']['runtime'] = {'R':'4.6.1','namespaces':namespaces,'loaded_dll_entries':len(dlls),'file_dll_entries':len(dlls)-1,'all_loaded_dll_paths_resolve_to_bound_inputs_or_installed_DLL':True,'runtime_selected_endpoint_checks':'R, Rscript, exec/R, libR; all loaded namespace DESCRIPTIONs; dplyr/vctrs/rlang DESCRIPTIONs; installed DLL','dplyr_loaded_by_finish':'dplyr' in {r['name'] for r in namespaces},'build_warnings':len(warnings),'warning_class':'Archive object SDK macOS 26.5 versus link target 26.0, retained unchanged'}
    report['limits'] = [
        'This qualifies a fresh retained predecessor installation and its tiny load check, not Stage8 binding/join behavior or performance.',
        'The original installer still performs a bare Git rev-parse and early Git/export/compiler/dependency discovery before its inner full binding. This launch adds saved selected endpoints before invocation and unchanged endpoints afterward, not a continuous per-invocation resolution guarantee or complete early command transcript.',
        'Outer actual argv and PATH are retained; inner commands inherit that environment with recorded overrides. Canonical tool identities are not a complete subprocess image trace. Python interpreter actually invoked is the pyenv path, while the separate python3 tool selected on PATH is Homebrew.',
        'Saved 11279-input inventory and unchanged completion results were read. Only named selected runtime endpoints were rehashed here, not every dependency/R/Rust file or SDK/system/Python closure.',
        'Loaded namespaces and DLLs describe the finish process only; dplyr was a bound dependency but not loaded there. Future observations must validate their own loaded namespace/DLL/runtime selection.',
        'The full source-tar membership and saved Git export identities were checked; only the listed selected sources were independently compared byte-for-byte through Git, source tar, export and built archive. This is not a complete source archive equality claim.',
        'Installed 57-file membership and identities were checked, including the sidecar. This reviewer did not deserialize RDS objects or reproduce the constructor call.'
    ]
    report['status'] = 'clear_with_stated_scope'
except BaseException as error:
    report['failure'] = {'type':type(error).__name__,'message':str(error)}
    raise
finally:
    OUT.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'report':str(OUT),'status':report['status'],'failure':report['failure']}))
