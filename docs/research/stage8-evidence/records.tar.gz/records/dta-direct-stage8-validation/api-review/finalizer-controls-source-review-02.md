Source-only review: finalizer control draft02

No source blocker found for preparing a bounded functional harness. This is not production approval or a semantic/performance result. Read the complete original result/capture modules and constructor/reserve bodies, actual six variant text deltas, draft01-to-draft02 patch, README, and declared source-freeze02. Small text comparisons found the four original bodies in the current package sources; the freeze's digests were read as declarations, not recomputed.

The relevant interface checks are:

- Lineage removal retains source columns and metadata. Current `select`, `rename`, `relocate`, `ungroup`, and `rowwise` column-operation routes all reach the finalizer with `sources=NULL`, making isolation true before the lineage clause. The existing source tree has no other reader of `context$lineage`. This supports the current caller set; a private call combining a columns context with incomplete non-NULL sources can change isolation behavior. Keep that limit explicit.
- Repeated-output reuse computes first identities from the rooted original columns and reads an earlier physical output slot only after that slot has been prepared and stored. It retains grouping and validation after the loop. The future harness should exercise physically shared slots, zero columns, grouped/rowwise metadata, and normalization-sensitive aliases; no arbitrary callback equivalence follows from this source read.
- Atomic capture's early exits copy the existing opaque/non-list decisions before creating the table/recursive closure. List recursion, active-cycle rejection, completed sibling reuse, typing, and reference publication remain intact.
- Constructor hashing uses public actual-object address hashes and reads each physical slot after the existing typing/replacement step. It preserves the original NULL-as-miss behavior. A harness must reach this helper through a controlled constructor entry rather than bypass normalization.
- Reserve hashing preserves per-iteration reads and source-membership decisions. Draft02's unique environment sentinel distinguishes absence from a cached NULL, matching the original exists/get distinction. The original draft01 remains unexecuted. Test this seam directly if the controlled entry accepts such payloads, with separate ordinary supported container cases.

The README's local-environment design can reach the intended selector finalizer by rebinding the five listed method closures and `.dibble_group_result`; constructor, reserve, and capture require their own explicit routing. Assert those environments and selected bodies in the future harness. This review does not qualify a harness/config that does not yet exist, error-record retention, namespace/runtime identities, foreign-write isolation, retention bounds, or allocation effects.

No R, parse, tests, Git, hash/index sweep, or runtime/artifact audit ran during root's quiet window. Only small source reads/comparisons and this report were performed.
