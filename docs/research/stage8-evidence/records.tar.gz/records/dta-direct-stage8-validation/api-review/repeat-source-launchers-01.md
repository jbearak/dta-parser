# Restricted repeat source review

Clear for the proposed bounded repeats. This review read the actual R delta, ten launcher deltas, selected guard bodies, the new freeze, README, and the directly relevant shape/memory source. It ran no R, target-script parser, benchmark, or endpoint hash sweep.

| Preparation | Source assessment |
| --- | --- |
| Three paired bind_cols runs | The driver adds only the final `measure`/exact 100,000 and 1,000,000 row assertions and the four-row `bind_cols` filter. Widths remain 8 and 16. Predecessor selects public plus fixed reference; cf317 selects public. Seven GC-inclusive samples, first/warm profiles, schemas and validation bodies are unchanged. |
| Two paired RSS runs | The single-case launcher selects public `bind_rows_wide`, 100,000 rows and the existing memory driver. That driver fixes width 8 and 50 calls. The inherited mode label remains `smoke`; this does not introduce elapsed-time evidence. RSS covers the whole child. |
| Selection and retention | Accepted predecessor/cf317 source and receipt arguments are correct. New outputs and launch/log/exit names are unique for all ten cases. The repeat freeze replaces the workload driver and adds its README; its six shared rows exactly match the original freeze records. Memory uses the original freeze/schema. Initial approved-identity comparison, fixed Python/Rscript/Git selection, `/usr/bin/time` selection for RSS, subprocess records, and separate final-inventory error retention are unchanged. |

The repeat driver is declared as SHA256 `98d86ad1a8ff50a47b9dd337f7b94ea4adedf4f4314090fc38fc84a5a16a8188`; the repeat freeze is declared as `8acc8e4808a6a5bb26bb0e778d4ff91199a4130f8999e0412f994508b496f5d1` in `repeat-preparation-01.json`. These are read source-selection identities, not a fresh live hash qualification. The launcher will verify those bindings; root retains the separate first-invocation selection record.

The filtered driver omits the prior whole-grid prefix. Pair order is an orchestration promise in the README, not enforced by these independent launchers; actual launch records must establish it. The RSS launcher inherits a stale one-line predecessor/batch docstring, while its controlling argv and retained scope correctly identify the selected single-case source and operation. This is not an execution blocker.

The original four bind_cols fixed-reference flags and the original RSS outlier remain observations pending repeats. No acceptance, cause attribution, complete OS/child image closure, or replacement of original results is implied. No production source changed. All reviewer processes are closed; quiet-ready.
