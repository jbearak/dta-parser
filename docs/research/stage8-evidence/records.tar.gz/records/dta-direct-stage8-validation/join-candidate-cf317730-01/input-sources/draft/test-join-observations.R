test_that("J01 predecessor equality joins retain independently computed row order", {
    on.exit(.s8_flush())
    shapes <- list(duplicates = list(x = c(2L, 1L, 2L, 4L), y = c(2L, 3L, 2L)),
        empty_left = list(x = integer(), y = c(2L, 1L)),
        empty_right = list(x = c(2L, 1L), y = integer()),
        empty_both = list(x = integer(), y = integer()))
    for (kind in c("dibble", "tibble", "frame")) for (shape in names(shapes)) {
        keys <- shapes[[shape]]
        x <- .s8_frame(kind, list(k = keys$x, xid = seq_along(keys$x)))
        y <- .s8_frame(kind, list(k = keys$y, yid = seq_along(keys$y)))
        for (type in c("inner", "left", "right", "full", "semi", "anti")) {
            args <- list(x, y, by = "k")
            if (!type %in% c("semi", "anti")) args$relationship <- "many-to-many"
            result <- .s8_record(paste("J01", kind, shape, type, sep = "/"),
                do.call(getExportedValue("dplyr", paste0(type, "_join")), args))
            expect_true(result$ok)
            if (!result$ok) next
            expected <- .s8_rows(keys$x, keys$y, type)
            expect_identical(as.double(result$value$xid), as.double(expected$x))
            if (!type %in% c("semi", "anti"))
                expect_identical(as.double(result$value$yid), as.double(expected$y))
            expect_identical(nrow(result$value), length(expected$x))
        }
    }
})

test_that("J02 predecessor mixed inputs natural keys suffixes and keep are observed", {
    on.exit(.s8_flush())
    for (left in c("dibble", "tibble", "frame")) for (right in c("dibble", "tibble", "frame")) {
        x <- .s8_frame(left, list(k = c(2L, 1L), value = c("a", "b")))
        y <- .s8_frame(right, list(k = c(1L, 3L), value = c("b", "c")))
        for (keep in list(NULL, FALSE, TRUE)) {
            id <- paste("J02", left, right, if (is.null(keep)) "NULL" else keep, sep = "/")
            z <- .s8_record(id, dplyr::full_join(x, y, by = "k", keep = keep,
                                              suffix = c("_left", "_right")))
            expect_true(z$ok)
            if (z$ok) expect_identical(nrow(z$value), 3L)
        }
        z <- .s8_record(paste("J02/natural", left, right, sep = "/"), dplyr::left_join(x, y))
        expect_true(z$ok)
        z <- .s8_record(paste("J02/named", left, right, sep = "/"),
            dplyr::left_join(x, .s8_frame(right, list(other = c(1L, 3L), extra = 3:4)),
                             by = c(k = "other")))
        expect_true(z$ok)
    }
})

test_that("J03 inequality rolling and overlap joins record real public specifications", {
    on.exit(.s8_flush())
    specs <- list(less = dplyr::join_by(k < k), greater = dplyr::join_by(k >= k),
        closest = dplyr::join_by(closest(k >= k)),
        between = dplyr::join_by(between(k, lo, hi)),
        within = dplyr::join_by(within(lo, hi, lo, hi)),
        overlaps = dplyr::join_by(overlaps(lo, hi, lo, hi, bounds = "[)")))
    for (kind in c("dibble", "tibble", "frame")) {
        x <- .s8_frame(kind, list(k = c(1L, 3L, 5L), lo = c(1L, 2L, 4L), hi = c(2L, 4L, 6L), xid = 1:3))
        y <- .s8_frame(kind, list(k = c(2L, 3L, 4L), lo = c(0L, 2L, 4L), hi = c(3L, 4L, 6L), yid = 1:3))
        for (name in names(specs)) for (type in c("inner", "left", "semi", "anti")) {
            z <- .s8_record(paste("J03", kind, name, type, sep = "/"),
                do.call(getExportedValue("dplyr", paste0(type, "_join")), list(x, y, by = specs[[name]])))
            expect_true(z$ok)
            if (!z$ok) next
            xk <- c(1L, 3L, 5L); yk <- c(2L, 3L, 4L)
            xl <- c(1L, 2L, 4L); xh <- c(2L, 4L, 6L)
            yl <- c(0L, 2L, 4L); yh <- c(3L, 4L, 6L)
            matches <- switch(name, less = outer(xk, yk, "<"),
                greater = outer(xk, yk, ">="),
                between = outer(xk, yl, ">=") & outer(xk, yh, "<="),
                within = outer(xl, yl, ">=") & outer(xh, yh, "<="),
                overlaps = outer(xl, yh, "<") & outer(xh, yl, ">"),
                closest = t(vapply(xk, function(k) {
                    eligible <- yk <= k
                    eligible & if (any(eligible)) yk == max(yk[eligible]) else FALSE
                }, logical(3))))
            expected <- .s8_rows(1:3, 1:3, type, matches)
            expect_identical(as.double(z$value$xid), as.double(expected$x))
            if (!type %in% c("semi", "anti"))
                expect_identical(as.double(z$value$yid), as.double(expected$y))
        }
    }
})

test_that("J04 all Stata missing payloads retain bare and typed matching distinctions", {
    on.exit(.s8_flush())
    missing <- c(NA_real_, vapply(letters, haven::tagged_na, 0))
    values <- c(1, missing)
    constructors <- list(bare = identity, byte = dta_byte, int = dta_int,
                         long = dta_long, float = dta_float, double = dta_double)
    for (storage in names(constructors)) for (kind in c("tibble", "dibble")) {
        x <- .s8_frame(kind, list(k = constructors[[storage]](values), xid = 1:28))
        y <- .s8_frame(kind, list(k = constructors[[storage]](rev(values)), yid = 28:1))
        for (na in c("na", "never")) {
            z <- .s8_record(paste("J04", storage, kind, na, sep = "/"),
                dplyr::left_join(x, y, by = "k", na_matches = na,
                                relationship = "many-to-many", keep = TRUE))
            expect_true(z$ok)
            if (!z$ok) next
            # Bare tibble keys collapse NA tags; dibble construction types them.
            count <- if (storage == "bare" && kind == "tibble" && na == "na") 730L else 28L
            expect_identical(nrow(z$value), count)
            if (storage != "bare" || kind == "dibble")
                expect_identical(as.double(z$value$yid), as.double(1:28))
        }
    }
})

test_that("J05 argument and matching conditions are retained as observations", {
    on.exit(.s8_flush())
    x <- dibble(k = c(1L, 1L, 2L), value = 1:3)
    y <- dibble(k = c(1L, 1L, 3L), other = 1:3)
    cases <- list(
        default_warning = function() dplyr::left_join(x, y, by = "k"),
        one_to_one = function() dplyr::left_join(x, y, by = "k", relationship = "one-to-one"),
        one_to_many = function() dplyr::left_join(x, y, by = "k", relationship = "one-to-many"),
        many_to_one = function() dplyr::left_join(x, y, by = "k", relationship = "many-to-one"),
        unmatched_left = function() dplyr::left_join(x, y, by = "k", unmatched = "error", relationship = "many-to-many"),
        unmatched_right = function() dplyr::right_join(x, y, by = "k", unmatched = "error", relationship = "many-to-many"),
        unmatched_inner_x = function() dplyr::inner_join(x, y, by = "k", unmatched = c("error", "drop"), relationship = "many-to-many"),
        unmatched_inner_y = function() dplyr::inner_join(x, y, by = "k", unmatched = c("drop", "error"), relationship = "many-to-many"),
        first = function() dplyr::left_join(x, y, by = "k", multiple = "first"),
        last = function() dplyr::left_join(x, y, by = "k", multiple = "last"),
        any = function() dplyr::left_join(x, y, by = "k", multiple = "any"),
        suffix_bad = function() dplyr::left_join(x, y, by = "k", suffix = NA_character_),
        keep_bad = function() dplyr::left_join(x, y, by = "k", keep = 1),
        inequality_keep_false = function() dplyr::left_join(x, y, dplyr::join_by(k > k), keep = FALSE),
        by_missing = function() dplyr::left_join(x, y, by = "missing"),
        by_duplicate = function() dplyr::left_join(x, y, by = c("k", "k")),
        dots = function() dplyr::left_join(x, y, by = "k", bogus = 1),
        incompatible = function() dplyr::left_join(x, dibble(k = "a"), by = "k"),
        expression_rejected = function() dplyr::left_join(x, y, dplyr::join_by(k + 1 == k)))
    successful <- c("default_warning", "first", "last", "any")
    for (id in names(cases)) {
        z <- .s8_record(paste0("J05/", id), cases[[id]]())
        expect_identical(z$ok, id %in% successful)
    }
})

test_that("J06 grouped rowwise cross and nested joins preserve observed containers", {
    on.exit(.s8_flush())
    original <- dibble(k = c(2L, 1L, 2L), g = c("a", "b", "a"), value = 1:3)
    attr(original, "label") <- "source dataset"
    inputs <- list(plain = original, grouped = dplyr::group_by(original, g),
                   rowwise = dplyr::rowwise(original, g))
    y <- dibble(k = c(1L, 2L), extra = c("x", "y"))
    for (name in names(inputs)) {
        x <- inputs[[name]]
        for (type in c("left", "full", "semi", "anti")) {
            z <- .s8_record(paste("J06", name, type, sep = "/"),
                do.call(getExportedValue("dplyr", paste0(type, "_join")), list(x, y, by = "k")))
            expect_true(z$ok)
        }
        z <- .s8_record(paste("J06", name, "cross", sep = "/"), dplyr::cross_join(x, y))
        expect_true(z$ok)
        if (z$ok) expect_identical(nrow(z$value), 6L)
        z <- .s8_record(paste("J06", name, "nest", sep = "/"),
                        dplyr::nest_join(x, y, by = "k", name = "matched"))
        expect_true(z$ok)
        if (z$ok) expect_identical(vapply(z$value$matched, nrow, 0L), rep(1L, 3))
    }
})
