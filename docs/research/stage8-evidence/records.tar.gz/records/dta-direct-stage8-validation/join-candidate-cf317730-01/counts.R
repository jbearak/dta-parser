list(blocks = 7L, passed = 646L, failed = 0L, errors = 0L, warnings = 0L, 
    skips = 0L)
