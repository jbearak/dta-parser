list(selector = list(kind = "selector", warm_calls = 25L, measured_calls = 100L, 
    before_heap = c(Ncells = 654232, Vcells = 1148315), after_heap = c(Ncells = 666163, 
    Vcells = 1156269), before_physical = list(source = list(table_address = "0xa21ff4000", 
        names_address = "0xa20f5c000", v1_address = "0xa215a05f0", 
        copy_address = NULL, column_capacity = 5008, column_count = 8L), 
        first = list(table_address = "0xa1d890000", names_address = "0xa1d89c000", 
            v1_address = "0xa1f9993b8", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), latest = list(
            table_address = "0xa1fd74000", names_address = "0xa1fd80000", 
            v1_address = "0xa1f538d60", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L)), after_physical = list(
        source = list(table_address = "0xa21ff4000", names_address = "0xa20f5c000", 
            v1_address = "0xa215a05f0", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0xa1d890000", names_address = "0xa1d89c000", 
            v1_address = "0xa1f9993b8", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), latest = list(
            table_address = "0xa1db78000", names_address = "0xa1db84000", 
            v1_address = "0xa1eb76740", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L)), ncells = 11931, 
    vector_bytes = 63632, rows = 64L, columns = c("v1", "v2", 
    "v3", "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"), 
    duplicate = list(kind = "duplicate", warm_calls = 25L, measured_calls = 100L, 
        before_heap = c(Ncells = 654237, Vcells = 1148323), after_heap = c(Ncells = 666174, 
        Vcells = 1156281), before_physical = list(source = list(
            table_address = "0xa5ffc8000", names_address = "0xa5ffd4000", 
            v1_address = "0xa5e2c05f0", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0xa5a920000", names_address = "0xa5a92c000", 
            v1_address = "0xa5c5d3dc8", copy_address = "0xa5c5d3dc8", 
            column_capacity = 5009, column_count = 9L), latest = list(
            table_address = "0xa5a998000", names_address = "0xa5aa1c000", 
            v1_address = "0xa5c1953f0", copy_address = "0xa5c1953f0", 
            column_capacity = 5009, column_count = 9L)), after_physical = list(
            source = list(table_address = "0xa5ffc8000", names_address = "0xa5ffd4000", 
                v1_address = "0xa5e2c05f0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), first = list(
                table_address = "0xa5a920000", names_address = "0xa5a92c000", 
                v1_address = "0xa5c5d3dc8", copy_address = "0xa5c5d3dc8", 
                column_capacity = 5009, column_count = 9L), latest = list(
                table_address = "0xa5a9f8000", names_address = "0xa5aa04000", 
                v1_address = "0xa5f51f1c0", copy_address = "0xa5f51f1c0", 
                column_capacity = 5009, column_count = 9L)), 
        ncells = 11937, vector_bytes = 63664, rows = 64L, columns = c("v1", 
        "v2", "v3", "v4", "v5", "v6", "v7", "v8", "copy"), namespace_path = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"), 
    constructor = list(kind = "constructor", warm_calls = 25L, 
        measured_calls = 100L, before_heap = c(Ncells = 593936, 
        Vcells = 1053443), after_heap = c(Ncells = 596340, Vcells = 1055047
        ), before_physical = list(source = list(table_address = "0x997fc8000", 
            names_address = "0x997fd4000", v1_address = "0x9963805f0", 
            copy_address = NULL, column_capacity = 5008, column_count = 8L), 
            first = list(table_address = "0x994e98000", names_address = "0x994ea4000", 
                v1_address = "0x993c4ab68", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), latest = list(
                table_address = "0x994eb0000", names_address = "0x994ebc000", 
                v1_address = "0x993d0c7e8", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L)), 
        after_physical = list(source = list(table_address = "0x997fc8000", 
            names_address = "0x997fd4000", v1_address = "0x9963805f0", 
            copy_address = NULL, column_capacity = 5008, column_count = 8L), 
            first = list(table_address = "0x994e98000", names_address = "0x994ea4000", 
                v1_address = "0x993c4ab68", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), latest = list(
                table_address = "0x9934f0000", names_address = "0x9934fc000", 
                v1_address = "0x992dec3c0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L)), 
        ncells = 2404, vector_bytes = 12832, rows = 64L, columns = c("v1", 
        "v2", "v3", "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"), 
    reserve = list(kind = "reserve", warm_calls = 25L, measured_calls = 100L, 
        before_heap = c(Ncells = 594762, Vcells = 1034332), after_heap = c(Ncells = 597162, 
        Vcells = 1035932), before_physical = list(source = list(
            table_address = "0x8e67c8000", names_address = "0x8e67d4000", 
            v1_address = "0x8e90c05f0", copy_address = NULL, 
            column_capacity = 5008, column_count = 8L), first = list(
            table_address = "0x8e618b300", names_address = "0x8e618b600", 
            v1_address = "0x8ea076078", copy_address = NULL, 
            column_capacity = 40, column_count = 8L), latest = list(
            table_address = "0x8e618bd80", names_address = "0x8e61a0180", 
            v1_address = "0x8ea0b3348", copy_address = NULL, 
            column_capacity = 40, column_count = 8L)), after_physical = list(
            source = list(table_address = "0x8e67c8000", names_address = "0x8e67d4000", 
                v1_address = "0x8e90c05f0", copy_address = NULL, 
                column_capacity = 5008, column_count = 8L), first = list(
                table_address = "0x8e618b300", names_address = "0x8e618b600", 
                v1_address = "0x8ea076078", copy_address = NULL, 
                column_capacity = 40, column_count = 8L), latest = list(
                table_address = "0x8e627bc00", names_address = "0x8e627bd80", 
                v1_address = "0x8eacb52a0", copy_address = NULL, 
                column_capacity = 40, column_count = 8L)), ncells = 2400, 
        vector_bytes = 12800, rows = 64L, columns = c("v1", "v2", 
        "v3", "v4", "v5", "v6", "v7", "v8"), namespace_path = "/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01/library/dtatools"))
