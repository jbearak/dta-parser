list(blocks = 1L, passed = 10L, failed = 6L, errors = 0L, warnings = 0L, 
    skips = 0L)
