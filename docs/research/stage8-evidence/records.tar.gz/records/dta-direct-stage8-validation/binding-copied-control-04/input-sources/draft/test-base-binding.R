# Additive diagnostic only. Requires the unchanged control03 helpers/modules.
test_that("B11 base binding preserves standard edges and first applicable callbacks", {
    observed <- list()
    installed_methods <- character()
    events <- new.env(parent = emptyenv()); events$values <- list()
    flush <- function() {
        directory <- get("out", .GlobalEnv)
        saveRDS(observed, file.path(directory, "base-binding.rds"))
        dput(observed, file.path(directory, "base-binding.R"))
    }
    on.exit(flush(), add = TRUE)
    on.exit({
        if (length(installed_methods)) rm(list = installed_methods, envir = .GlobalEnv)
    }, add = TRUE)
    store <- new.env(parent = environment(.s8_record))
    store$.s8_records <- new.env(parent = emptyenv()); store$.s8_records$values <- list()
    record <- .s8_record; environment(record) <- store
    canonical <- function(value) {
        if (is.null(value)) return(NULL)
        stopifnot(identical(value$kind, "frame"))
        keys <- names(value$attributes)
        if (is.null(keys) || anyNA(keys) || any(keys == "") || anyDuplicated(keys))
            stop("Invalid top-level frame attribute names")
        value$attributes <- value$attributes[sort(keys)]
        value
    }
    marked_frame <- function(columns, classes = "data.frame", mode = "return", row_names = NULL) {
        value <- dtatools:::.reference_snapshot(do.call(dibble, columns))
        class(value) <- classes
        if (!is.null(row_names)) attr(value, "row.names") <- row_names
        attr(value, "stage8_base_mode") <- mode
        value <- dtatools:::.mark_reference_data(value,
            dtatools:::.new_reference_state(value, dibble = TRUE))
        stopifnot(is_dibble(value), dtatools:::.reference_state_valid(value),
            identical(class(dtatools:::.reference_snapshot(value)), classes))
        value
    }
    standard <- function(case) {
        if (case %in% c("rbind_factor", "rbind_ordered")) {
            factor_fn <- if (case == "rbind_factor") factor else ordered
            return(list(generic = "rbind", inputs = list(
                dibble(k = 1:2, f = factor_fn(c("a", "b"), levels = c("a", "b"))),
                data.frame(k = 3L, f = factor_fn("c", levels = c("b", "c")))),
                status = "return", dimensions = c(3L, 2L), factor_values = c("a", "b", "c")))
        }
        switch(case,
            rbind_matrix = list(generic = "rbind", inputs = list(
                dibble(k = 1:2, value = c(10, 20)),
                matrix(c(3, 30), nrow = 1L, dimnames = list(NULL, c("k", "value")))),
                status = "return", dimensions = c(3L, 2L)),
            rbind_row_names = list(generic = "rbind", inputs = list(
                marked_frame(list(k = 1:2, value = c(10, 20)), row_names = c("same", "left")),
                data.frame(k = 3L, value = 30, row.names = "same")),
                status = "return", dimensions = c(3L, 2L)),
            rbind_reordered = list(generic = "rbind", inputs = list(
                dibble(k = 1:2, value = c(10, 20)), data.frame(value = 30, k = 3L)),
                status = "return", dimensions = c(3L, 2L)),
            rbind_bad_names = list(generic = "rbind", inputs = list(
                dibble(k = 1:2, value = c(10, 20)), data.frame(k = 3L, other = 30)),
                status = "error"),
            cbind_matrix = list(generic = "cbind", inputs = list(
                dibble(k = 1:2), matrix(11:14, nrow = 2L,
                    dimnames = list(NULL, c("m1", "m2")))),
                status = "return", dimensions = c(2L, 3L)),
            cbind_scalar = list(generic = "cbind", inputs = list(dibble(k = 1:2), extra = 7L),
                status = "return", dimensions = c(2L, 2L)),
            cbind_divisible = list(generic = "cbind", inputs = list(
                dibble(k = 1:4), data.frame(extra = c(7L, 8L))),
                status = "return", dimensions = c(4L, 2L)),
            cbind_incompatible = list(generic = "cbind", inputs = list(
                dibble(k = 1:3), data.frame(extra = c(7L, 8L))), status = "error"),
            cbind_nonsyntactic = list(generic = "cbind", inputs = list(
                dibble(k = 1:2), setNames(data.frame(extra = 3:4), "odd name")),
                status = "return", dimensions = c(2L, 2L), column_names = c("k", "odd name")),
            cbind_duplicate = list(generic = "cbind", inputs = list(
                dibble(k = 1:2), data.frame(k = 3:4)), status = "error"),
            cbind_named_frames = list(generic = "cbind", inputs = list(
                left = dibble(k = 1:2, value = c(10, 20)), right = data.frame(a = 3:4, b = 5:6)),
                status = "return", dimensions = c(2L, 4L),
                column_names = c("left.k", "left.value", "right.a", "right.b")),
            cbind_empty_name = list(generic = "cbind", inputs = list(
                dibble(k = 1:2), setNames(data.frame(extra = 3:4), "")),
                status = "return", dimensions = c(2L, 2L)),
            stop("Unknown standard base-binding case"))
    }
    for (generic in c("rbind", "cbind")) for (tag in c("a", "b")) {
        method_name <- paste0(generic, ".stage8_base_dispatch_", tag)
        if (exists(method_name, .GlobalEnv, inherits = FALSE)) stop("Diagnostic method already exists")
        method <- local({
            selected_generic <- generic; selected_tag <- tag
            function(..., deparse.level = 1) {
                values <- list(...)
                frame <- environment()
                special <- function(name) if (exists(name, frame, inherits = FALSE))
                    get(name, frame, inherits = FALSE) else NULL
                mode <- attr(values[[1L]], "stage8_base_mode", exact = TRUE)
                events$values[[length(events$values) + 1L]] <- list(
                    selected_generic = selected_generic, selected_tag = selected_tag,
                    deparse_level = deparse.level, argument_names = names(values),
                    argument_classes = lapply(values, class),
                    generic_context = special(".Generic"), method_context = special(".Method"),
                    call = paste(deparse(sys.call()), collapse = "\n"),
                    parent_call = paste(deparse(sys.call(sys.parent())), collapse = "\n"))
                if (identical(mode, "error")) stop("Stage8 base callback sentinel", call. = FALSE)
                if (identical(mode, "warning")) warning("Stage8 base callback warning", call. = FALSE)
                data.frame(dispatched = rep.int(paste(selected_generic, selected_tag, sep = "/"), 2L))
            }
        })
        assign(method_name, method, envir = .GlobalEnv)
        installed_methods <- c(installed_methods, method_name)
    }
    dispatch <- function(shape, generic) {
        left <- if (generic == "rbind") list(k = 1:2, value = c(10, 20)) else list(k = 1:2)
        right <- if (generic == "rbind") list(k = 3:4, value = c(30, 40)) else list(extra = 3:4)
        foreign <- function(columns, tag = "a") structure(as.data.frame(columns),
            class = c(paste0("stage8_base_dispatch_", tag), "data.frame"), stage8_base_mode = "return")
        tag <- if (shape == "marked_second_class") "b" else "a"
        mode <- if (shape == "marked_warning") "warning" else if (shape == "marked_error") "error" else "return"
        inputs <- switch(shape,
            marked_first = list(marked_frame(left, c("stage8_base_dispatch_a", "stage8_base_dispatch_b", "data.frame")), as.data.frame(right)),
            marked_second_class = list(marked_frame(left, c("stage8_base_dispatch_missing", "stage8_base_dispatch_b", "data.frame")), as.data.frame(right)),
            standard_first = list(do.call(dibble, left), foreign(right)),
            ordinary_first = list(as.data.frame(left), marked_frame(right, c("stage8_base_dispatch_a", "data.frame"))),
            foreign_first = list(foreign(left), do.call(dibble, right)),
            marked_warning = list(marked_frame(left, c("stage8_base_dispatch_a", "data.frame"), mode), as.data.frame(right)),
            marked_error = list(marked_frame(left, c("stage8_base_dispatch_a", "data.frame"), mode), as.data.frame(right)),
            stop("Unknown dispatch case"))
        list(generic = generic, inputs = inputs, status = if (mode == "error") "error" else "return",
            callback_tag = if (shape %in% c("standard_first", "ordinary_first")) NULL else tag,
            expected_direct = !shape %in% c("ordinary_first", "foreign_first"))
    }
    observe <- function(id, fixture, route, callback = FALSE) {
        before <- .s8b_snapshot(fixture$inputs)
        events$values <- list(); .s8b_route$last <- NULL
        fn <- if (route == "public") getExportedValue("base", fixture$generic) else
            .s8b_operation("base", fixture$generic)
        answer <- record(id, do.call(fn, c(fixture$inputs, list(deparse.level = 2L))))
        saved <- store$.s8_records$values[[id]]
        saved$events <- events$values; saved$before <- before
        saved$selected_route <- if (route == "public") list(route = "public", direct = FALSE) else .s8b_route$last
        saved$expected <- fixture[c("status", "dimensions", "column_names", "callback_tag", "expected_direct")]
        saved$after <- list(status = "pending"); observed[[id]] <<- saved
        saved$after <- .s8b_snapshot(fixture$inputs); observed[[id]] <<- saved
        flush()
        expect_identical(before$status, "complete", info = id)
        expect_identical(saved$after$status, "complete", info = id)
        expect_identical(saved$after$value, before$value, info = id)
        expect_identical(saved$status, fixture$status, info = id)
        expect_identical(saved$snapshot_status,
            if (saved$status == "return") "complete" else "not_applicable", info = id)
        if (route == "copied") expect_identical(saved$selected_route$direct,
            if (callback) fixture$expected_direct else TRUE, info = id)
        if (saved$status == "return") {
            expect_true(is.data.frame(answer$value), info = id)
            if (!is.null(fixture$dimensions)) expect_identical(dim(answer$value), fixture$dimensions, info = id)
            if (!is.null(fixture$column_names)) expect_identical(names(answer$value), fixture$column_names, info = id)
            if (!is.null(fixture$factor_values)) expect_identical(as.character(answer$value$f), fixture$factor_values, info = id)
        }
        if (callback) {
            expect_identical(length(saved$events), if (is.null(fixture$callback_tag)) 0L else 1L, info = id)
            if (length(saved$events)) {
                expect_identical(saved$events[[1L]]$selected_tag, fixture$callback_tag, info = id)
                expect_identical(saved$events[[1L]]$selected_generic, fixture$generic, info = id)
                expect_identical(saved$events[[1L]]$deparse_level, 2L, info = id)
            }
        } else expect_identical(length(saved$events), 0L, info = id)
        saved
    }
    parity <- function(pair, id) {
        expect_identical(pair$copied$status, pair$public$status, info = id)
        expect_identical(canonical(pair$copied$value), canonical(pair$public$value), info = id)
        expect_identical(pair$copied$error$classes, pair$public$error$classes, info = id)
        expect_identical(pair$copied$error$message, pair$public$error$message, info = id)
        expect_identical(lapply(pair$copied$conditions, function(x) x[c("classes", "message")]),
            lapply(pair$public$conditions, function(x) x[c("classes", "message")]), info = id)
        selected <- c("selected_generic", "selected_tag", "deparse_level", "argument_names",
            "argument_classes", "generic_context", "method_context")
        expect_identical(lapply(pair$copied$events, function(x) x[selected]),
            lapply(pair$public$events, function(x) x[selected]), info = id)
    }
    cases <- c("rbind_factor", "rbind_ordered", "rbind_matrix", "rbind_row_names", "rbind_reordered",
        "rbind_bad_names", "cbind_matrix", "cbind_scalar", "cbind_divisible", "cbind_incompatible",
        "cbind_nonsyntactic", "cbind_duplicate", "cbind_named_frames", "cbind_empty_name")
    for (case in cases) {
        pair <- list()
        for (route in c("public", "copied")) pair[[route]] <- observe(
            paste("B11", case, route, sep = "/"), standard(case), route)
        parity(pair, case)
    }
    for (generic in c("rbind", "cbind")) for (shape in c("marked_first", "marked_second_class",
        "standard_first", "ordinary_first", "foreign_first", "marked_warning", "marked_error")) {
        pair <- list()
        for (route in c("public", "copied")) pair[[route]] <- observe(
            paste("B11", generic, shape, route, sep = "/"), dispatch(shape, generic), route, TRUE)
        parity(pair, paste(generic, shape, sep = "/"))
    }
    flush()
    expect_identical(length(observed), 56L)
    expect_identical(length(unique(names(observed))), 56L)
})
