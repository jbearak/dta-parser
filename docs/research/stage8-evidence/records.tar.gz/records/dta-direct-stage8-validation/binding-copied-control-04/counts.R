list(blocks = 2L, passed = 687L, failed = 0L, errors = 0L, warnings = 0L, 
    skips = 0L)
