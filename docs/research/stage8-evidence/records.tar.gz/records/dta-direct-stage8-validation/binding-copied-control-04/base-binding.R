list(`B11/rbind_factor/public` = list(id = "B11/rbind_factor/public", 
    status = "return", conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "f"), row.names = 1:3, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), f = list(kind = "integer", attributes = list(
            levels = c("a", "b", "c"), class = "factor"), values = 1:3))), 
    events = list(), before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "f"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), f = list(kind = "integer", attributes = list(levels = c("a", 
        "b"), class = "factor"), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = "factor"), 
                values = 2L))))), selected_route = list(route = "public", 
        direct = FALSE), expected = structure(list("return", 
        3:2, NULL, NULL, NULL), names = c("status", "dimensions", 
    NA, NA, NA)), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "f"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), f = list(kind = "integer", attributes = list(levels = c("a", 
        "b"), class = "factor"), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = "factor"), 
                values = 2L)))))), `B11/rbind_factor/copied` = list(
    id = "B11/rbind_factor/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "f"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), f = list(kind = "integer", 
        attributes = list(levels = c("a", "b", "c"), class = "factor"), 
        values = 1:3))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), f = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = "factor"), 
                values = 1:2))), list(kind = "frame", attributes = list(
            names = c("k", "f"), class = "data.frame", row.names = 1L), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3L), f = list(kind = "integer", attributes = list(
                levels = c("b", "c"), class = "factor"), values = 2L))))), 
    selected_route = list(namespace = "base", name = "rbind", 
        direct = TRUE), expected = structure(list("return", 3:2, 
        NULL, NULL, NULL), names = c("status", "dimensions", 
    NA, NA, NA)), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "f"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), f = list(kind = "integer", attributes = list(levels = c("a", 
        "b"), class = "factor"), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = "factor"), 
                values = 2L)))))), `B11/rbind_ordered/public` = list(
    id = "B11/rbind_ordered/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "f"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), f = list(kind = "integer", 
        attributes = list(levels = c("a", "b", "c"), class = c("ordered", 
        "factor")), values = 1:3))), events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), f = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = c("ordered", 
            "factor")), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = c("ordered", 
                "factor")), values = 2L))))), selected_route = list(
        route = "public", direct = FALSE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), f = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = c("ordered", 
                "factor")), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = c("ordered", 
                "factor")), values = 2L)))))), `B11/rbind_ordered/copied` = list(
    id = "B11/rbind_ordered/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "f"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), f = list(kind = "integer", 
        attributes = list(levels = c("a", "b", "c"), class = c("ordered", 
        "factor")), values = 1:3))), events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), f = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = c("ordered", 
            "factor")), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = c("ordered", 
                "factor")), values = 2L))))), selected_route = list(
        namespace = "base", name = "rbind", direct = TRUE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), f = list(kind = "integer", 
                attributes = list(levels = c("a", "b"), class = c("ordered", 
                "factor")), values = 1:2))), list(kind = "frame", 
            attributes = list(names = c("k", "f"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), f = list(kind = "integer", 
                attributes = list(levels = c("b", "c"), class = c("ordered", 
                "factor")), values = 2L)))))), `B11/rbind_matrix/public` = list(
    id = "B11/rbind_matrix/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "double", 
            attributes = list(dim = 1:2, dimnames = list(NULL, 
                c("k", "value"))), values = c(3, 30)))), selected_route = list(
        route = "public", direct = FALSE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "double", 
            attributes = list(dim = 1:2, dimnames = list(NULL, 
                c("k", "value"))), values = c(3, 30))))), `B11/rbind_matrix/copied` = list(
    id = "B11/rbind_matrix/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "double", 
            attributes = list(dim = 1:2, dimnames = list(NULL, 
                c("k", "value"))), values = c(3, 30)))), selected_route = list(
        namespace = "base", name = "rbind", direct = TRUE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "double", 
            attributes = list(dim = 1:2, dimnames = list(NULL, 
                c("k", "value"))), values = c(3, 30))))), `B11/rbind_row_names/public` = list(
    id = "B11/rbind_row_names/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(stage8_base_mode = "return", 
        names = c("k", "value"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), 
        columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2, 3)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = c("same", "left"), class = c("dibble", 
            "dtatools_ref_data", "data.frame"), stage8_base_mode = "return"), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = "same"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3L), value = list(kind = "double", attributes = NULL, 
                values = 30))))), selected_route = list(route = "public", 
        direct = FALSE), expected = structure(list("return", 
        3:2, NULL, NULL, NULL), names = c("status", "dimensions", 
    NA, NA, NA)), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = c("same", "left"
            ), class = c("dibble", "dtatools_ref_data", "data.frame"
            ), stage8_base_mode = "return"), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = "same"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3L), value = list(kind = "double", attributes = NULL, 
                values = 30)))))), `B11/rbind_row_names/copied` = list(
    id = "B11/rbind_row_names/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(stage8_base_mode = "return", 
        names = c("k", "value"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), 
        columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2, 3)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = c("same", "left"), class = c("dibble", 
            "dtatools_ref_data", "data.frame"), stage8_base_mode = "return"), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = "same"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3L), value = list(kind = "double", attributes = NULL, 
                values = 30))))), selected_route = list(namespace = "base", 
        name = "rbind", direct = TRUE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = c("same", "left"), class = c("dibble", 
            "dtatools_ref_data", "data.frame"), stage8_base_mode = "return"), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = "same"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3L), value = list(kind = "double", attributes = NULL, 
                values = 30)))))), `B11/rbind_reordered/public` = list(
    id = "B11/rbind_reordered/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("value", "k"), class = "data.frame", 
                row.names = 1L), columns = list(value = list(
                kind = "double", attributes = NULL, values = 30), 
                k = list(kind = "integer", attributes = NULL, 
                  values = 3L))))), selected_route = list(route = "public", 
        direct = FALSE), expected = structure(list("return", 
        3:2, NULL, NULL, NULL), names = c("status", "dimensions", 
    NA, NA, NA)), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20)))), list(kind = "frame", attributes = list(names = c("value", 
        "k"), class = "data.frame", row.names = 1L), columns = list(
            value = list(kind = "double", attributes = NULL, 
                values = 30), k = list(kind = "integer", attributes = NULL, 
                values = 3L)))))), `B11/rbind_reordered/copied` = list(
    id = "B11/rbind_reordered/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 3)), value = list(kind = "double", 
        attributes = list(stata.storage = "double", class = c("dta_numeric", 
        "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20, 30)))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("value", "k"), class = "data.frame", 
                row.names = 1L), columns = list(value = list(
                kind = "double", attributes = NULL, values = 30), 
                k = list(kind = "integer", attributes = NULL, 
                  values = 3L))))), selected_route = list(namespace = "base", 
        name = "rbind", direct = TRUE), expected = structure(list(
        "return", 3:2, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("value", "k"), class = "data.frame", 
                row.names = 1L), columns = list(value = list(
                kind = "double", attributes = NULL, values = 30), 
                k = list(kind = "integer", attributes = NULL, 
                  values = 3L)))))), `B11/rbind_bad_names/public` = list(
    id = "B11/rbind_bad_names/public", status = "error", conditions = list(), 
    error = list(classes = c("simpleError", "error", "condition"
    ), message = "names do not match previous names", call = "match.names(clabs, names(xi))", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "other"), class = "data.frame", row.names = 1L), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 3L), 
            other = list(kind = "double", attributes = NULL, 
                values = 30))))), selected_route = list(route = "public", 
        direct = FALSE), expected = structure(list("error", NULL, 
        NULL, NULL, NULL), names = c("status", NA, NA, NA, NA
    )), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20)))), list(kind = "frame", attributes = list(names = c("k", 
        "other"), class = "data.frame", row.names = 1L), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 3L), 
            other = list(kind = "double", attributes = NULL, 
                values = 30)))))), `B11/rbind_bad_names/copied` = list(
    id = "B11/rbind_bad_names/copied", status = "error", conditions = list(), 
    error = list(classes = c("simpleError", "error", "condition"
    ), message = "names do not match previous names", call = "match.names(clabs, names(xi))", 
        parent = NULL), snapshot_status = "not_applicable", snapshot_conditions = list(), 
    snapshot_error = NULL, value = NULL, events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "other"), class = "data.frame", row.names = 1L), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 3L), 
            other = list(kind = "double", attributes = NULL, 
                values = 30))))), selected_route = list(namespace = "base", 
        name = "rbind", direct = TRUE), expected = structure(list(
        "error", NULL, NULL, NULL, NULL), names = c("status", 
    NA, NA, NA, NA)), after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
        20)))), list(kind = "frame", attributes = list(names = c("k", 
        "other"), class = "data.frame", row.names = 1L), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 3L), 
            other = list(kind = "double", attributes = NULL, 
                values = 30)))))), `B11/cbind_matrix/public` = list(
    id = "B11/cbind_matrix/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "m1", "m2"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), m1 = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = c(11, 
        12)), m2 = list(kind = "double", attributes = list(stata.storage = "long", 
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        )), values = c(13, 14)))), events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = "k", 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)))), list(kind = "integer", 
            attributes = list(dim = c(2L, 2L), dimnames = list(
                NULL, c("m1", "m2"))), values = 11:14))), selected_route = list(
        route = "public", direct = FALSE), expected = structure(list(
        "return", 2:3, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = "k", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), list(kind = "integer", 
            attributes = list(dim = c(2L, 2L), dimnames = list(
                NULL, c("m1", "m2"))), values = 11:14)))), `B11/cbind_matrix/copied` = list(
    id = "B11/cbind_matrix/copied", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "m1", "m2"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), m1 = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = c(11, 
        12)), m2 = list(kind = "double", attributes = list(stata.storage = "long", 
        class = c("dta_numeric", "dta_long", "vctrs_vctr", "double"
        )), values = c(13, 14)))), events = list(), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = "k", 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)))), list(kind = "integer", 
            attributes = list(dim = c(2L, 2L), dimnames = list(
                NULL, c("m1", "m2"))), values = 11:14))), selected_route = list(
        namespace = "base", name = "cbind", direct = TRUE), expected = structure(list(
        "return", 2:3, NULL, NULL, NULL), names = c("status", 
    "dimensions", NA, NA, NA)), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = "k", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), list(kind = "integer", 
            attributes = list(dim = c(2L, 2L), dimnames = list(
                NULL, c("m1", "m2"))), values = 11:14)))), `B11/cbind_scalar/public` = list(
    id = "B11/cbind_scalar/public", status = "return", conditions = list(), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "extra"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2)), extra = list(kind = "double", 
        attributes = list(stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), values = c(7, 7
        )))), events = list(), before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = "k", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), extra = list(
            kind = "integer", attributes = NULL, values = 7L))), 
    selected_route = list(route = "public", direct = FALSE), 
    expected = structure(list("return", c(2L, 2L), NULL, NULL, 
        NULL), names = c("status", "dimensions", NA, NA, NA)), 
    after = list(status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = "k", 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)))), extra = list(
            kind = "integer", attributes = NULL, values = 7L)))), 
    `B11/cbind_scalar/copied` = list(id = "B11/cbind_scalar/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "extra"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), extra = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(7, 
            7)))), events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), extra = list(kind = "integer", attributes = NULL, 
                values = 7L))), selected_route = list(namespace = "base", 
            name = "cbind", direct = TRUE), expected = structure(list(
            "return", c(2L, 2L), NULL, NULL, NULL), names = c("status", 
        "dimensions", NA, NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), extra = list(kind = "integer", attributes = NULL, 
                values = 7L)))), `B11/cbind_divisible/public` = list(
        id = "B11/cbind_divisible/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), row.names = 1:4, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(7, 8, 7, 8)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:4, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3, 4)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", c(4L, 2L), NULL, NULL, NULL), names = c("status", 
        "dimensions", NA, NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3, 4)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8)))))), `B11/cbind_divisible/copied` = list(
        id = "B11/cbind_divisible/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), row.names = 1:4, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(7, 8, 7, 8)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:4, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3, 4)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", c(4L, 2L), NULL, 
            NULL, NULL), names = c("status", "dimensions", NA, 
        NA, NA)), after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:4, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3, 4)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8)))))), `B11/cbind_incompatible/public` = list(
        id = "B11/cbind_incompatible/public", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "arguments imply differing number of rows: 3, 2", 
            call = "data.frame(..., check.names = FALSE)", parent = NULL), 
        snapshot_status = "not_applicable", snapshot_conditions = list(), 
        snapshot_error = NULL, value = NULL, events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "error", NULL, NULL, NULL, NULL), names = c("status", 
        NA, NA, NA, NA)), after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8)))))), `B11/cbind_incompatible/copied` = list(
        id = "B11/cbind_incompatible/copied", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "arguments imply differing number of rows: 3, 2", 
            call = ".dibble_base_data_frame(..., check.names = FALSE)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2, 3)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("error", NULL, NULL, NULL, 
            NULL), names = c("status", NA, NA, NA, NA)), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:3, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 7:8)))))), `B11/cbind_nonsyntactic/public` = list(
        id = "B11/cbind_nonsyntactic/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "odd name"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), `odd name` = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "odd name", class = "data.frame", row.names = 1:2), 
                columns = list(`odd name` = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", c(2L, 2L), c("k", "odd name"), NULL, NULL), names = c("status", 
        "dimensions", "column_names", NA, NA)), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "odd name", class = "data.frame", row.names = 1:2), 
                columns = list(`odd name` = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind_nonsyntactic/copied` = list(
        id = "B11/cbind_nonsyntactic/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "odd name"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), `odd name` = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "odd name", class = "data.frame", row.names = 1:2), 
                columns = list(`odd name` = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", c(2L, 2L), c("k", 
        "odd name"), NULL, NULL), names = c("status", "dimensions", 
        "column_names", NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "odd name", class = "data.frame", row.names = 1:2), 
                columns = list(`odd name` = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind_duplicate/public` = list(
        id = "B11/cbind_duplicate/public", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("error", 
            NULL, NULL, NULL, NULL), names = c("status", NA, 
        NA, NA, NA)), after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4)))))), `B11/cbind_duplicate/copied` = list(
        id = "B11/cbind_duplicate/copied", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4))))), selected_route = list(namespace = "base", 
            name = "cbind", direct = TRUE), expected = structure(list(
            "error", NULL, NULL, NULL, NULL), names = c("status", 
        NA, NA, NA, NA)), after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4)))))), `B11/cbind_named_frames/public` = list(
        id = "B11/cbind_named_frames/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("left.k", "left.value", 
            "right.a", "right.b"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(left.k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), left.value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), right.a = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), right.b = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(5, 
            6)))), events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), right = list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:2), 
                columns = list(a = list(kind = "integer", attributes = NULL, 
                  values = 3:4), b = list(kind = "integer", attributes = NULL, 
                  values = 5:6))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            c(2L, 4L), c("left.k", "left.value", "right.a", "right.b"
            ), NULL, NULL), names = c("status", "dimensions", 
        "column_names", NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), right = list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:2), 
                columns = list(a = list(kind = "integer", attributes = NULL, 
                  values = 3:4), b = list(kind = "integer", attributes = NULL, 
                  values = 5:6)))))), `B11/cbind_named_frames/copied` = list(
        id = "B11/cbind_named_frames/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("left.k", "left.value", 
            "right.a", "right.b"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(left.k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), left.value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), right.a = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), right.b = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(5, 
            6)))), events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), right = list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:2), 
                columns = list(a = list(kind = "integer", attributes = NULL, 
                  values = 3:4), b = list(kind = "integer", attributes = NULL, 
                  values = 5:6))))), selected_route = list(namespace = "base", 
            name = "cbind", direct = TRUE), expected = structure(list(
            "return", c(2L, 4L), c("left.k", "left.value", "right.a", 
            "right.b"), NULL, NULL), names = c("status", "dimensions", 
        "column_names", NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), right = list(kind = "frame", attributes = list(
                names = c("a", "b"), class = "data.frame", row.names = 1:2), 
                columns = list(a = list(kind = "integer", attributes = NULL, 
                  values = 3:4), b = list(kind = "integer", attributes = NULL, 
                  values = 5:6)))))), `B11/cbind_empty_name/public` = list(
        id = "B11/cbind_empty_name/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "Var.2"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), Var.2 = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "", class = "data.frame", row.names = 1:2), 
                columns = structure(list(list(kind = "integer", 
                  attributes = NULL, values = 3:4)), names = "")))), 
        selected_route = list(route = "public", direct = FALSE), 
        expected = structure(list("return", c(2L, 2L), NULL, 
            NULL, NULL), names = c("status", "dimensions", NA, 
        NA, NA)), after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "", class = "data.frame", row.names = 1:2), 
                columns = structure(list(list(kind = "integer", 
                  attributes = NULL, values = 3:4)), names = ""))))), 
    `B11/cbind_empty_name/copied` = list(id = "B11/cbind_empty_name/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "Var.2"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), Var.2 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)))), events = list(), before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "", class = "data.frame", row.names = 1:2), 
                columns = structure(list(list(kind = "integer", 
                  attributes = NULL, values = 3:4)), names = "")))), 
        selected_route = list(namespace = "base", name = "cbind", 
            direct = TRUE), expected = structure(list("return", 
            c(2L, 2L), NULL, NULL, NULL), names = c("status", 
        "dimensions", NA, NA, NA)), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "", class = "data.frame", row.names = 1:2), 
                columns = structure(list(list(kind = "integer", 
                  attributes = NULL, values = 3:4)), names = ""))))), 
    `B11/rbind/marked_first/public` = list(id = "B11/rbind/marked_first/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = "dispatched", 
            row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(dispatched = list(
            kind = "character", attributes = list(stata.string.storage = "str7"), 
            values = c("rbind/a", "rbind/a")))), events = list(
            list(selected_generic = "rbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "rbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"stage8_base_dispatch_b\", \n\"data.frame\"), stage8_base_mode = \"return\"), structure(list(k = 3:4, \n    value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, "a", TRUE), names = c("status", NA, NA, 
        "callback_tag", "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_first/copied` = list(
        id = "B11/rbind/marked_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("rbind/a", "rbind/a")))), events = list(
            list(selected_generic = "rbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "rbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"stage8_base_dispatch_b\", \n\"data.frame\"), stage8_base_mode = \"return\"), structure(list(k = 3:4, \n    value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = TRUE), expected = structure(list(
            "return", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_second_class/public` = list(
        id = "B11/rbind/marked_second_class/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("rbind/b", "rbind/b")))), events = list(
            list(selected_generic = "rbind", selected_tag = "b", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_missing", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "rbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_missing\", \"stage8_base_dispatch_b\", \n\"data.frame\"), stage8_base_mode = \"return\"), structure(list(k = 3:4, \n    value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, "b", TRUE), names = c("status", NA, NA, 
        "callback_tag", "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_second_class/copied` = list(
        id = "B11/rbind/marked_second_class/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("rbind/b", "rbind/b")))), events = list(
            list(selected_generic = "rbind", selected_tag = "b", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_missing", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "rbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_missing\", \"stage8_base_dispatch_b\", \n\"data.frame\"), stage8_base_mode = \"return\"), structure(list(k = 3:4, \n    value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = TRUE), expected = structure(list(
            "return", NULL, NULL, "b", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/standard_first/public` = list(
        id = "B11/rbind/standard_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:4, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20, 30, 40)))), 
        events = list(), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_base_dispatch_a", "data.frame"
            ), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        selected_route = list(route = "public", direct = FALSE), 
        expected = structure(list("return", NULL, NULL, NULL, 
            TRUE), names = c("status", NA, NA, "callback_tag", 
        "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `B11/rbind/standard_first/copied` = list(id = "B11/rbind/standard_first/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
            kind = "double", attributes = list(stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20, 30, 40)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_base_dispatch_a", "data.frame"
            ), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        selected_route = list(namespace = "base", name = "rbind", 
            direct = TRUE), expected = structure(list("return", 
            NULL, NULL, NULL, TRUE), names = c("status", NA, 
        NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_base_dispatch_a", "data.frame"
            ), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `B11/rbind/ordinary_first/public` = list(id = "B11/rbind/ordinary_first/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:4, class = "data.frame"), columns = list(
            k = list(kind = "double", attributes = NULL, values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = NULL, 
                values = c(10, 20, 30, 40)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, NULL, FALSE), names = c("status", NA, 
        NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40))))))), `B11/rbind/ordinary_first/copied` = list(
        id = "B11/rbind/ordinary_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:4, 
                class = "data.frame"), columns = list(k = list(
                kind = "double", attributes = NULL, values = c(1, 
                2, 3, 4)), value = list(kind = "double", attributes = NULL, 
                values = c(10, 20, 30, 40)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, NULL, FALSE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40))))))), `B11/rbind/foreign_first/public` = list(
        id = "B11/rbind/foreign_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", class = "data.frame", 
                row.names = 1:2), columns = list(dispatched = list(
                kind = "character", attributes = NULL, values = c("rbind/a", 
                "rbind/a")))), events = list(list(selected_generic = "rbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), generic_context = NULL, method_context = NULL, 
            call = "rbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = 1:2, \n    value = c(10, 20)), class = c(\"stage8_base_dispatch_a\", \"data.frame\"\n), row.names = 1:2, stage8_base_mode = \"return\"), structure(list(\n    k = structure(c(3, 4), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(30, \n    40), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n    \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, "a", FALSE), names = c("status", NA, 
        NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40))))))), `B11/rbind/foreign_first/copied` = list(
        id = "B11/rbind/foreign_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", class = "data.frame", 
                row.names = 1:2), columns = list(dispatched = list(
                kind = "character", attributes = NULL, values = c("rbind/a", 
                "rbind/a")))), events = list(list(selected_generic = "rbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), generic_context = NULL, method_context = NULL, 
            call = "rbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = 1:2, \n    value = c(10, 20)), class = c(\"stage8_base_dispatch_a\", \"data.frame\"\n), row.names = 1:2, stage8_base_mode = \"return\"), structure(list(\n    k = structure(c(3, 4), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(30, \n    40), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n    \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, "a", FALSE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(30, 
                40))))))), `B11/rbind/marked_warning/public` = list(
        id = "B11/rbind/marked_warning/public", status = "return", 
        conditions = list(list(classes = c("simpleWarning", "warning", 
        "condition"), message = "Stage8 base callback warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("rbind/a", "rbind/a")))), events = list(
            list(selected_generic = "rbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "data.frame"), 
                  "data.frame"), generic_context = NULL, method_context = NULL, 
                call = "rbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"data.frame\"), stage8_base_mode = \"warning\"), \n    structure(list(k = 3:4, value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, "a", TRUE), names = c("status", NA, NA, 
        "callback_tag", "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_warning/copied` = list(
        id = "B11/rbind/marked_warning/copied", status = "return", 
        conditions = list(list(classes = c("simpleWarning", "warning", 
        "condition"), message = "Stage8 base callback warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("rbind/a", "rbind/a")))), events = list(
            list(selected_generic = "rbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "data.frame"), 
                  "data.frame"), generic_context = NULL, method_context = NULL, 
                call = "rbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"data.frame\"), stage8_base_mode = \"warning\"), \n    structure(list(k = 3:4, value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = TRUE), expected = structure(list(
            "return", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_error/public` = list(
        id = "B11/rbind/marked_error/public", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 base callback sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(list(selected_generic = "rbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), "data.frame"), generic_context = NULL, 
            method_context = NULL, call = "rbind(deparse.level, ...)", 
            parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"data.frame\"), stage8_base_mode = \"error\"), \n    structure(list(k = 3:4, value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "double", 
                    class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), class = "data.frame", 
                  row.names = 1:2), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = NULL, values = c(30, 
                  40)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("error", 
            NULL, NULL, "a", TRUE), names = c("status", NA, NA, 
        "callback_tag", "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(10, 
                  20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = NULL, values = c(30, 
                40))))))), `B11/rbind/marked_error/copied` = list(
        id = "B11/rbind/marked_error/copied", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 base callback sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(list(selected_generic = "rbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), "data.frame"), generic_context = NULL, 
            method_context = NULL, call = "rbind(deparse.level, ...)", 
            parent_call = "(function (..., deparse.level = 1) \n.Internal(rbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\")), value = structure(c(10, 20), stata.storage = \"double\", class = c(\"dta_numeric\", \n\"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L\n), class = c(\"stage8_base_dispatch_a\", \"data.frame\"), stage8_base_mode = \"error\"), \n    structure(list(k = 3:4, value = c(30, 40)), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "double", 
                    class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), class = "data.frame", 
                  row.names = 1:2), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = NULL, values = c(30, 
                  40)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = TRUE), expected = structure(list(
            "error", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "double", 
                    class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), class = "data.frame", 
                  row.names = 1:2), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = NULL, values = c(30, 
                  40))))))), `B11/cbind/marked_first/public` = list(
        id = "B11/cbind/marked_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/a", "cbind/a")))), events = list(
            list(selected_generic = "cbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "cbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"stage8_base_dispatch_b\", \"data.frame\"), stage8_base_mode = \"return\"), \n    structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/marked_first/copied` = list(
        id = "B11/cbind/marked_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/a", "cbind/a")))), events = list(
            list(selected_generic = "cbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "cbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"stage8_base_dispatch_b\", \"data.frame\"), stage8_base_mode = \"return\"), \n    structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", NULL, NULL, "a", 
            TRUE), names = c("status", NA, NA, "callback_tag", 
        "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "stage8_base_dispatch_a", "stage8_base_dispatch_b", 
                  "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/marked_second_class/public` = list(
        id = "B11/cbind/marked_second_class/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/b", "cbind/b")))), events = list(
            list(selected_generic = "cbind", selected_tag = "b", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_missing", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "cbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_missing\", \n\"stage8_base_dispatch_b\", \"data.frame\"), stage8_base_mode = \"return\"), \n    structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, "b", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/marked_second_class/copied` = list(
        id = "B11/cbind/marked_second_class/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/b", "cbind/b")))), events = list(
            list(selected_generic = "cbind", selected_tag = "b", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_missing", "stage8_base_dispatch_b", 
                  "data.frame"), "data.frame"), generic_context = NULL, 
                method_context = NULL, call = "cbind(deparse.level, ...)", 
                parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_missing\", \n\"stage8_base_dispatch_b\", \"data.frame\"), stage8_base_mode = \"return\"), \n    structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n    -2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_missing", 
                "stage8_base_dispatch_b", "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", NULL, NULL, "b", 
            TRUE), names = c("status", NA, NA, "callback_tag", 
        "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "stage8_base_dispatch_missing", "stage8_base_dispatch_b", 
                  "data.frame"), stage8_base_mode = "return"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/standard_first/public` = list(
        id = "B11/cbind/standard_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, NULL, TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/standard_first/copied` = list(
        id = "B11/cbind/standard_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", NULL, NULL, NULL, 
            TRUE), names = c("status", NA, NA, "callback_tag", 
        "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)))), list(kind = "frame", attributes = list(
                names = "extra", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/ordinary_first/public` = list(
        id = "B11/cbind/ordinary_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, NULL, FALSE), names = c("status", NA, 
        NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4))))))), `B11/cbind/ordinary_first/copied` = list(
        id = "B11/cbind/ordinary_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "extra"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)))), events = list(), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)))))), selected_route = list(namespace = "base", 
            name = "cbind", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, NULL, FALSE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "return"), 
                columns = list(extra = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4))))))), `B11/cbind/foreign_first/public` = list(
        id = "B11/cbind/foreign_first/public", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", class = "data.frame", 
                row.names = 1:2), columns = list(dispatched = list(
                kind = "character", attributes = NULL, values = c("cbind/a", 
                "cbind/a")))), events = list(list(selected_generic = "cbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), generic_context = NULL, method_context = NULL, 
            call = "cbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = 1:2), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), row.names = 1:2, stage8_base_mode = \"return\"), \n    structure(list(extra = structure(c(3, 4), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, \n    -2L), class = c(\"dibble\", \"dtatools_ref_data\", \"tbl_df\", \n    \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(extra = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)))))), selected_route = list(route = "public", 
            direct = FALSE), expected = structure(list("return", 
            NULL, NULL, "a", FALSE), names = c("status", NA, 
        NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(extra = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4))))))), `B11/cbind/foreign_first/copied` = list(
        id = "B11/cbind/foreign_first/copied", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", class = "data.frame", 
                row.names = 1:2), columns = list(dispatched = list(
                kind = "character", attributes = NULL, values = c("cbind/a", 
                "cbind/a")))), events = list(list(selected_generic = "cbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), generic_context = NULL, method_context = NULL, 
            call = "cbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = 1:2), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), row.names = 1:2, stage8_base_mode = \"return\"), \n    structure(list(extra = structure(c(3, 4), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, \n    -2L), class = c(\"dibble\", \"dtatools_ref_data\", \"tbl_df\", \n    \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(extra = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)))))), selected_route = list(namespace = "base", 
            name = "cbind", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, "a", FALSE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", class = c("stage8_base_dispatch_a", 
                "data.frame"), row.names = 1:2, stage8_base_mode = "return"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2))), list(kind = "frame", attributes = list(
                names = "extra", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(extra = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4))))))), `B11/cbind/marked_warning/public` = list(
        id = "B11/cbind/marked_warning/public", status = "return", 
        conditions = list(list(classes = c("simpleWarning", "warning", 
        "condition"), message = "Stage8 base callback warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/a", "cbind/a")))), events = list(
            list(selected_generic = "cbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "data.frame"), 
                  "data.frame"), generic_context = NULL, method_context = NULL, 
                call = "cbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), stage8_base_mode = \"warning\"), structure(list(\n    extra = 3:4), class = \"data.frame\", row.names = c(NA, -2L\n)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            route = "public", direct = FALSE), expected = structure(list(
            "return", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/marked_warning/copied` = list(
        id = "B11/cbind/marked_warning/copied", status = "return", 
        conditions = list(list(classes = c("simpleWarning", "warning", 
        "condition"), message = "Stage8 base callback warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "dispatched", row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(dispatched = list(
                kind = "character", attributes = list(stata.string.storage = "str7"), 
                values = c("cbind/a", "cbind/a")))), events = list(
            list(selected_generic = "cbind", selected_tag = "a", 
                deparse_level = 2L, argument_names = NULL, argument_classes = list(
                  c("stage8_base_dispatch_a", "data.frame"), 
                  "data.frame"), generic_context = NULL, method_context = NULL, 
                call = "cbind(deparse.level, ...)", parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), stage8_base_mode = \"warning\"), structure(list(\n    extra = 3:4), class = \"data.frame\", row.names = c(NA, -2L\n)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        expected = structure(list("return", NULL, NULL, "a", 
            TRUE), names = c("status", NA, NA, "callback_tag", 
        "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "stage8_base_dispatch_a", "data.frame"), stage8_base_mode = "warning"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))), `B11/cbind/marked_error/public` = list(
        id = "B11/cbind/marked_error/public", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 base callback sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(list(selected_generic = "cbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), "data.frame"), generic_context = NULL, 
            method_context = NULL, call = "cbind(deparse.level, ...)", 
            parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), stage8_base_mode = \"error\"), structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), list(kind = "frame", 
                attributes = list(names = "extra", class = "data.frame", 
                  row.names = 1:2), columns = list(extra = list(
                  kind = "integer", attributes = NULL, values = 3:4))))), 
        selected_route = list(route = "public", direct = FALSE), 
        expected = structure(list("error", NULL, NULL, "a", TRUE), names = c("status", 
        NA, NA, "callback_tag", "expected_direct")), after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), list(kind = "frame", 
                attributes = list(names = "extra", class = "data.frame", 
                  row.names = 1:2), columns = list(extra = list(
                  kind = "integer", attributes = NULL, values = 3:4)))))), 
    `B11/cbind/marked_error/copied` = list(id = "B11/cbind/marked_error/copied", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 base callback sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = list(list(selected_generic = "cbind", 
            selected_tag = "a", deparse_level = 2L, argument_names = NULL, 
            argument_classes = list(c("stage8_base_dispatch_a", 
            "data.frame"), "data.frame"), generic_context = NULL, 
            method_context = NULL, call = "cbind(deparse.level, ...)", 
            parent_call = "(function (..., deparse.level = 1) \n.Internal(cbind(deparse.level, ...)))(structure(list(k = structure(c(1, \n2), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"stage8_base_dispatch_a\", \n\"data.frame\"), stage8_base_mode = \"error\"), structure(list(extra = 3:4), class = \"data.frame\", row.names = c(NA, \n-2L)), deparse.level = 2L)")), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = "k", row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "stage8_base_dispatch_a", 
                "data.frame"), stage8_base_mode = "error"), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)))), list(kind = "frame", 
                attributes = list(names = "extra", class = "data.frame", 
                  row.names = 1:2), columns = list(extra = list(
                  kind = "integer", attributes = NULL, values = 3:4))))), 
        selected_route = list(namespace = "base", name = "cbind", 
            direct = TRUE), expected = structure(list("error", 
            NULL, NULL, "a", TRUE), names = c("status", NA, NA, 
        "callback_tag", "expected_direct")), after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = "k", 
                  row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
                  "stage8_base_dispatch_a", "data.frame"), stage8_base_mode = "error"), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)))), list(kind = "frame", attributes = list(
                names = "extra", class = "data.frame", row.names = 1:2), 
                columns = list(extra = list(kind = "integer", 
                  attributes = NULL, values = 3:4)))))))
