list(blocks = 11L, passed = 1518L, failed = 0L, errors = 0L, 
    warnings = 0L, skips = 0L)
