list(`update/events/public` = list(id = "update/events/public", 
    status = "return", conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:2, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
            stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(30, 
        40)))), events = c("events:1", "events:2"), before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("stage8_rows_selection", "data.frame"
        ), row.names = 1:2, stage8_mode = "events"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(30, 40)))))), after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, NA)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("stage8_rows_selection", 
            "data.frame"), row.names = 1:2, stage8_mode = "events"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = NULL, values = c(30, 40))))))), 
    `update/events/copied` = list(id = "update/events/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(30, 
            40)))), events = c("events:1", "events:2"), before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/transform/public` = list(id = "update/transform/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(130, 
            140)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/transform/copied` = list(id = "update/transform/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(130, 
            140)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/warning/public` = list(id = "update/warning/public", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(30, 40)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/warning/copied` = list(id = "update/warning/copied", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(30, 40)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/error/public` = list(id = "update/error/public", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `update/error/copied` = list(id = "update/error/copied", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/events/public` = list(id = "patch/events/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), events = c("events:1", "events:2"), before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/events/copied` = list(id = "patch/events/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), events = c("events:1", "events:2"), before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/transform/public` = list(id = "patch/transform/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/transform/copied` = list(id = "patch/transform/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/warning/public` = list(id = "patch/warning/public", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, NA)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/warning/copied` = list(id = "patch/warning/copied", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, NA)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/error/public` = list(id = "patch/error/public", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `patch/error/copied` = list(id = "patch/error/copied", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/events/public` = list(id = "upsert/events/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(30, 
            40)))), events = c("events:1", "events:2"), before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/events/copied` = list(id = "upsert/events/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(30, 
            40)))), events = c("events:1", "events:2"), before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/transform/public` = list(id = "upsert/transform/public", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(130, 
            140)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/transform/copied` = list(id = "upsert/transform/copied", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(130, 
            140)))), events = c("transform:1", "transform:2"), 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/warning/public` = list(id = "upsert/warning/public", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(30, 40)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/warning/copied` = list(id = "upsert/warning/copied", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(30, 40)))), events = c("warning:1", 
        "warning:2"), before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/error/public` = list(id = "upsert/error/public", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `upsert/error/copied` = list(id = "upsert/error/copied", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/events/public` = list(id = "delete/events/public", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "events:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/events/copied` = list(id = "delete/events/copied", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "events:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "events"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/transform/public` = list(id = "delete/transform/public", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "transform:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/transform/copied` = list(id = "delete/transform/copied", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "transform:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "transform"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/warning/public` = list(id = "delete/warning/public", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "warning:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/warning/copied` = list(id = "delete/warning/copied", 
        status = "return", conditions = list(list(classes = c("simpleWarning", 
        "warning", "condition"), message = "Stage8 bracket warning", 
            call = NULL, parent = NULL), list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), events = "warning:1", 
        before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "warning"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/error/public` = list(id = "delete/error/public", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))), 
    `delete/error/copied` = list(id = "delete/error/copied", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stage8 bracket sentinel", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, events = "error:1", before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = c("stage8_rows_selection", 
                "data.frame"), row.names = 1:2, stage8_mode = "error"), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40)))))), 
        after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("stage8_rows_selection", "data.frame"
            ), row.names = 1:2, stage8_mode = "error"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(30, 40))))))))
