test_that("B09 column modification preserves grouping metadata and regroup conditions", {
    canonical <- function(value) {
        if (is.null(value)) return(NULL)
        stopifnot(identical(value$kind, "frame"))
        attrs <- value$attributes
        keys <- names(attrs)
        if (is.null(keys) || anyNA(keys) || any(keys == "") || anyDuplicated(keys))
            stop("Invalid top-level attribute names in semantic record")
        # R treats attribute order as a set. Preserve every value and all
        # ordered columns/classes/groups; keep the raw recorded order intact.
        value$attributes <- attrs[sort(keys)]
        value
    }
    observed <- list()
    on.exit({
        directory <- get("out", .GlobalEnv)
        saveRDS(observed, file.path(directory, "grouped-columns.rds"))
        dput(observed, file.path(directory, "grouped-columns.R"))
    })
    store <- new.env(parent = environment(.s8_record))
    store$.s8_records <- new.env(parent = emptyenv()); store$.s8_records$values <- list()
    record <- .s8_record; environment(record) <- store
    for (shape in c("plain", "grouped", "rowwise"))
        for (case in c("value", "key", "delete_key", "wrong_size")) {
            pair <- list()
            for (route in c("public", "copied")) {
                x <- dibble(k = factor(c("a", "a", "b"), levels = c("a", "b", "c")),
                            value = c(10, 20, 30))
                attr(x, "label") <- "column modification source"
                if (shape == "grouped") x <- dplyr::group_by(x, k, .drop = FALSE)
                if (shape == "rowwise") x <- dplyr::rowwise(x, k)
                cols <- switch(case,
                    value = list(value = 7L), key = list(k = factor(c("b", "a", "a"),
                        levels = c("a", "b", "c"))), delete_key = list(k = NULL),
                    wrong_size = list(value = 1:2))
                before <- .s8b_snapshot(list(x, cols))
                events <- character()
                fn <- if (route == "public") dplyr::dplyr_col_modify else
                    .s8b_direct$dplyr_col_modify.dtatools_ref_data
                id <- paste(shape, case, route, sep = "/")
                result <- record(id, withCallingHandlers(fn(x, cols),
                    dplyr_regroup = function(cnd) events <<- c(events, class(cnd)[[1L]])))
                saved <- store$.s8_records$values[[id]]
                saved$events <- events
                saved$before <- before
                saved$after <- list(status = "pending")
                observed[[id]] <- saved
                saved$after <- .s8b_snapshot(list(x, cols))
                observed[[id]] <- saved
                pair[[route]] <- saved
                expect_identical(before$status, "complete", info = id)
                expect_identical(saved$snapshot_status,
                    if (saved$status == "return") "complete" else "not_applicable", info = id)
                expect_identical(saved$after$status, "complete", info = id)
                expect_identical(saved$after$value, before$value, info = id)
            }
            expect_identical(pair$copied$status, pair$public$status)
            expect_identical(pair$copied$snapshot_status, pair$public$snapshot_status)
            expect_identical(canonical(pair$copied$value), canonical(pair$public$value))
            expect_identical(pair$copied$error$classes, pair$public$error$classes)
            expect_identical(pair$copied$events, pair$public$events)
            expect_identical(lapply(pair$copied$conditions, function(x) x[c("classes", "message")]),
                             lapply(pair$public$conditions, function(x) x[c("classes", "message")]))
        }
})
