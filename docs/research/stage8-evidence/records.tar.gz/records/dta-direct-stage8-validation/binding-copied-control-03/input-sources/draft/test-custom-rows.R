test_that("B08 custom row selection preserves values and callback ordering", {
    method_name <- "[.stage8_rows_selection"
    if (exists(method_name, .GlobalEnv, inherits = FALSE)) stop("Diagnostic method name already exists")
    events <- new.env(parent = emptyenv())
    events$values <- character()
    assign(method_name, function(x, i, ..., drop = FALSE) {
        mode <- attr(x, "stage8_mode", exact = TRUE)
        events$values <- c(events$values, paste(mode, paste(i, collapse = ","), sep = ":"))
        if (mode == "error") stop("Stage8 bracket sentinel", call. = FALSE)
        if (mode == "warning") warning("Stage8 bracket warning", call. = FALSE)
        value <- NextMethod("[")
        if (mode == "transform" && "value" %in% names(value)) value$value <- value$value + 100
        value
    }, envir = .GlobalEnv)
    on.exit(rm(list = method_name, envir = .GlobalEnv), add = TRUE)
    observed <- list()
    on.exit({
        directory <- get("out", .GlobalEnv)
        saveRDS(observed, file.path(directory, "custom-rows.rds"))
        dput(observed, file.path(directory, "custom-rows.R"))
    }, add = TRUE)
    store <- new.env(parent = environment(.s8_record))
    store$.s8_records <- new.env(parent = emptyenv()); store$.s8_records$values <- list()
    record <- .s8_record; environment(record) <- store
    for (verb in c("update", "patch", "upsert", "delete"))
        for (mode in c("events", "transform", "warning", "error")) {
            pair <- list()
            for (route in c("public", "copied")) {
                x <- dibble(k = 1:2, value = c(10, NA_real_))
                y <- structure(data.frame(k = 1:2, value = c(30, 40)),
                    class = c("stage8_rows_selection", "data.frame"), stage8_mode = mode)
                before <- .s8b_snapshot(list(x, y))
                fn <- if (route == "public") getExportedValue("dplyr", paste0("rows_", verb)) else
                    get(paste0("rows_", verb, ".dtatools_ref_data"), envir = .s8b_direct)
                id <- paste(verb, mode, route, sep = "/")
                events$values <- character()
                result <- record(id, fn(x, y, by = "k"))
                saved <- store$.s8_records$values[[id]]
                saved$events <- events$values
                saved$before <- before
                saved$after <- list(status = "pending")
                observed[[id]] <- saved
                saved$after <- .s8b_snapshot(list(x, y))
                observed[[id]] <- saved
                pair[[route]] <- saved
                expect_identical(before$status, "complete", info = id)
                expect_identical(saved$snapshot_status,
                    if (saved$status == "return") "complete" else "not_applicable", info = id)
                expect_identical(saved$after$status, "complete", info = id)
                expect_identical(saved$after$value, before$value, info = id)
                expect_true(length(saved$events) > 0L, info = id)
                expect_identical(saved$status, if (mode == "error") "error" else "return", info = id)
            }
            expect_identical(pair$copied$events, pair$public$events)
            expect_identical(pair$copied$value, pair$public$value)
            expect_identical(pair$copied$error$classes, pair$public$error$classes)
            expect_identical(pair$copied$error$message, pair$public$error$message)
            expect_identical(lapply(pair$copied$conditions, function(x) x[c("classes", "message")]),
                             lapply(pair$public$conditions, function(x) x[c("classes", "message")]))
        }
})
