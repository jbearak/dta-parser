list(`B01/frame/dibble_first/base_rows` = list(id = "B01/frame/dibble_first/base_rows", 
    status = "return", conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_first/base_cols` = list(
    id = "B01/frame/dibble_first/base_cols", status = "error", 
    conditions = list(), error = list(classes = c("simpleError", 
    "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
        call = NULL, parent = NULL), snapshot_status = "not_applicable", 
    snapshot_conditions = list(), snapshot_error = NULL, value = NULL, 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_first/dplyr_rows` = list(
    id = "B01/frame/dibble_first/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_first/dplyr_cols` = list(
    id = "B01/frame/dibble_first/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k...1 = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value...2 = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_first/vctrs_rows` = list(
    id = "B01/frame/dibble_first/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3:4), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(12, 
                22)))))), selected_route = list(namespace = "vctrs", 
        name = "vec_rbind", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_first/vctrs_cols` = list(
    id = "B01/frame/dibble_first/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value...2 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)), k...3 = list(kind = "integer", 
            attributes = NULL, values = 3:4), value...4 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 3:4), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(12, 
                22)))))), selected_route = list(namespace = "vctrs", 
        name = "vec_cbind", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3:4), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/frame/dibble_second/base_rows` = list(
    id = "B01/frame/dibble_second/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = "data.frame"), columns = list(k = list(kind = "double", 
            attributes = NULL, values = c(1, 2, 3, 4)), value = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/frame/dibble_second/base_cols` = list(
    id = "B01/frame/dibble_second/base_cols", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value", "k", "value"
        ), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)), k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/frame/dibble_second/dplyr_rows` = list(
    id = "B01/frame/dibble_second/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = "data.frame"), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/frame/dibble_second/dplyr_cols` = list(
    id = "B01/frame/dibble_second/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = "data.frame"), 
        columns = list(k...1 = list(kind = "integer", attributes = NULL, 
            values = 1:2), value...2 = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/frame/dibble_second/vctrs_rows` = list(
    id = "B01/frame/dibble_second/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/frame/dibble_second/vctrs_cols` = list(
    id = "B01/frame/dibble_second/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = "data.frame", row.names = 1:2), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/tibble/dibble_first/base_rows` = list(
    id = "B01/tibble/dibble_first/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_first/base_cols` = list(
    id = "B01/tibble/dibble_first/base_cols", status = "error", 
    conditions = list(), error = list(classes = c("simpleError", 
    "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
        call = NULL, parent = NULL), snapshot_status = "not_applicable", 
    snapshot_conditions = list(), snapshot_error = NULL, value = NULL, 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_first/dplyr_rows` = list(
    id = "B01/tibble/dibble_first/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_first/dplyr_cols` = list(
    id = "B01/tibble/dibble_first/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k...1 = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value...2 = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_first/vctrs_rows` = list(
    id = "B01/tibble/dibble_first/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 3:4), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(12, 
            22)))))), selected_route = list(namespace = "vctrs", 
        name = "vec_rbind", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_first/vctrs_cols` = list(
    id = "B01/tibble/dibble_first/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value...2 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)), k...3 = list(kind = "integer", 
            attributes = NULL, values = 3:4), value...4 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 3:4), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(12, 
            22)))))), selected_route = list(namespace = "vctrs", 
        name = "vec_cbind", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/tibble/dibble_second/base_rows` = list(
    id = "B01/tibble/dibble_second/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("tbl_df", "tbl", "data.frame")), columns = list(
            k = list(kind = "double", attributes = NULL, values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
                label = "binding value"), values = c(10, 20, 
            12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
            "data.frame")), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/tibble/dibble_second/base_cols` = list(
    id = "B01/tibble/dibble_second/base_cols", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value", "k", "value"
        ), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)), k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/tibble/dibble_second/dplyr_rows` = list(
    id = "B01/tibble/dibble_second/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("tbl_df", "tbl", "data.frame")), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
            "data.frame")), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/tibble/dibble_second/dplyr_cols` = list(
    id = "B01/tibble/dibble_second/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/tibble/dibble_second/vctrs_rows` = list(
    id = "B01/tibble/dibble_second/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
            "data.frame")), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/tibble/dibble_second/vctrs_cols` = list(
    id = "B01/tibble/dibble_second/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/reference/dibble_first/base_rows` = list(
    id = "B01/reference/dibble_first/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "base", 
        name = "rbind", direct = TRUE), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/reference/dibble_first/base_cols` = list(
    id = "B01/reference/dibble_first/base_cols", status = "error", 
    conditions = list(), error = list(classes = c("simpleError", 
    "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
        call = NULL, parent = NULL), snapshot_status = "not_applicable", 
    snapshot_conditions = list(), snapshot_error = NULL, value = NULL, 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "base", 
        name = "cbind", direct = TRUE), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22))))))), `B01/reference/dibble_first/dplyr_rows` = list(
    id = "B01/reference/dibble_first/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "dplyr", 
        name = "bind_rows", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                ))))))), `B01/reference/dibble_first/dplyr_cols` = list(
    id = "B01/reference/dibble_first/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k...1 = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value...2 = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "dplyr", 
        name = "bind_cols", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                ))))))), `B01/reference/dibble_first/vctrs_rows` = list(
    id = "B01/reference/dibble_first/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                ))))))), `B01/reference/dibble_first/vctrs_cols` = list(
    id = "B01/reference/dibble_first/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value...2 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)), k...3 = list(kind = "integer", 
            attributes = NULL, values = 3:4), value...4 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                ))))))), `B01/reference/dibble_second/base_rows` = list(
    id = "B01/reference/dibble_second/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = "data.frame"), columns = list(k = list(kind = "double", 
            attributes = NULL, values = c(1, 2, 3, 4)), value = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("dtatools_ref_data", "data.frame"
        ), row.names = 1:2), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/reference/dibble_second/base_cols` = list(
    id = "B01/reference/dibble_second/base_cols", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value", "k", "value"
        ), class = "data.frame", row.names = 1:2), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)), k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("dtatools_ref_data", "data.frame"
        ), row.names = 1:2), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/reference/dibble_second/dplyr_rows` = list(
    id = "B01/reference/dibble_second/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = "data.frame", 
            row.names = 1:4), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("dtatools_ref_data", "data.frame"
        ), row.names = 1:2), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/reference/dibble_second/dplyr_cols` = list(
    id = "B01/reference/dibble_second/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = "data.frame", row.names = 1:2), 
        columns = list(k...1 = list(kind = "integer", attributes = NULL, 
            values = 1:2), value...2 = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("dtatools_ref_data", "data.frame"
        ), row.names = 1:2), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/reference/dibble_second/vctrs_rows` = list(
    id = "B01/reference/dibble_second/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), class = c("dtatools_ref_data", "data.frame"
            ), row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/reference/dibble_second/vctrs_cols` = list(
    id = "B01/reference/dibble_second/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("dtatools_ref_data", "data.frame"
        ), row.names = 1:2), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), class = c("dtatools_ref_data", 
            "data.frame"), row.names = 1:2), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/grouped/dibble_first/base_rows` = list(
    id = "B01/grouped/dibble_first/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_first/base_cols` = list(
    id = "B01/grouped/dibble_first/base_cols", status = "error", 
    conditions = list(), error = list(classes = c("simpleError", 
    "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
        call = NULL, parent = NULL), snapshot_status = "not_applicable", 
    snapshot_conditions = list(), snapshot_error = NULL, value = NULL, 
    inputs_before = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = TRUE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_first/dplyr_rows` = list(
    id = "B01/grouped/dibble_first/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_first/dplyr_cols` = list(
    id = "B01/grouped/dibble_first/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k...1 = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value...2 = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)), k...3 = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_first/vctrs_rows` = list(
    id = "B01/grouped/dibble_first/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            groups = structure(list(k = 3:4, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_first/vctrs_cols` = list(
    id = "B01/grouped/dibble_first/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value...2 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)), k...3 = list(kind = "integer", 
            attributes = NULL, values = 3:4), value...4 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            groups = structure(list(k = 3:4, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 3:4), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
        2)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/grouped/dibble_second/base_rows` = list(
    id = "B01/grouped/dibble_second/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(groups = structure(list(k = structure(c(1, 
        2, 3, 4), stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), .rows = structure(list(
            1L, 2L, 3L, 4L), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -4L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:4, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "rbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            groups = structure(list(k = 1:2, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/grouped/dibble_second/base_cols` = list(
    id = "B01/grouped/dibble_second/base_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "base", name = "cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            groups = structure(list(k = 1:2, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/grouped/dibble_second/dplyr_rows` = list(
    id = "B01/grouped/dibble_second/dplyr_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(groups = structure(list(k = structure(c(1, 
        2, 3, 4), stata.storage = "long", class = c("dta_numeric", 
        "dta_long", "vctrs_vctr", "double")), .rows = structure(list(
            1L, 2L, 3L, 4L), ptype = integer(0), class = c("vctrs_list_of", 
        "vctrs_vctr", "list"))), row.names = c(NA, -4L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:4, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_rows", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            groups = structure(list(k = 1:2, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/grouped/dibble_second/dplyr_cols` = list(
    id = "B01/grouped/dibble_second/dplyr_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "dplyr", name = "bind_cols", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            groups = structure(list(k = 1:2, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/grouped/dibble_second/vctrs_rows` = list(
    id = "B01/grouped/dibble_second/vctrs_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), class = c("tbl_df", 
        "tbl", "data.frame"), row.names = 1:4), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(groups = structure(list(
                k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame"), .drop = FALSE), 
                names = c("k", "value"), row.names = 1:2, class = c("grouped_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(12, 
                22)))))), selected_route = list(namespace = "vctrs", 
        name = "vec_rbind", direct = FALSE), inputs_after = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22))))))), `B01/grouped/dibble_second/vctrs_cols` = list(
    id = "B01/grouped/dibble_second/vctrs_cols", status = "return", 
    conditions = list(list(classes = c("rlib_message_name_repair", 
    "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
        call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k...1", "value...2", "k...3", 
        "value...4"), class = c("tbl_df", "tbl", "data.frame"
        ), row.names = 1:2), columns = list(k...1 = list(kind = "integer", 
            attributes = NULL, values = 1:2), value...2 = list(
            kind = "double", attributes = list(label = "binding value"), 
            values = c(10, 20)), k...3 = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
            4)), value...4 = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(groups = structure(list(
            k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
        "tbl", "data.frame"), .drop = FALSE), names = c("k", 
        "value"), row.names = 1:2, class = c("grouped_df", "tbl_df", 
        "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = list(label = "binding value"), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))))), selected_route = list(
        namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
    inputs_after = list(status = "complete", conditions = list(), 
        error = NULL, value = list(list(kind = "frame", attributes = list(
            groups = structure(list(k = 1:2, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame"), .drop = FALSE), names = c("k", 
            "value"), row.names = 1:2, class = c("grouped_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
            names = c("k", "value"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
            stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(3, 
        4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(12, 22))))))), `B01/rowwise/dibble_first/base_rows` = list(
    id = "B01/rowwise/dibble_first/base_rows", status = "return", 
    conditions = list(), error = NULL, snapshot_status = "complete", 
    snapshot_conditions = list(), value = list(kind = "frame", 
        attributes = list(names = c("k", "value"), row.names = 1:4, 
            class = c("dibble", "dtatools_ref_data", "tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "double", 
            attributes = list(stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3, 4)), value = list(kind = "double", attributes = list(
            label = "binding value", stata.storage = "double", 
            class = c("dta_numeric", "dta_double", "vctrs_vctr", 
            "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
        status = "complete", conditions = list(), error = NULL, 
        value = list(list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
            attributes = list(groups = structure(list(k = 3:4, 
                .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
            ), class = c("tbl_df", "tbl", "data.frame")), names = c("k", 
            "value"), row.names = 1:2, class = c("rowwise_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "base", 
        name = "rbind", direct = TRUE), inputs_after = list(status = "complete", 
        conditions = list(), error = NULL, value = list(list(
            kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
            groups = structure(list(k = 3:4, .rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame")), names = c("k", "value"), row.names = 1:2, 
            class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "integer", attributes = NULL, 
            values = 3:4), value = list(kind = "double", attributes = list(
            label = "binding value"), values = c(12, 22))))))), 
    `B01/rowwise/dibble_first/base_cols` = list(id = "B01/rowwise/dibble_first/base_cols", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "base", name = "cbind", direct = TRUE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/rowwise/dibble_first/dplyr_rows` = list(
        id = "B01/rowwise/dibble_first/dplyr_rows", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:4, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20, 12, 22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "dplyr", name = "bind_rows", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/rowwise/dibble_first/dplyr_cols` = list(
        id = "B01/rowwise/dibble_first/dplyr_cols", status = "return", 
        conditions = list(list(classes = c("rlib_message_name_repair", 
        "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k...1", "value...2", 
            "k...3", "value...4"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k...1 = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value...2 = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)), k...3 = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)), value...4 = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(12, 
                22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "dplyr", name = "bind_cols", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/rowwise/dibble_first/vctrs_rows` = list(
        id = "B01/rowwise/dibble_first/vctrs_rows", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("tbl_df", 
            "tbl", "data.frame"), row.names = 1:4), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(10, 
                  20, 12, 22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/rowwise/dibble_first/vctrs_cols` = list(
        id = "B01/rowwise/dibble_first/vctrs_cols", status = "return", 
        conditions = list(list(classes = c("rlib_message_name_repair", 
        "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k...1", "value...2", 
            "k...3", "value...4"), class = c("tbl_df", "tbl", 
            "data.frame"), row.names = 1:2), columns = list(k...1 = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value...2 = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)), k...3 = list(kind = "integer", attributes = NULL, 
                values = 3:4), value...4 = list(kind = "double", 
                attributes = list(label = "binding value"), values = c(12, 
                22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(groups = structure(list(k = 3:4, 
                  .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 3:4), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B01/rowwise/dibble_second/base_rows` = list(
        id = "B01/rowwise/dibble_second/base_rows", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(groups = structure(list(k = structure(c(1, 
            2, 3, 4), stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), .rows = structure(list(
                1L, 2L, 3L, 4L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -4L), class = c("tbl_df", 
            "tbl", "data.frame")), names = c("k", "value"), row.names = 1:4, 
                class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3, 4)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "base", 
            name = "rbind", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B01/rowwise/dibble_second/base_cols` = list(
        id = "B01/rowwise/dibble_second/base_cols", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "k", "value"
            ), class = "data.frame", row.names = 1:2), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)), k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                  4)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "base", 
            name = "cbind", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B01/rowwise/dibble_second/dplyr_rows` = list(
        id = "B01/rowwise/dibble_second/dplyr_rows", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(groups = structure(list(k = structure(c(1, 
            2, 3, 4), stata.storage = "long", class = c("dta_numeric", 
            "dta_long", "vctrs_vctr", "double")), .rows = structure(list(
                1L, 2L, 3L, 4L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -4L), class = c("tbl_df", 
            "tbl", "data.frame")), names = c("k", "value"), row.names = 1:4, 
                class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2, 3, 4)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20, 12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "dplyr", 
            name = "bind_rows", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B01/rowwise/dibble_second/dplyr_cols` = list(
        id = "B01/rowwise/dibble_second/dplyr_cols", status = "return", 
        conditions = list(list(classes = c("rlib_message_name_repair", 
        "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(groups = structure(list(.rows = structure(list(
                1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
            "vctrs_vctr", "list"))), row.names = c(NA, -2L), class = c("tbl_df", 
            "tbl", "data.frame")), names = c("k...1", "value...2", 
            "k...3", "value...4"), row.names = 1:2, class = c("rowwise_df", 
            "tbl_df", "tbl", "data.frame")), columns = list(k...1 = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value...2 = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(10, 20
                )), k...3 = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value...4 = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "dplyr", 
            name = "bind_cols", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B01/rowwise/dibble_second/vctrs_rows` = list(
        id = "B01/rowwise/dibble_second/vctrs_rows", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), class = c("tbl_df", 
            "tbl", "data.frame"), row.names = 1:4), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(10, 
                  20, 12, 22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(groups = structure(list(
                  k = 1:2, .rows = structure(list(1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                  "vctrs_vctr", "list"))), row.names = c(NA, 
                -2L), class = c("tbl_df", "tbl", "data.frame"
                )), names = c("k", "value"), row.names = 1:2, 
                  class = c("rowwise_df", "tbl_df", "tbl", "data.frame"
                  )), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 1:2), value = list(
                  kind = "double", attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "vctrs", 
            name = "vec_rbind", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B01/rowwise/dibble_second/vctrs_cols` = list(
        id = "B01/rowwise/dibble_second/vctrs_cols", status = "return", 
        conditions = list(list(classes = c("rlib_message_name_repair", 
        "rlang_message", "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
            call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k...1", "value...2", 
            "k...3", "value...4"), class = c("tbl_df", "tbl", 
            "data.frame"), row.names = 1:2), columns = list(k...1 = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value...2 = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(10, 20
                )), k...3 = list(kind = "double", attributes = list(
                  stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(3, 
                4)), value...4 = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22)))))), selected_route = list(namespace = "vctrs", 
            name = "vec_cbind", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                groups = structure(list(k = 1:2, .rows = structure(list(
                  1L, 2L), ptype = integer(0), class = c("vctrs_list_of", 
                "vctrs_vctr", "list"))), row.names = c(NA, -2L
                ), class = c("tbl_df", "tbl", "data.frame")), 
                names = c("k", "value"), row.names = 1:2, class = c("rowwise_df", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(3, 4)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(12, 
                  22))))))), `B02/leading_NULL_rows` = list(id = "B02/leading_NULL_rows", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 12, 22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "NULL", attributes = NULL, values = NULL), 
                list(kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                  attributes = list(names = c("k", "value"), 
                    row.names = 1:2, class = c("tbl_df", "tbl", 
                    "data.frame")), columns = list(k = list(kind = "integer", 
                    attributes = NULL, values = 3:4), value = list(
                    kind = "double", attributes = list(label = "binding value"), 
                    values = c(12, 22)))))), selected_route = list(
            namespace = "dplyr", name = "bind_rows", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "NULL", attributes = NULL, 
                values = NULL), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B02/leading_NULL_cols` = list(
        id = "B02/leading_NULL_cols", status = "return", conditions = list(
            list(classes = c("rlib_message_name_repair", "rlang_message", 
            "message", "condition"), message = "New names:\n* `k` -> `k...1`\n* `value` -> `value...2`\n* `k` -> `k...3`\n* `value` -> `value...4`", 
                call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k...1", "value...2", 
            "k...3", "value...4"), row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k...1 = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value...2 = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)), k...3 = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(3, 4)), value...4 = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(12, 
                22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "NULL", attributes = NULL, values = NULL), 
                list(kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                  attributes = list(names = c("k", "value"), 
                    row.names = 1:2, class = c("tbl_df", "tbl", 
                    "data.frame")), columns = list(k = list(kind = "integer", 
                    attributes = NULL, values = 3:4), value = list(
                    kind = "double", attributes = list(label = "binding value"), 
                    values = c(12, 22)))))), selected_route = list(
            namespace = "dplyr", name = "bind_cols", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "NULL", attributes = NULL, 
                values = NULL), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B02/named_id` = list(
        id = "B02/named_id", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("origin", 
        "k", "value"), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(origin = list(
            kind = "character", attributes = list(stata.string.storage = "str5"), 
            values = c("left", "left", "right", "right")), k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
            kind = "double", attributes = list(label = "binding value", 
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20, 12, 22)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22)))))), selected_route = list(namespace = "dplyr", 
            name = "bind_rows", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(left = list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22))))))), `B02/id_collision` = list(id = "B02/id_collision", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:4, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3, 4)), value = list(
            kind = "character", attributes = list(stata.string.storage = "str5"), 
            values = c("left", "left", "right", "right")))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(left = list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("dibble", "dtatools_ref_data", "tbl_df", 
                  "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "long", 
                    class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                    "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(label = "binding value", 
                    stata.storage = "double", class = c("dta_numeric", 
                    "dta_double", "vctrs_vctr", "double")), values = c(10, 
                  20)))), right = list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 3:4), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(12, 22
                )))))), selected_route = list(namespace = "dplyr", 
            name = "bind_rows", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(left = list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22))))))), `B02/column_union` = list(id = "B02/column_union", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value", "extra"), row.names = 1:3, class = c("dibble", 
        "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2, 3)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20, NA)), extra = list(
                kind = "character", attributes = list(stata.string.storage = "str1"), 
                values = c("", "", "z")))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "extra"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), extra = list(kind = "character", 
                  attributes = NULL, values = "z"))))), selected_route = list(
            namespace = "dplyr", name = "bind_rows", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "extra"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), extra = list(kind = "character", 
                  attributes = NULL, values = "z")))))), `B02/factor_union` = list(
        id = "B02/factor_union", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "f"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), f = list(kind = "integer", 
            attributes = list(levels = c("a", "b"), class = "factor"), 
            values = 1:2))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "f"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                  k = list(kind = "double", attributes = list(
                    stata.storage = "long", class = c("dta_numeric", 
                    "dta_long", "vctrs_vctr", "double")), values = 1), 
                  f = list(kind = "integer", attributes = list(
                    levels = "a", class = "factor"), values = 1L))), 
                list(kind = "frame", attributes = list(names = c("k", 
                "f"), row.names = 1L, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 2L), f = list(kind = "integer", 
                  attributes = list(levels = "b", class = "factor"), 
                  values = 1L))))), selected_route = list(namespace = "dplyr", 
            name = "bind_rows", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "f"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                f = list(kind = "integer", attributes = list(
                  levels = "a", class = "factor"), values = 1L))), 
                list(kind = "frame", attributes = list(names = c("k", 
                "f"), row.names = 1L, class = c("tbl_df", "tbl", 
                "data.frame")), columns = list(k = list(kind = "integer", 
                  attributes = NULL, values = 2L), f = list(kind = "integer", 
                  attributes = list(levels = "b", class = "factor"), 
                  values = 1L)))))), `B02/zero_rows_base` = list(
        id = "B02/zero_rows_base", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(3, 4)), value = list(kind = "double", 
            attributes = list(label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(12, 22)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "base", name = "rbind", direct = TRUE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = integer(0), 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = numeric(0)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = numeric(0)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B02/zero_columns_vctrs` = list(
        id = "B02/zero_columns_vctrs", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("tbl_df", "tbl", "data.frame"), row.names = 1:2), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))))), selected_route = list(
            namespace = "vctrs", name = "vec_cbind", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = character(0), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = structure(list(), names = character(0))), 
                list(kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20))))))), `B02/explicit_ptype` = list(
        id = "B02/explicit_ptype", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), class = c("tbl_df", "tbl", "data.frame"), row.names = 1:4), 
            columns = list(k = list(kind = "double", attributes = NULL, 
                values = c(1, 2, 3, 4)), value = list(kind = "double", 
                attributes = NULL, values = c(10, 20, 12, 22)))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "vctrs", name = "vec_rbind", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B02/minimal_names` = list(
        id = "B02/minimal_names", status = "error", conditions = list(), 
        error = list(classes = c("simpleError", "error", "condition"
        ), message = "a dibble needs unique, non-missing column names; repair them first or request `output = \"tibble\"`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22)))))), selected_route = list(
            namespace = "dplyr", name = "bind_cols", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3:4), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(12, 22))))))), `B02/scalar_recycling` = list(
        id = "B02/scalar_recycling", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value", "extra"), row.names = 1:2, class = c("dibble", 
        "dtatools_ref_data", "tbl_df", "tbl", "data.frame")), 
            columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)), extra = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(7, 7)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), extra = list(
                kind = "integer", attributes = NULL, values = 7L))), 
        selected_route = list(namespace = "dplyr", name = "bind_cols", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), extra = list(
                kind = "integer", attributes = NULL, values = 7L)))), 
    `B02/named_frame_packing` = list(id = "B02/named_frame_packing", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("left", 
        "right"), class = c("tbl_df", "tbl", "data.frame"), row.names = 1:2), 
            columns = list(left = list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22)))))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(left = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22)))))), selected_route = list(namespace = "vctrs", 
            name = "vec_cbind", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(left = list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), right = list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 3:4), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(12, 
                  22))))))), `B03/frame/insert` = list(id = "B03/frame/insert", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:3), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 30))))), 
        expectation = list(source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_insert", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30)))))), `B03/frame/append` = list(
        id = "B03/frame/append", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:3), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 30))))), 
        expectation = list(source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30)))))), `B03/frame/update` = list(
        id = "B03/frame/update", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), expectation = list(
            source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B03/frame/patch` = list(
        id = "B03/frame/patch", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, NA)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), expectation = list(
            source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_patch", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, NA)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B03/frame/upsert` = list(
        id = "B03/frame/upsert", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:3), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 99, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 2:3), value = list(
                kind = "double", attributes = NULL, values = c(99, 
                30)))))), expectation = list(source_policy_keys = 1:3, 
            scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_upsert", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2:3), value = list(kind = "double", 
                  attributes = NULL, values = c(99, 30))))))), 
    `B03/frame/delete` = list(id = "B03/frame/delete", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1L, 
                class = "data.frame"), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1L), 
                value = list(kind = "double", attributes = NULL, 
                  values = 10))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = "k", 
                  class = "data.frame", row.names = 1L), columns = list(
                  k = list(kind = "integer", attributes = NULL, 
                    values = 2L))))), expectation = list(source_policy_keys = 1L, 
            scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_delete", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = "k", 
                  class = "data.frame", row.names = 1L), columns = list(
                  k = list(kind = "integer", attributes = NULL, 
                    values = 2L)))))), `B03/tibble/insert` = list(
        id = "B03/tibble/insert", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:3), value = list(kind = "double", 
            attributes = NULL, values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30))))), expectation = list(
            source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_insert", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30)))))), `B03/tibble/append` = list(
        id = "B03/tibble/append", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:3), value = list(kind = "double", 
            attributes = NULL, values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30))))), expectation = list(
            source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 30)))))), `B03/tibble/update` = list(
        id = "B03/tibble/update", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = NULL, values = c(10, 99)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), expectation = list(
            source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B03/tibble/patch` = list(
        id = "B03/tibble/patch", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:2), value = list(kind = "double", 
            attributes = NULL, values = c(10, 99)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, NA)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), expectation = list(
            source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_patch", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, NA)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B03/tibble/upsert` = list(
        id = "B03/tibble/upsert", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = 1:3), value = list(kind = "double", 
            attributes = NULL, values = c(10, 99, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2:3), value = list(kind = "double", 
                  attributes = NULL, values = c(99, 30)))))), 
        expectation = list(source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_upsert", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2:3), value = list(kind = "double", 
                  attributes = NULL, values = c(99, 30))))))), 
    `B03/tibble/delete` = list(id = "B03/tibble/delete", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1L, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 10))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = "k", row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L))))), expectation = list(source_policy_keys = 1L, 
            scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_delete", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = "k", row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L)))))), `B03/dibble/insert` = list(
        id = "B03/dibble/insert", status = "return", conditions = list(), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:3, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2, 3)), value = list(
            kind = "double", attributes = list(stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 3), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 30))))), 
        expectation = list(source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_insert", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 30)))))), 
    `B03/dibble/append` = list(id = "B03/dibble/append", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 3), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 30))))), 
        expectation = list(source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 30)))))), 
    `B03/dibble/update` = list(id = "B03/dibble/update", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 99)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 2), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        expectation = list(source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B03/dibble/patch` = list(id = "B03/dibble/patch", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, NA)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            NA)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 2), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        expectation = list(source_policy_keys = 1:2, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_patch", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                NA)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B03/dibble/upsert` = list(id = "B03/dibble/upsert", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:3, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 3)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 99, 30)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(2, 3)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(99, 30)))))), expectation = list(
            source_policy_keys = 1:3, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_upsert", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(2, 
                3)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(99, 
            30))))))), `B03/dibble/delete` = list(id = "B03/dibble/delete", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = 1), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = 10))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = "k", 
                row.names = 1L, class = c("dibble", "dtatools_ref_data", 
                "tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 2))))), expectation = list(
            source_policy_keys = 1L, scope = "Comparison aid only; not asserted as a green observation"), 
        selected_route = list(namespace = "dplyr", name = "rows_delete", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = "k", row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 2)))))), 
    `B04/frame/append_wide` = list(id = "B04/frame/append_wide", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 200))))), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 200)))))), 
    `B04/frame/update_wide` = list(id = "B04/frame/update_wide", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 2L), value = list(
                kind = "double", attributes = NULL, values = 200))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 2L), value = list(
                kind = "double", attributes = NULL, values = 200)))))), 
    `B04/frame/common_key_match` = list(id = "B04/frame/common_key_match", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "byte", 
                class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
                attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 2), value = list(
                kind = "double", attributes = NULL, values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 2), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B04/frame/fractional_key_ignore` = list(id = "B04/frame/fractional_key_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "double", attributes = list(stata.storage = "byte", 
                class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
                attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 1.5), value = list(
                kind = "double", attributes = NULL, values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 1.5), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B04/frame/upsert_wide_key` = list(id = "B04/frame/upsert_wide_key", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 300), value = list(
                kind = "double", attributes = NULL, values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_upsert", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "double", 
                attributes = NULL, values = 300), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B04/frame/append_wide_string` = list(id = "B04/frame/append_wide_string", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata str1 storage cannot represent `x`; use `dta_string(x, storage = \"str5\")`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "character", attributes = list(
                  stata.string.storage = "str1", class = c("dta_string", 
                  "vctrs_vctr", "character")), values = c("a", 
                "b")))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "character", attributes = NULL, values = "wider"))))), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "character", attributes = list(
                  stata.string.storage = "str1", class = c("dta_string", 
                  "vctrs_vctr", "character")), values = c("a", 
                "b")))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "character", attributes = NULL, values = "wider")))))), 
    `B04/tibble/append_wide` = list(id = "B04/tibble/append_wide", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 200))))), selected_route = list(
            namespace = "dplyr", name = "rows_append", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 200)))))), `B04/tibble/update_wide` = list(
        id = "B04/tibble/update_wide", status = "error", conditions = list(), 
        error = list(classes = c("simpleError", "error", "condition"
        ), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 200))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 200)))))), `B04/tibble/common_key_match` = list(
        id = "B04/tibble/common_key_match", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(10, 99)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 2), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 2), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B04/tibble/fractional_key_ignore` = list(
        id = "B04/tibble/fractional_key_ignore", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 1.5), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 1.5), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B04/tibble/upsert_wide_key` = list(
        id = "B04/tibble/upsert_wide_key", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(1, 2)), value = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 300), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_upsert", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "double", attributes = NULL, 
                  values = 300), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B04/tibble/append_wide_string` = list(
        id = "B04/tibble/append_wide_string", status = "error", 
        conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata str1 storage cannot represent `x`; use `dta_string(x, storage = \"str5\")`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "double", attributes = list(stata.storage = "byte", 
                    class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                    "double")), values = c(1, 2)), value = list(
                  kind = "character", attributes = list(stata.string.storage = "str1", 
                    class = c("dta_string", "vctrs_vctr", "character"
                    )), values = c("a", "b")))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "character", 
                  attributes = NULL, values = "wider"))))), selected_route = list(
            namespace = "dplyr", name = "rows_append", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "byte", 
                  class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "character", attributes = list(stata.string.storage = "str1", 
                  class = c("dta_string", "vctrs_vctr", "character"
                  )), values = c("a", "b")))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "character", 
                  attributes = NULL, values = "wider")))))), 
    `B04/dibble/append_wide` = list(id = "B04/dibble/append_wide", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 200))))), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 200)))))), 
    `B04/dibble/update_wide` = list(id = "B04/dibble/update_wide", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 200))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 200)))))), 
    `B04/dibble/common_key_match` = list(id = "B04/dibble/common_key_match", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "byte", 
                class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "byte", class = c("dta_numeric", 
            "dta_byte", "vctrs_vctr", "double")), values = c(10, 
            99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 2), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B04/dibble/fractional_key_ignore` = list(id = "B04/dibble/fractional_key_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "byte", 
                class = c("dta_numeric", "dta_byte", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "byte", class = c("dta_numeric", 
            "dta_byte", "vctrs_vctr", "double")), values = c(10, 
            20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 1.5), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 1.5), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B04/dibble/upsert_wide_key` = list(id = "B04/dibble/upsert_wide_key", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata byte storage cannot represent `x`; use `dta_int(x)`", 
            call = ".construct_dta_numeric(x, NULL, storage)", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 300), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_upsert", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 300), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B04/dibble/append_wide_string` = list(id = "B04/dibble/append_wide_string", 
        status = "error", conditions = list(), error = list(classes = c("simpleError", 
        "error", "condition"), message = "Stata str1 storage cannot represent `x`; use `dta_string(x, storage = \"str5\")`", 
            call = NULL, parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "character", attributes = list(
                  stata.string.storage = "str1", class = c("dta_string", 
                  "vctrs_vctr", "character")), values = c("a", 
                "b")))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "character", attributes = list(
                  stata.string.storage = "str5"), values = "wider"))))), 
        selected_route = list(namespace = "dplyr", name = "rows_append", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "byte", class = c("dta_numeric", 
                  "dta_byte", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "character", attributes = list(
                  stata.string.storage = "str1", class = c("dta_string", 
                  "vctrs_vctr", "character")), values = c("a", 
                "b")))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "character", attributes = list(
                  stata.string.storage = "str5"), values = "wider")))))), 
    `B05/frame/insert_conflict_error` = list(id = "B05/frame/insert_conflict_error", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` can't contain keys that already exist in `x`.\ni The following rows in `y` have keys that already exist in `x`: `c(1)`.\ni Use `conflict = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., conflict = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_insert\")\n})(structure(list(k = 1:2, value = c(10, 20)), class = \"data.frame\", row.names = c(NA, \n-2L)), structure(list(k = 1L, value = 99), class = \"data.frame\", row.names = c(NA, \n-1L)), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_insert", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/insert_conflict_ignore` = list(id = "B05/frame/insert_conflict_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_insert", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/update_duplicate_y` = list(id = "B05/frame/update_duplicate_y", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` key values must be unique.\ni The following rows contain duplicate key values: `c(1, 2)`.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_update\", x)\n})(structure(list(k = 1:2, value = c(10, 20)), class = \"data.frame\", row.names = c(NA, \n-2L)), structure(list(k = c(1L, 1L), value = c(40, 50)), class = \"data.frame\", row.names = c(NA, \n-2L)), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = c(1L, 1L)), value = list(kind = "double", 
                  attributes = NULL, values = c(40, 50)))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = c(1L, 1L)), value = list(kind = "double", 
                  attributes = NULL, values = c(40, 50))))))), 
    `B05/frame/update_duplicate_x` = list(id = "B05/frame/update_duplicate_x", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = c(1L, 
            1L)), value = list(kind = "double", attributes = NULL, 
                values = c(99, 99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = c(1L, 1L)), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = c(1L, 1L)), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/update_unmatched_error` = list(id = "B05/frame/update_unmatched_error", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` must contain keys that already exist in `x`.\ni The following rows in `y` have keys that don't exist in `x`: `c(1)`.\ni Use `unmatched = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_update\", x)\n})(structure(list(k = 1:2, value = c(10, 20)), class = \"data.frame\", row.names = c(NA, \n-2L)), structure(list(k = 3L, value = 99), class = \"data.frame\", row.names = c(NA, \n-1L)), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/update_unmatched_ignore` = list(id = "B05/frame/update_unmatched_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(10, 20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 3L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/delete_extra_column` = list(id = "B05/frame/delete_extra_column", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1L, 
                class = "data.frame"), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 2L), 
                value = list(kind = "double", attributes = NULL, 
                  values = 20))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_delete", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/frame/default_by` = list(id = "B05/frame/default_by", 
        status = "return", conditions = list(list(classes = c("dplyr_message_matching_by", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Matching, by = \"k\"", call = NULL, parent = NULL)), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = "data.frame"), columns = list(
            k = list(kind = "integer", attributes = NULL, values = 1:2), 
            value = list(kind = "double", attributes = NULL, 
                values = c(99, 20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1L), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = NULL, values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1L), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1L), value = list(
                kind = "double", attributes = NULL, values = 99)))))), 
    `B05/tibble/insert_conflict_error` = list(id = "B05/tibble/insert_conflict_error", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` can't contain keys that already exist in `x`.\ni The following rows in `y` have keys that already exist in `x`: `c(1)`.\ni Use `conflict = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., conflict = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_insert\")\n})(structure(list(k = 1:2, value = c(10, 20)), row.names = c(NA, \n-2L), class = c(\"tbl_df\", \"tbl\", \"data.frame\")), structure(list(\n    k = 1L, value = 99), row.names = c(NA, -1L), class = c(\"tbl_df\", \n\"tbl\", \"data.frame\")), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_insert", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/tibble/insert_conflict_ignore` = list(
        id = "B05/tibble/insert_conflict_ignore", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_insert", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/tibble/update_duplicate_y` = list(
        id = "B05/tibble/update_duplicate_y", status = "error", 
        conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` key values must be unique.\ni The following rows contain duplicate key values: `c(1, 2)`.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_update\", x)\n})(structure(list(k = 1:2, value = c(10, 20)), row.names = c(NA, \n-2L), class = c(\"tbl_df\", \"tbl\", \"data.frame\")), structure(list(\n    k = c(1L, 1L), value = c(40, 50)), row.names = c(NA, -2L), class = c(\"tbl_df\", \n\"tbl\", \"data.frame\")), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = c(1L, 1L)), value = list(kind = "double", 
                  attributes = NULL, values = c(40, 50)))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1:2, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = c(1L, 1L)), value = list(kind = "double", 
                  attributes = NULL, values = c(40, 50))))))), 
    `B05/tibble/update_duplicate_x` = list(id = "B05/tibble/update_duplicate_x", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("tbl_df", "tbl", 
        "data.frame")), columns = list(k = list(kind = "integer", 
            attributes = NULL, values = c(1L, 1L)), value = list(
            kind = "double", attributes = NULL, values = c(99, 
            99)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = c(1L, 
                  1L)), value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = c(1L, 
                1L)), value = list(kind = "double", attributes = NULL, 
                values = c(10, 20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1L), 
                value = list(kind = "double", attributes = NULL, 
                  values = 99)))))), `B05/tibble/update_unmatched_error` = list(
        id = "B05/tibble/update_unmatched_error", status = "error", 
        conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` must contain keys that already exist in `x`.\ni The following rows in `y` have keys that don't exist in `x`: `c(1)`.\ni Use `unmatched = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    UseMethod(\"rows_update\", x)\n})(structure(list(k = 1:2, value = c(10, 20)), row.names = c(NA, \n-2L), class = c(\"tbl_df\", \"tbl\", \"data.frame\")), structure(list(\n    k = 3L, value = 99), row.names = c(NA, -1L), class = c(\"tbl_df\", \n\"tbl\", \"data.frame\")), by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = NULL, 
                    values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/tibble/update_unmatched_ignore` = list(
        id = "B05/tibble/update_unmatched_ignore", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(10, 20)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 3L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/tibble/delete_extra_column` = list(
        id = "B05/tibble/delete_extra_column", status = "return", 
        conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1L, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 2L), value = list(kind = "double", 
                  attributes = NULL, values = 20))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_delete", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/tibble/default_by` = list(
        id = "B05/tibble/default_by", status = "return", conditions = list(
            list(classes = c("dplyr_message_matching_by", "dplyr_message", 
            "rlang_message", "message", "condition"), message = "Matching, by = \"k\"", 
                call = NULL, parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("tbl_df", "tbl", "data.frame")), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = NULL, values = c(99, 20)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99))))), selected_route = list(
            namespace = "dplyr", name = "rows_update", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = NULL, 
                  values = c(10, 20)))), list(kind = "frame", 
                attributes = list(names = c("k", "value"), row.names = 1L, 
                  class = c("tbl_df", "tbl", "data.frame")), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1L), value = list(kind = "double", 
                  attributes = NULL, values = 99)))))), `B05/dibble/insert_conflict_error` = list(
        id = "B05/dibble/insert_conflict_error", status = "error", 
        conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` can't contain keys that already exist in `x`.\ni The following rows in `y` have keys that already exist in `x`: 1.\ni Use `conflict = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., conflict = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    if (!is_dibble(x)) \n        return(NextMethod())\n    rlang::check_dots_empty()\n    call <- rlang::current_env()\n    .dibble_rows_in_place(in_place, call)\n    y <- dplyr::auto_copy(x, y, copy = copy)\n    by <- .dibble_rows_by(by, y, call)\n    .dibble_rows_columns(x, y, by, call)\n    y <- .dibble_rows_cast(y, x, call)\n    keep <- .dibble_rows_keep(.dibble_rows_select(x, by, call), \n        .dibble_rows_select(y, by, call), conflict, TRUE, call)\n    if (!is.null(keep)) \n        y <- dplyr::dplyr_row_slice(y, keep)\n    .dibble_rows_append(x, y, \"rows_insert()\")\n})(structure(list(k = structure(c(1, 2), stata.storage = \"long\", class = c(\"dta_numeric\", \n\"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(10, \n20), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    structure(list(k = structure(1, stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(99, stata.storage = \"double\", class = c(\"dta_numeric\", \n    \"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, \n    -1L), class = c(\"dibble\", \"dtatools_ref_data\", \"tbl_df\", \n    \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_insert", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/insert_conflict_ignore` = list(id = "B05/dibble/insert_conflict_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_insert", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/update_duplicate_y` = list(id = "B05/dibble/update_duplicate_y", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` key values must be unique.\ni The following rows contain duplicate key values: 1 and 2.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    if (!is_dibble(x)) \n        return(NextMethod())\n    rlang::check_dots_empty()\n    call <- rlang::current_env()\n    .dibble_rows_in_place(in_place, call)\n    y <- dplyr::auto_copy(x, y, copy = copy)\n    .dibble_rows_change(x, y, by, \"update\", unmatched, call)\n})(structure(list(k = structure(c(1, 2), stata.storage = \"long\", class = c(\"dta_numeric\", \n\"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(10, \n20), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    structure(list(k = structure(c(1, 1), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(40, \n    50), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n    \"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n    \"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                1)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(40, 
            50)))))), selected_route = list(namespace = "dplyr", 
            name = "rows_update", direct = TRUE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(40, 50))))))), `B05/dibble/update_duplicate_x` = list(
        id = "B05/dibble/update_duplicate_x", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1:2, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1)), value = list(
                kind = "double", attributes = list(stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(99, 99)))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                1)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 1), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  1)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/update_unmatched_error` = list(id = "B05/dibble/update_unmatched_error", 
        status = "error", conditions = list(), error = list(classes = c("rlang_error", 
        "error", "condition"), message = "`y` must contain keys that already exist in `x`.\ni The following rows in `y` have keys that don't exist in `x`: 1.\ni Use `unmatched = \"ignore\"` if you want to ignore these `y` rows.", 
            call = "(function (x, y, by = NULL, ..., unmatched = c(\"error\", \"ignore\"), \n    copy = FALSE, in_place = FALSE) \n{\n    if (!is_dibble(x)) \n        return(NextMethod())\n    rlang::check_dots_empty()\n    call <- rlang::current_env()\n    .dibble_rows_in_place(in_place, call)\n    y <- dplyr::auto_copy(x, y, copy = copy)\n    .dibble_rows_change(x, y, by, \"update\", unmatched, call)\n})(structure(list(k = structure(c(1, 2), stata.storage = \"long\", class = c(\"dta_numeric\", \n\"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(10, \n20), stata.storage = \"double\", class = c(\"dta_numeric\", \"dta_double\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -2L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    structure(list(k = structure(3, stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(99, stata.storage = \"double\", class = c(\"dta_numeric\", \n    \"dta_double\", \"vctrs_vctr\", \"double\"))), row.names = c(NA, \n    -1L), class = c(\"dibble\", \"dtatools_ref_data\", \"tbl_df\", \n    \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    by = \"k\")", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/update_unmatched_ignore` = list(id = "B05/dibble/update_unmatched_ignore", 
        status = "return", conditions = list(), error = NULL, 
        snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 3), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/delete_extra_column` = list(id = "B05/dibble/delete_extra_column", 
        status = "return", conditions = list(list(classes = c("dplyr_message_delete_extra_cols", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Ignoring extra `y` columns: value", call = NULL, 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value"), row.names = 1L, 
                class = c("dibble", "dtatools_ref_data", "tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 2), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 20))), 
        inputs_before = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = c(10, 
            20)))), list(kind = "frame", attributes = list(names = c("k", 
            "value"), row.names = 1L, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = 1), value = list(kind = "double", 
                attributes = list(stata.storage = "double", class = c("dta_numeric", 
                "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_delete", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B05/dibble/default_by` = list(id = "B05/dibble/default_by", 
        status = "return", conditions = list(list(classes = c("dplyr_message_matching_by", 
        "dplyr_message", "rlang_message", "message", "condition"
        ), message = "Matching, by = \"k\"", call = NULL, parent = NULL)), 
        error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
        value = list(kind = "frame", attributes = list(names = c("k", 
        "value"), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
        "tbl_df", "tbl", "data.frame")), columns = list(k = list(
            kind = "double", attributes = list(stata.storage = "long", 
                class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                "double")), values = c(1, 2)), value = list(kind = "double", 
            attributes = list(stata.storage = "double", class = c("dta_numeric", 
            "dta_double", "vctrs_vctr", "double")), values = c(99, 
            20)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99))))), 
        selected_route = list(namespace = "dplyr", name = "rows_update", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(10, 
                20)))), list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1L, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = 1), 
                value = list(kind = "double", attributes = list(
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = 99)))))), 
    `B06/frame/scalar` = list(id = "B06/frame/scalar", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "added"
            ), row.names = 1:2, class = "data.frame"), columns = list(
                k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "integer", 
                  attributes = NULL, values = c(7L, 7L)), added = list(
                  kind = "character", attributes = NULL, values = c("x", 
                  "x")))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = c("value", "added")), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 7L), added = list(
                  kind = "character", attributes = NULL, values = "x"))))), 
        selected_route = list(namespace = "dplyr", name = "dplyr_col_modify", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = c("value", "added")), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 7L), added = list(
                  kind = "character", attributes = NULL, values = "x")))))), 
    `B06/frame/delete` = list(id = "B06/frame/delete", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "k", row.names = 1:2, class = "data.frame"), 
            columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "NULL", attributes = NULL, 
                    values = NULL))))), selected_route = list(
            namespace = "dplyr", name = "dplyr_col_modify", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "list", attributes = list(
                names = "value"), values = list(value = list(
                kind = "NULL", attributes = NULL, values = NULL)))))), 
    `B06/frame/wrong_size` = list(id = "B06/frame/wrong_size", 
        status = "error", conditions = list(), error = list(classes = c("vctrs_error_incompatible_size", 
        "vctrs_error_recycle_incompatible_size", "vctrs_error", 
        "rlang_error", "error", "condition"), message = "Can't recycle `value` (size 3) to size 2.", 
            call = "(function (data, cols) \n{\n    UseMethod(\"dplyr_col_modify\")\n})(structure(list(k = 1:2, value = structure(c(10, 20), label = \"binding value\")), class = \"data.frame\", row.names = c(NA, \n-2L)), list(value = 1:3))", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), class = "data.frame", row.names = 1:2), 
                columns = list(k = list(kind = "integer", attributes = NULL, 
                  values = 1:2), value = list(kind = "double", 
                  attributes = list(label = "binding value"), 
                  values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "integer", attributes = NULL, 
                    values = 1:3))))), selected_route = list(
            namespace = "dplyr", name = "dplyr_col_modify", direct = FALSE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), class = "data.frame", 
                row.names = 1:2), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2), value = list(
                kind = "double", attributes = list(label = "binding value"), 
                values = c(10, 20)))), list(kind = "list", attributes = list(
                names = "value"), values = list(value = list(
                kind = "integer", attributes = NULL, values = 1:3)))))), 
    `B06/tibble/scalar` = list(id = "B06/tibble/scalar", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "added"
            ), row.names = 1:2, class = c("tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "integer", attributes = NULL, 
                values = 1:2), value = list(kind = "integer", 
                attributes = NULL, values = c(7L, 7L)), added = list(
                kind = "character", attributes = NULL, values = c("x", 
                "x")))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(10, 
                  20)))), list(kind = "list", attributes = list(
                names = c("value", "added")), values = list(value = list(
                kind = "integer", attributes = NULL, values = 7L), 
                added = list(kind = "character", attributes = NULL, 
                  values = "x"))))), selected_route = list(namespace = "dplyr", 
            name = "dplyr_col_modify", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(10, 20
                )))), list(kind = "list", attributes = list(names = c("value", 
            "added")), values = list(value = list(kind = "integer", 
                attributes = NULL, values = 7L), added = list(
                kind = "character", attributes = NULL, values = "x")))))), 
    `B06/tibble/delete` = list(id = "B06/tibble/delete", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "k", row.names = 1:2, class = c("tbl_df", 
            "tbl", "data.frame")), columns = list(k = list(kind = "integer", 
                attributes = NULL, values = 1:2))), inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(10, 20
                )))), list(kind = "list", attributes = list(names = "value"), 
                values = list(value = list(kind = "NULL", attributes = NULL, 
                  values = NULL))))), selected_route = list(namespace = "dplyr", 
            name = "dplyr_col_modify", direct = FALSE), inputs_after = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                kind = "integer", attributes = NULL, values = 1:2), 
                value = list(kind = "double", attributes = list(
                  label = "binding value"), values = c(10, 20
                )))), list(kind = "list", attributes = list(names = "value"), 
                values = list(value = list(kind = "NULL", attributes = NULL, 
                  values = NULL)))))), `B06/tibble/wrong_size` = list(
        id = "B06/tibble/wrong_size", status = "error", conditions = list(), 
        error = list(classes = c("vctrs_error_incompatible_size", 
        "vctrs_error_recycle_incompatible_size", "vctrs_error", 
        "rlang_error", "error", "condition"), message = "Can't recycle `value` (size 3) to size 2.", 
            call = "(function (data, cols) \n{\n    UseMethod(\"dplyr_col_modify\")\n})(structure(list(k = 1:2, value = structure(c(10, 20), label = \"binding value\")), row.names = c(NA, \n-2L), class = c(\"tbl_df\", \"tbl\", \"data.frame\")), list(value = 1:3))", 
            parent = NULL), snapshot_status = "not_applicable", 
        snapshot_conditions = list(), snapshot_error = NULL, 
        value = NULL, inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(10, 
                  20)))), list(kind = "list", attributes = list(
                names = "value"), values = list(value = list(
                kind = "integer", attributes = NULL, values = 1:3))))), 
        selected_route = list(namespace = "dplyr", name = "dplyr_col_modify", 
            direct = FALSE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("tbl_df", 
                "tbl", "data.frame")), columns = list(k = list(
                  kind = "integer", attributes = NULL, values = 1:2), 
                  value = list(kind = "double", attributes = list(
                    label = "binding value"), values = c(10, 
                  20)))), list(kind = "list", attributes = list(
                names = "value"), values = list(value = list(
                kind = "integer", attributes = NULL, values = 1:3)))))), 
    `B06/dibble/scalar` = list(id = "B06/dibble/scalar", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "added"
            ), row.names = 1:2, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2)), value = list(
                kind = "double", attributes = list(label = "binding value", 
                  stata.storage = "double", class = c("dta_numeric", 
                  "dta_double", "vctrs_vctr", "double")), values = c(7, 
                7)), added = list(kind = "character", attributes = list(
                stata.string.storage = "str1"), values = c("x", 
            "x")))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = c("value", "added")), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 7L), added = list(
                  kind = "character", attributes = NULL, values = "x"))))), 
        selected_route = list(namespace = "dplyr", name = "dplyr_col_modify", 
            direct = TRUE), inputs_after = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = c("value", "added")), 
                values = list(value = list(kind = "integer", 
                  attributes = NULL, values = 7L), added = list(
                  kind = "character", attributes = NULL, values = "x")))))), 
    `B06/dibble/delete` = list(id = "B06/dibble/delete", status = "return", 
        conditions = list(), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = "k", row.names = 1:2, class = c("dibble", 
            "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
            )), columns = list(k = list(kind = "double", attributes = list(
                stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
            2)))), inputs_before = list(status = "complete", 
            conditions = list(), error = NULL, value = list(list(
                kind = "frame", attributes = list(names = c("k", 
                "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                  attributes = list(stata.storage = "long", class = c("dta_numeric", 
                  "dta_long", "vctrs_vctr", "double")), values = c(1, 
                  2)), value = list(kind = "double", attributes = list(
                  label = "binding value", stata.storage = "double", 
                  class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                  "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "NULL", attributes = NULL, 
                    values = NULL))))), selected_route = list(
            namespace = "dplyr", name = "dplyr_col_modify", direct = TRUE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "NULL", attributes = NULL, 
                    values = NULL)))))), `B06/dibble/wrong_size` = list(
        id = "B06/dibble/wrong_size", status = "error", conditions = list(), 
        error = list(classes = c("vctrs_error_incompatible_size", 
        "vctrs_error_recycle_incompatible_size", "vctrs_error", 
        "rlang_error", "error", "condition"), message = "Can't recycle `value` (size 3) to size 2.", 
            call = ".dibble_col_modify(data, cols)", parent = NULL), 
        snapshot_status = "not_applicable", snapshot_conditions = list(), 
        snapshot_error = NULL, value = NULL, inputs_before = list(
            status = "complete", conditions = list(), error = NULL, 
            value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "integer", attributes = NULL, 
                    values = 1:3))))), selected_route = list(
            namespace = "dplyr", name = "dplyr_col_modify", direct = TRUE), 
        inputs_after = list(status = "complete", conditions = list(), 
            error = NULL, value = list(list(kind = "frame", attributes = list(
                names = c("k", "value"), row.names = 1:2, class = c("dibble", 
                "dtatools_ref_data", "tbl_df", "tbl", "data.frame"
                )), columns = list(k = list(kind = "double", 
                attributes = list(stata.storage = "long", class = c("dta_numeric", 
                "dta_long", "vctrs_vctr", "double")), values = c(1, 
                2)), value = list(kind = "double", attributes = list(
                label = "binding value", stata.storage = "double", 
                class = c("dta_numeric", "dta_double", "vctrs_vctr", 
                "double")), values = c(10, 20)))), list(kind = "list", 
                attributes = list(names = "value"), values = list(
                  value = list(kind = "integer", attributes = NULL, 
                    values = 1:3)))))))
