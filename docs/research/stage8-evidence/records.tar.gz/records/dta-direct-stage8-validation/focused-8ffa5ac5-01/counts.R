list(blocks = 165L, passed = 3609L, failed = 3L, errors = 0L, 
    warnings = 0L, skips = 0L)
