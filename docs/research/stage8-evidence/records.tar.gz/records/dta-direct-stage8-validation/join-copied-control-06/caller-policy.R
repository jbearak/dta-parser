list(public = list(id = "public", status = "return", conditions = list(
    list(classes = c("dplyr_warning_join_relationship_many_to_many", 
    "dplyr_warning_join", "dplyr_warning", "rlang_warning", "warning", 
    "condition"), message = "Detected an unexpected many-to-many relationship between `x` and `y`.\ni Row 1 of `x` matches multiple rows in `y`.\ni Row 1 of `y` matches multiple rows in `x`.\ni If a many-to-many relationship is expected, set `relationship = \"many-to-many\"` to silence this warning.", 
        call = "operations[[name]](x, y, by = \"k\")", parent = NULL)), 
    error = NULL, snapshot_status = "complete", snapshot_conditions = list(), 
    value = list(kind = "frame", attributes = list(names = c("k", 
    "value", "other"), row.names = 1:5, class = c("dibble", "dtatools_ref_data", 
    "tbl_df", "tbl", "data.frame")), columns = list(k = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 1, 1, 1, 2)), value = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 1, 2, 2, 3)), other = list(
        kind = "double", attributes = list(stata.storage = "long", 
            class = c("dta_numeric", "dta_long", "vctrs_vctr", 
            "double")), values = c(1, 2, 1, 2, NA)))), policy_trace = list()), 
    old_wrapper = list(id = "old_wrapper", status = "return", 
        conditions = list(list(classes = c("dplyr_warning_join_relationship_many_to_many", 
        "dplyr_warning_join", "dplyr_warning", "rlang_warning", 
        "warning", "condition"), message = "Detected an unexpected many-to-many relationship between `x` and `y`.\ni Row 1 of `x` matches multiple rows in `y`.\ni Row 1 of `y` matches multiple rows in `x`.\ni If a many-to-many relationship is expected, set `relationship = \"many-to-many\"` to silence this warning.", 
            call = "(function (x, y, by = NULL, copy = FALSE, suffix = c(\".x\", \".y\"), \n    ..., keep = NULL, na_matches = c(\"na\", \"never\"), multiple = \"all\", \n    unmatched = \"drop\", relationship = NULL) \n{\n    if (!is_dibble(x)) \n        return(NextMethod())\n    rlang::check_dots_empty()\n    y <- dplyr::auto_copy(x, y, copy = copy)\n    .dibble_join_mutate(x, y, by, \"left\", suffix, keep, na_matches, \n        multiple, unmatched, relationship, rlang::current_env(), \n        rlang::caller_env())\n})(x = structure(list(k = structure(c(1, 1, 2), stata.storage = \"long\", class = c(\"dta_numeric\", \n\"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(1, \n2, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -3L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    y = structure(list(k = structure(c(1, 1, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), other = structure(c(1, \n    2, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n    \"vctrs_vctr\", \"double\"))), row.names = c(NA, -3L), class = c(\"dibble\", \n    \"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    by = \"k\")", 
            parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "other"
            ), row.names = 1:5, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1, 1, 1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1, 2, 2, 3)), other = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 1, 2, NA)))), 
        policy_trace = list(list(caller_is_empty = FALSE, top_is_global = FALSE, 
            top_is_namespace = TRUE, top_name = "dtatools", namespace = c(name = "dtatools"), 
            tested_package = "dtatools", eligible = TRUE, rlang_namespace = TRUE, 
            upstream_eligible = TRUE))), forwarded_wrapper = list(
        id = "forwarded_wrapper", status = "return", conditions = list(
            list(classes = c("dplyr_warning_join_relationship_many_to_many", 
            "dplyr_warning_join", "dplyr_warning", "rlang_warning", 
            "warning", "condition"), message = "Detected an unexpected many-to-many relationship between `x` and `y`.\ni Row 1 of `x` matches multiple rows in `y`.\ni Row 1 of `y` matches multiple rows in `x`.\ni If a many-to-many relationship is expected, set `relationship = \"many-to-many\"` to silence this warning.", 
                call = "(function (x, y, by = NULL, copy = FALSE, suffix = c(\".x\", \".y\"), \n    ..., keep = NULL, na_matches = c(\"na\", \"never\"), multiple = \"all\", \n    unmatched = \"drop\", relationship = NULL) \n{\n    if (!is_dibble(x)) \n        return(NextMethod())\n    rlang::check_dots_empty()\n    y <- dplyr::auto_copy(x, y, copy = copy)\n    .dibble_join_mutate(x, y, by, \"left\", suffix, keep, na_matches, \n        multiple, unmatched, relationship, rlang::current_env(), \n        rlang::caller_env())\n})(x = structure(list(k = structure(c(1, 1, 2), stata.storage = \"long\", class = c(\"dta_numeric\", \n\"dta_long\", \"vctrs_vctr\", \"double\")), value = structure(c(1, \n2, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n\"vctrs_vctr\", \"double\"))), row.names = c(NA, -3L), class = c(\"dibble\", \n\"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    y = structure(list(k = structure(c(1, 1, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \n    \"dta_long\", \"vctrs_vctr\", \"double\")), other = structure(c(1, \n    2, 3), stata.storage = \"long\", class = c(\"dta_numeric\", \"dta_long\", \n    \"vctrs_vctr\", \"double\"))), row.names = c(NA, -3L), class = c(\"dibble\", \n    \"dtatools_ref_data\", \"tbl_df\", \"tbl\", \"data.frame\"), .dtatools_ref_state = <environment>), \n    by = \"k\")", 
                parent = NULL)), error = NULL, snapshot_status = "complete", 
        snapshot_conditions = list(), value = list(kind = "frame", 
            attributes = list(names = c("k", "value", "other"
            ), row.names = 1:5, class = c("dibble", "dtatools_ref_data", 
            "tbl_df", "tbl", "data.frame")), columns = list(k = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1, 1, 1, 2)), value = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 1, 2, 2, 3)), other = list(
                kind = "double", attributes = list(stata.storage = "long", 
                  class = c("dta_numeric", "dta_long", "vctrs_vctr", 
                  "double")), values = c(1, 2, 1, 2, NA)))), 
        policy_trace = list(list(caller_is_empty = FALSE, top_is_global = FALSE, 
            top_is_namespace = TRUE, top_name = "dtatools", namespace = c(name = "dtatools"), 
            tested_package = "dtatools", eligible = TRUE, rlang_namespace = TRUE, 
            upstream_eligible = TRUE))))
