list(blocks = 10L, passed = 1931L, failed = 0L, errors = 0L, 
    warnings = 0L, skips = 0L)
