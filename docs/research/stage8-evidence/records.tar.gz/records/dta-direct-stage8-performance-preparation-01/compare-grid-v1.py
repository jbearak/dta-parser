"""Compare the assessed Stage8 candidate with both fixed predecessor routes."""
import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
                bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def assess(path, expected_digest, series):
    selected = identity(path)
    require(selected['sha256'] == expected_digest, 'Assessment digest differs')
    assessment = json.loads(path.read_text())
    require(identity(path) == selected, 'Assessment changed while reading')
    require(assessment['status'] == 'complete saved-grid assessment', 'Assessment incomplete')
    require(assessment['series'] == series and assessment['samples'] == 7 * series,
            'Wrong assessed grid size')
    for flag in ('exact_shape_membership', 'all_raw_profile_sums_and_maxima_match',
                 'all_sample_medians_and_gc_totals_match',
                 'all_state_steps_and_source_handles_match', 'selected_inputs_unchanged'):
        require(assessment[flag] is True, 'Missing assessment gate: ' + flag)
    candidates = [Path(name) for name in assessment['selected_files']
                  if name.endswith('/results/operations.csv')]
    require(len(candidates) == 1, 'Ambiguous operations file')
    operations_path = candidates[0]
    operations = identity(operations_path)
    require(operations['sha256'] == assessment['selected_files'][str(operations_path)],
            'Assessed operations file changed')
    rows = list(csv.DictReader(io.StringIO(operations_path.read_text())))
    require(identity(operations_path) == operations, 'Operations changed while reading')
    run = operations_path.parent.parent
    receipt_path = run / 'receipt.json'
    receipt_identity = identity(receipt_path)
    require(receipt_identity['sha256'] == assessment['receipt_sha256'], 'Receipt changed')
    receipt = json.loads(receipt_path.read_text())
    require(identity(receipt_path) == receipt_identity, 'Receipt changed while reading')
    require(receipt['status'] == 'complete', 'Run receipt incomplete')
    manifest_path = run / 'products.json'
    require(identity(manifest_path) == receipt['products'], 'Product index changed')
    require(identity(run / 'result.json') == receipt['result'], 'Run result changed')
    manifest = json.loads(manifest_path.read_text())['products']
    require(identity(manifest_path) == receipt['products'], 'Product index changed while reading')
    source_prefix = str(run / 'source') + '/'
    executed = {row['path'][len(source_prefix):]: (row['bytes'], row['mode'], row['sha256'])
                for row in manifest if row['path'].startswith(source_prefix)}
    require(executed and len(rows) == series, 'Missing executed source or grid records')
    require(all(row['values_metadata_groups_source'] == 'TRUE' and row['iterations'] == '7'
                for row in rows), 'Invalid operation validation records')
    return dict(assessment=selected, operations=operations, receipt=receipt_identity,
                manifest=receipt['products'], source=assessment['result']['source_sha'],
                runner=assessment['result']['runner_sha'], executed=executed, rows=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('predecessor', type=Path)
    parser.add_argument('predecessor_sha256')
    parser.add_argument('candidate', type=Path)
    parser.add_argument('candidate_sha256')
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    before = assess(args.predecessor, args.predecessor_sha256, 120)
    after = assess(args.candidate, args.candidate_sha256, 60)
    require(before['source'] == 'af0bed0b9c200f82d37891902266d200a1819196', 'Wrong predecessor')
    require(after['source'] != before['source'], 'Candidate must be distinct')
    require(before['runner'] == after['runner'], 'Runner revision differs')
    require(before['executed'] == after['executed'], 'Executed workload/support source differs')
    keys = ('rows', 'width', 'workload')
    key = lambda row: tuple(row[name] for name in keys)
    candidate = {key(row): row for row in after['rows']}
    require(len(candidate) == 60 and all(row['route'] == 'public' for row in candidate.values()),
            'Invalid candidate shapes/routes')
    old_keys = {(key(row), row['route']) for row in before['rows']}
    require(len(old_keys) == 120 and old_keys == {
        (shape, route) for shape in candidate for route in ('public', 'predecessor_safe_reference')
    }, 'Predecessor/candidate shape membership differs')
    skip = set(keys) | {'route', 'values_metadata_groups_source', 'iterations'}
    comparisons = []
    for old in before['rows']:
        new = candidate[key(old)]
        require(set(old) == set(new), 'Metric fields differ')
        row = {name: old[name] for name in keys}
        row['reference_route'] = old['route']
        for metric in old:
            if metric in skip:
                continue
            a, b = float(old[metric]), float(new[metric])
            require(math.isfinite(a) and math.isfinite(b), 'Nonfinite metric: ' + metric)
            row['before_' + metric] = a
            row['after_' + metric] = b
            row['delta_' + metric] = b - a
        require(row['before_median_ms'] > 0 and row['after_median_ms'] > 0, 'Invalid median')
        row['median_ratio'] = row['after_median_ms'] / row['before_median_ms']
        row['investigation_flag'] = row['median_ratio'] > 1.1 and row['delta_median_ms'] > 1
        comparisons.append(row)
    for run in (before, after):
        for name in ('assessment', 'operations', 'receipt', 'manifest'):
            require(identity(Path(run[name]['path'])) == run[name], 'Selected input changed')
    args.output.mkdir(parents=True, exist_ok=False)
    csv_path = args.output / 'comparisons.csv'
    with csv_path.open('x') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(comparisons[0]))
        writer.writeheader()
        writer.writerows(comparisons)
    summary = dict(predecessor={k: v for k, v in before.items() if k not in ('rows', 'executed')},
                   candidate={k: v for k, v in after.items() if k not in ('rows', 'executed')},
                   comparison_source=identity(Path(__file__).resolve()), pairs=120,
                   csv=identity(csv_path),
                   flags=[row for row in comparisons if row['investigation_flag']],
                   positive_median_deltas=sum(row['delta_median_ms'] > 0 for row in comparisons),
                   scope='Candidate public versus both fixed predecessor routes. Seven GC-inclusive samples per series, independently assessed before comparison. Joint >10% and >1ms flags require repeatability investigation. All positive and negative deltas remain in CSV. R allocation, overlapping native counters, retained heap and whole-child RSS remain separate; this is not overall Stage8 acceptance.')
    with (args.output / 'result.json').open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(pairs=120, flags=len(summary['flags']),
                          candidate_source=after['source'], output=str(args.output))))


if __name__ == '__main__':
    main()
