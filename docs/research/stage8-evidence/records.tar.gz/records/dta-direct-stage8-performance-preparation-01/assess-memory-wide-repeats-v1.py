"""Assess completed Stage8 memory records without rerunning any R workload."""
import csv
import hashlib
import itertools
import json
from pathlib import Path
import re
import sys

destination = Path(sys.argv[1])
runs = [Path(x).resolve(strict=True) for x in sys.argv[2:]]
assert len(runs) == 4 and len(set(runs)) == 4
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assessments = []
selected = {}
heap_steps = ['prefixture', '0_source_only', '5', '50', 'before_validation',
    'after_validation', 'first_released', 'latest_released', 'inputs_released',
    'released_gc_1', 'released_gc_2', 'released_gc_3']
for child in runs:
    count, workload, route = 100000, 'bind_rows_wide', 'public'
    receipt = json.loads((child / 'receipt.json').read_text())
    for row in [receipt['result'], receipt['products']]:
        assert sha(Path(row['path'])) == row['sha256']
    index = {row['path']: row for row in json.loads((child / 'products.json').read_text())['products']}
    def read(path):
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert digest == index[str(path)]['sha256']
        selected[str(path)] = digest
        return data.decode()
    def read_csv(path):
        return list(csv.DictReader(read(path).splitlines()))
    result = json.loads(read(child / 'result.json'))
    command = json.loads(read(child / 'command-result.json'))
    rss = json.loads(read(child / 'rss.json'))
    runtime = json.loads(read(child / 'runtime-coverage.json'))
    log = read(child / 'runner.log')
    assert result['status'] == 'complete' and result['input_binding_complete'] and result['inputs_unchanged']
    assert result['routes'] == route and result['memory_workload'] == workload
    assert command['returncode'] == 0 and command['error'] is None
    assert command['command'][:3] == ['/usr/bin/time', '-l', '/opt/homebrew/Cellar/r/4.6.1/bin/Rscript']
    assert int(command['command'][-1]) == count
    rss_values = re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$', log, re.MULTILINE)
    assert len(rss_values) == 1 and int(rss_values[0]) == rss['bytes'] and rss['bytes'] > 0
    assert rss['rows'] == count and rss['workload'] == workload and rss['route'] == route
    validation = read_csv(child / 'results/validation.csv')
    assert len(validation) == 1
    checked = validation[0]
    assert int(checked['rows']) == count and checked['width'] == '8'
    assert checked['workload'] == workload and checked['route'] == route
    assert checked['calls'] == '50' and checked['source_first_latest_values_schema'] == 'TRUE'
    heap = read_csv(child / 'results/heap.csv')
    assert [row['checkpoint'] for row in heap] == heap_steps
    assert all(int(row['vector_heap_bytes']) == 8 * int(row['v_cells_used']) for row in heap)
    states = read_csv(child / 'results/states.csv')
    assert {row['checkpoint'] for row in states} == {'0', '5', '50', 'after_validation'}
    assert all(row['depth'] == '1' for row in states if row['owned'] == 'TRUE')
    for role in ['x', 'y', 'first']:
        by_checkpoint = {}
        for row in states:
            if row['role'] == role:
                prior = by_checkpoint.setdefault(row['checkpoint'], {})
                assert row['path'] not in prior
                prior[row['path']] = row['handle']
        wanted = {'5', '50', 'after_validation'} | (set() if role == 'first' else {'0'})
        assert set(by_checkpoint) == wanted
        values = list(by_checkpoint.values())
        assert all(value == values[0] for value in values)
    checkpoints = {row['checkpoint']: row for row in heap}
    deltas = {}
    for before, after in [('5', '50'), ('50', 'after_validation'),
                          ('prefixture', 'released_gc_3')]:
        deltas[before + '_to_' + after] = {key:
            int(checkpoints[after][key]) - int(checkpoints[before][key])
            for key in ['n_cells_used', 'vector_heap_bytes']}
    assessments.append(dict(rows=count, workload=workload, route=route,
        receipt_sha256=sha(child / 'receipt.json'), rss_bytes=rss['bytes'],
        heap=heap, deltas=deltas, state_rows=len(states), source_sha=result['source_sha'],
        runtime=runtime, command=command['command']))
assert sorted(r['source_sha'] for r in assessments) == sorted([
    'af0bed0b9c200f82d37891902266d200a1819196',
    'cf317730d3110568c72862719424e01c2876141b'] * 2)
assert all(sha(Path(path)) == digest for path, digest in selected.items())
report = dict(status='Completed memory records assessed', cases=len(assessments),
    heap_rows=sum(len(row['heap']) for row in assessments),
    state_rows=sum(row['state_rows'] for row in assessments),
    measurements=assessments, selected_inputs_unchanged=True,
    scope='All case RSS/log/command/validation/heap/state records checked against producer identities; retained source/first handles and selected owned depth checked. Producer independent value/schema formulas passed, but final full payload snapshots are not saved. Whole-child RSS, recorder-inclusive finite heap and operation allocation remain separate; no asymptotic, exclusive object-cause or full process-image claim.',
    selected=selected)
with destination.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in report.items()
                  if key not in ['measurements', 'selected']}, indent=2))
for row in assessments:
    print(row['rows'], row['workload'], row['route'], row['rss_bytes'], row['deltas'])
