from pathlib import Path
import hashlib
import json

P = Path('/private/tmp/dta-direct-stage8-performance-preparation-01')
V = Path('/private/tmp/dta-direct-stage8-validation')
R = Path('/private/tmp/dta-direct-stage8-retention-preparation-01')
selected = {}

def add(path, category, expected=None):
    path = Path(path)
    if not path.is_file():
        raise ValueError(f'Missing selected file: {path}')
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if expected is not None and digest != expected:
        raise ValueError(f'Changed assessed file: {path}')
    row = selected.setdefault(str(path), {
        'path': str(path), 'resolved': str(path.resolve()),
        'bytes': len(data), 'sha256': digest,
        'categories': [],
    })
    if category not in row['categories']:
        row['categories'].append(category)

def tree(path, category):
    for file in sorted(Path(path).rglob('*')):
        if file.is_file():
            add(file, category)

# These directories contain root preparation, source, assessments and saved
# comparison results. No live dependency installation is enumerated here.
for file in sorted(P.iterdir()):
    if file.is_file() and file.name not in {'CURRENT.json', 'root-artifact-selection-01.json'}:
        add(file, 'root-preparation-and-assessments')
for name in ['draft-03', 'comparison-cf317730-01',
             'bind-cols-repeat-comparison-01', 'bind-cols-repeat-comparison-02',
             'bind-cols-repeat-comparison-03', 'repeat-execution-timing-01',
             'repeat-execution-rss-01']:
    tree(P / name, 'prepared-sources-and-executed-comparisons')

# Preserve the exact raw files already selected by completed root assessments.
for file in sorted(P.glob('*assessment*.json')):
    obj = json.loads(file.read_text())
    for key in ['selected', 'selected_files']:
        for path, digest in obj.get(key, {}).items():
            if isinstance(digest, str) and len(digest) == 64:
                add(path, 'previously-assessed-raw-record', digest)

run_names = [
    'root-performance-schemas-01', 'root-performance-predecessor-01',
    'root-performance-cf317730-01', 'root-performance-8ffa5ac5-smoke-01',
    'root-retention-predecessor-01', 'root-retention-predecessor-02',
    'root-retention-8ffa5ac5-01', 'root-copied-retention-01',
    'root-retention-writes-predecessor-01', 'root-retention-writes-cf317730-01',
]
run_names += [f'root-bind-cols-repeat-{role}-{i:02}'
              for role in ['predecessor', 'cf317730'] for i in range(1, 4)]
run_names += [f'root-memory-wide-repeat-{role}-{i:02}'
              for role in ['predecessor', 'cf317730'] for i in range(1, 3)]
for role in ['predecessor', 'cf317730']:
    batch = V / f'root-memory-{role}-01'
    for file in sorted(batch.iterdir()):
        if file.is_file():
            add(file, 'memory-batch-record')
        elif file.is_dir():
            run_names.append(str(file.relative_to(V)))

for name in run_names:
    run = V / name
    for file in sorted(run.iterdir()):
        if file.is_file() and file.name not in {'inputs-before.json', 'inputs-after.json'}:
            add(file, 'producer-control-record')
    for dirname in ['source', 'results']:
        if (run / dirname).is_dir():
            tree(run / dirname, 'producer-source-or-raw-result')

# Minimum execution and selected linkage are interpreted with the parent-owned
# installation and full/package/native evidence, not as a separate closure.
add(V / 'root-minimum-cf317730-dll-linkage-01.json', 'minimum-static-linkage')
add(V / 'history-lifetime-correction-commit-01.json', 'source-reuse-bridge')
for file in sorted(R.iterdir()):
    if file.is_file() and file.suffix in {'.R', '.py', '.md', '.json'}:
        add(file, 'retention-preparation')

for relative in [
    'api-review/repeat-execution-selected-chain-01.json',
    'api-review/repeat-source-launchers-01.md',
    'api-review/stage8-assessor-v2-source-review-01.json',
    'api-review/stage8-comparator-v1-source-review-01.md',
    'api-review/cf317-minimum-selected-chain-01.json',
    'semantics-review/bind-cols-reference-overhead-source-01.md',
    'semantics-review/bind-cols-repeat-source-01.md',
    'semantics-review/retention-8ffa5ac5-01.md',
]:
    add(V / relative, 'independent-review')
for relative in ['semantics-review/bind-cols-repeats-01',
                 'semantics-review/retention-writes-cf317730-01']:
    tree(V / relative, 'independent-review')

rows = [selected[key] for key in sorted(selected)]
result = {
    'status': 'root-selected-artifact-handoff',
    'candidate_source': 'cf317730d3110568c72862719424e01c2876141b',
    'predecessor_source': 'af0bed0b9c200f82d37891902266d200a1819196',
    'disposition': str(P / 'stage8-performance-disposition-draft-02.md'),
    'files': rows,
    'file_count': len(rows),
    'total_bytes': sum(row['bytes'] for row in rows),
    'scope': [
        'This is a publication selection of existing records, not a rerun or new acceptance test.',
        'Assessed raw-file digests are checked where prior assessments provide them. Other selected files are freshly hashed for publication transport only.',
        'Complete before/after live dependency inventories remain at original run paths and are bound by existing receipts; they are deliberately omitted from this compact selection.',
        'Prepared but unused versions and preserved failed attempts retain their names and status. Their inclusion is not an execution or acceptance claim.',
        'Parent adds semantic controls, installation/full/package/native and source-review records under its existing evidence selection.',
        'Absolute original paths inside records remain original observations. The durable bundle must provide a mapping without rewriting original bytes.',
        'Stage8 publication/CI/implementation review/normal merge and all Stage9/final epic obligations remain open.',
    ],
}
destination = P / 'root-artifact-selection-01.json'
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(destination), 'files': len(rows),
                  'bytes': result['total_bytes'],
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
