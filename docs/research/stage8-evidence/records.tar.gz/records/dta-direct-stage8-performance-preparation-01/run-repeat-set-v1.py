"""Run the reviewed restricted repeat launchers in alternating pair order."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
p = Path('/private/tmp/dta-direct-stage8-performance-preparation-01')
selection = p / 'repeat-preparation-01.json'
selection_sha = '2cc80eeead0c0d4e84daf3ae702e187d12ac48c53c457f89f5e86af95ea6523c'
mode = sys.argv[1]
assert mode in ['timing', 'rss']
kind = 'bind_cols' if mode == 'timing' else 'RSS'
python = Path('/opt/homebrew/Cellar/python@3.14/3.14.7/bin/python3.14')
def ident(f):
    return dict(path=str(f), resolved=str(f.resolve(strict=True)), bytes=f.stat().st_size,
        mode=oct(f.stat().st_mode & 0o777), sha256=hashlib.sha256(f.read_bytes()).hexdigest())
def save(f, value):
    with f.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ident(selection)['sha256'] == selection_sha
chosen = json.loads(selection.read_text())
assert ident(selection)['sha256'] == selection_sha
rows = {(x['pair'], x['role']): x for x in chosen['launchers'] if x['kind'] == kind}
pairs = 3 if mode == 'timing' else 2
order = [(i, role) for i in range(1, pairs + 1) for role in
         (['predecessor', 'cf317730'] if i % 2 else ['cf317730', 'predecessor'])]
assert set(rows) == set(order)
for x in rows.values():
    assert ident(Path(x['source']['path'])) == x['source']
paths = [selection, python, Path(sys.executable), Path(__file__).resolve(),
         *[Path(rows[key]['source']['path']) for key in order]]
before = [ident(x) for x in paths]
output = p / ('repeat-execution-' + mode + '-01')
output.mkdir(exist_ok=False)
save(output / 'launch.json', dict(order=order, inputs=before, python_invocation=sys.orig_argv,
    started_utc=now(), scope='Alternating source order. Each unchanged individual launcher binds its fresh output and accepted installation. No full interpreter/process closure.'))
records, failure = [], None
try:
    for number, key in enumerate(order):
        assert [ident(x) for x in paths] == before
        command = [str(python), '-I', '-B', rows[key]['source']['path']]
        record = dict(pair=key[0], role=key[1], command=command, cwd=str(p), started_utc=now())
        save(output / (str(number) + '-before.json'), record)
        with (output / (str(number) + '.log')).open('x') as stream:
            result = subprocess.run(command, cwd=p, stdout=stream, stderr=subprocess.STDOUT)
        record.update(returncode=result.returncode, completed_utc=now())
        records.append(record)
        save(output / (str(number) + '-result.json'), record)
        assert result.returncode == 0
        print(mode, key[0], key[1], 'complete', flush=True)
except BaseException as error:
    failure = dict(type=type(error).__name__, message=str(error))
    raise
finally:
    unchanged = [ident(x) for x in paths] == before
    save(output / 'result.json', dict(records=records, failure=failure,
        inputs_unchanged=unchanged, completed_utc=now(),
        status='complete' if unchanged and failure is None and len(records) == len(order) else 'failed'))
assert unchanged
