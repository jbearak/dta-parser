"""Inspect completed finite-history writer records; semantic decoding is separate."""
import csv
import hashlib
import io
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve(strict=True)
destination = Path(sys.argv[2])

def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
                bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

receipt_identity = identity(root / 'receipt.json')
receipt = json.loads((root / 'receipt.json').read_text())
assert receipt['status'] == 'complete'
assert identity(root / 'products.json') == receipt['products']
assert identity(root / 'result.json') == receipt['result']
products = {x['path']: x for x in json.loads((root / 'products.json').read_text())['products']}
checked = {}

def bound(path):
    row = products[str(path)]
    assert identity(path) == row, str(path)
    data = path.read_bytes()
    assert identity(path) == row, str(path)
    checked[str(path)] = row
    return data

def rows(path, delimiter=','):
    return list(csv.DictReader(io.StringIO(bound(path).decode()), delimiter=delimiter))

result = json.loads((root / 'result.json').read_text())
assert result['status'] == 'complete' and result['inputs_unchanged'] is True
command = json.loads(bound(root / 'command-result.json'))
assert command['returncode'] == 0 and command['error'] is None
inputs = json.loads(bound(root / 'inputs-before.json'))
input_paths = {x['resolved'] for x in inputs}
runtime = json.loads(bound(root / 'runtime-coverage.json'))
assert bound(root / 'runner.log').decode().strip() == 'PASS twenty-four public installed write cases after500calls; protected roles and intended duplicate-slot coupling checked.'
cases = rows(root / 'results' / 'retention-write-cases.csv')
expected = set()
for duplicate in ('FALSE', 'TRUE'):
    for lifetime in ('fixed_original', 'latest_chain', 'retained_chain'):
        for direction in (('result',) if lifetime == 'latest_chain' else ('source', 'result')):
            for write in ('payload', 'metadata'):
                expected.add(('selector', lifetime, duplicate, direction, write))
for kind in ('constructor', 'reserve'):
    for write in ('payload', 'metadata'):
        expected.add((kind, 'latest_chain', 'FALSE', 'result', write))
keys = ('kind', 'lifetime', 'duplicate', 'direction', 'write_kind')
actual = {tuple(case[k] for k in keys) for case in cases}
assert len(cases) == 24 and actual == expected
namespace_count = dll_count = 0
temporary_dlls = []
for case in cases:
    assert case['planned_calls'] == '500' and case['passed'] == 'TRUE'
    directory = root / 'results' / '-'.join(case[k] for k in keys)
    assert bound(directory / 'completed-calls.txt').decode().strip() == '500'
    for name in ('primitives-before.txt', 'primitives.txt'):
        assert bound(directory / name).decode().split() == (['1', '0'] if name == 'primitives-before.txt' else ['1', '0', '1', '0'])
    for name in ('stdout.log', 'stderr.log'):
        assert not bound(directory / name).strip()
    child = bound(directory / 'result.R').decode()
    assert 'passed = TRUE' in child and 'calls = 500L' in child
    assert 'rows = 16L, payload_width = 8L' in child
    assert result['source_sha'] in child
    assert str(Path(result['installation']) / 'library' / 'dtatools') in child
    assert bound(directory / 'parent-result.R').decode() == child
    coupled = case['duplicate'] == 'TRUE' and case['direction'] == 'result'
    assert ('affected_columns = c("c01", "copy")' if coupled else
            'affected_columns = "c01"') in child
    for name in ('prepared-observations.rds', 'observations.rds'):
        assert len(bound(directory / name)) > 0
    for namespace in rows(directory / 'namespaces.tsv', '\t'):
        prefix = str(Path(namespace['path']).resolve(strict=True)) + '/'
        assert any(path.startswith(prefix) for path in input_paths), namespace
        namespace_count += 1
    for dll in rows(directory / 'dlls.tsv', '\t'):
        if dll['path'] == 'base':
            continue
        path = Path(dll['path'])
        if dll['name'] == 'client' and not path.exists():
            temporary_dlls.append(dll)
            continue
        assert str(path.resolve(strict=True)) in input_paths, dll
        dll_count += 1
assert identity(root / 'receipt.json') == receipt_identity
assert identity(root / 'products.json') == receipt['products']
assert all(identity(Path(path)) == row for path, row in checked.items())
assessment = dict(status='24 completed producer cases; independent graph decoding separate',
    output=str(root), receipt_sha256=receipt_identity['sha256'], cases=24,
    exact_case_membership=True, completed_calls_per_child=500,
    graph_files_present_and_bound=48, primitive_records_passed=48,
    child_namespace_rows=namespace_count, surviving_file_dll_rows=dll_count,
    missing_temporary_client_dll_rows=len(temporary_dlls),
    temporary_dll_paths=sorted({x['path'] for x in temporary_dlls}),
    selected_output_files_checked=len(checked), parent_runtime=runtime,
    scope='All case rows, child completion markers, primitive observations, result records, graph file identities and declared namespace/DLL paths checked. Full graph decoding remains separate. Temporary callr client bytes were not captured; no complete child-image closure, timing/RSS/heap or arbitrary-type write claim.')
with destination.open('x') as stream:
    json.dump(assessment, stream, indent=2)
    stream.write('\n')
print(json.dumps(assessment, indent=2))
