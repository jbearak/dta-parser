# Fixed-reference write qualification

Run this only after the tiny predecessor schema/value run establishes which reference routes match the public contract. A source-clear wrapper or schema match is not a write-isolation result. The control must remain restricted to installed af0bed0b9c200f82d37891902266d200a1819196.

Use the same fifteen workload families at 16 left rows and width eight. Each write case creates fresh inputs and retains the first and latest of five calls. Use ordinary semantic copies only for expected observations. Record intended target changes and all protected original/first/latest values and metadata after the write, not merely a lack of thrown conditions. Keep each case in a disposable child and record runtime/error outcomes even when assertions fail.

Use multi-element c01/r01 numeric columns for the initial payload and metadata writes. These avoid the known unrelated logical-singleton hazard while testing actual foreign-write capture. Payload writes change one existing element through data.table::set; metadata writes change a column label through data.table::setattr. Keep tested numeric payloads and written indices explicit. This is not logical/factor/native-pointer qualification; those remain with the broader implementation/native matrix.

For each source that contributes a payload column, test source-to-results and latest-result-to-sources directions, independently for payload and metadata. Semi/anti joins and reconstruction have only a contributing x payload in this fixture; y payload writes do not meaningfully test output storage there. For rows_update, use x row one and a right update row at global key four. For rbind/bind_rows, write the corresponding left or right output segment. For a padded full join, choose a matched nonmissing right payload. For nesting, write the actual inner frame at the relevant key and protect every nested sibling and retained output.

Check source, first and latest with independent fixture values before any write. After writing, compare a complete tiny semantic record against the deliberately changed target and unchanged protected records. Distinguish top-level source roles from nested result paths. Preserve primitive/runtime checks where inherited from the established disposable writer; never retry a known corrupting case in the shared process.

Where the safe reference fails, repair its bounded control and rerun affected cases before using it in a safety-equivalent comparison. Preserve read-only predecessor timings separately if its public output has a write defect. A defect at one recorded size/type does not establish that every timing fixture has that defect.

The planned fixed reference is a measurement control, not production code or a new public fallback. The implementation agent's source/result tests still cover mixed ordinary/data.table/list storage, logicals/factors, metadata policies, typed missing values and the full join/bind/rows integration contracts.
