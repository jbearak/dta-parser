"""Assess eight completed installed500-call heap records without rerunning R."""
import csv
import hashlib
import io
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve(strict=True)
destination = Path(sys.argv[2])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt_path = root / 'receipt.json'
receipt_digest = digest(receipt_path)
receipt = json.loads(receipt_path.read_text())
assert receipt['status'] == 'complete'
for row in (receipt['products'], receipt['result']):
    assert digest(Path(row['path'])) == row['sha256']
products = {row['path']: row for row in json.loads((root / 'products.json').read_text())['products']}
selected = {}

def read(path):
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    assert actual == products[str(path)]['sha256'], str(path)
    selected[str(path)] = actual
    return data.decode()

def rows(path, delimiter=','):
    return list(csv.DictReader(io.StringIO(read(path)), delimiter=delimiter))

result = json.loads(read(root / 'result.json'))
command = json.loads(read(root / 'command-result.json'))
assert result['status'] == 'complete' and result['inputs_unchanged'] and result['input_binding_complete']
assert command['returncode'] == 0 and command['error'] is None
assert read(root / 'runner.log').strip() == 'PASS eight installed-source retained-heap children; separate source/result lifetimes preserved.'
cases = rows(root / 'results/retention-cases.csv')
keys = ('kind', 'lifetime', 'duplicate')
expected = {('selector', lifetime, duplicate)
            for lifetime in ('fixed_original', 'latest_chain', 'retained_chain')
            for duplicate in ('FALSE', 'TRUE')}
expected |= {(kind, 'latest_chain', 'FALSE') for kind in ('constructor', 'reserve')}
assert len(cases) == 8 and {tuple(row[key] for key in keys) for row in cases} == expected
heap_steps = ['prefixture', '0', '5', '50', '500', 'before_validation',
              'after_validation', 'released', 'released_gc_1', 'released_gc_2', 'released_gc_3']
measurements = []
for case in cases:
    assert case['planned_calls'] == '500' and case['passed'] == 'TRUE'
    directory = root / 'results' / '-'.join(case[key] for key in keys)
    child = read(directory / 'result.R')
    assert 'passed = TRUE' in child and 'calls = 500L' in child
    assert 'rows = 256L, payload_width = 8L' in ' '.join(child.split())
    assert result['source_sha'] in child and result['installation'] + '/library/dtatools' in child
    assert read(directory / 'parent-result.R') == child
    assert not read(directory / 'stdout.log').strip() and not read(directory / 'stderr.log').strip()
    heap = rows(directory / 'heap.csv')
    assert [row['checkpoint'] for row in heap] == heap_steps
    assert all(int(row['vector_heap_bytes']) == 8 * int(row['v_cells_used']) for row in heap)
    states = rows(directory / 'states.csv')
    assert all(row['depth'] == '1' for row in states if row['owned'] == 'TRUE')
    expected_membership = {('prime', 'discarded_warm_result')}
    for checkpoint in ('5', '50', '500', 'after_validation'):
        expected_membership.add((checkpoint, 'latest'))
        if case['lifetime'] in ('fixed_original', 'retained_chain'):
            expected_membership.add((checkpoint, 'original'))
        if case['lifetime'] == 'retained_chain':
            expected_membership.add((checkpoint, 'first'))
    if case['kind'] != 'constructor':
        expected_membership.add(('0', 'latest'))
    if case['lifetime'] in ('fixed_original', 'retained_chain'):
        expected_membership.add(('0', 'original'))
    assert {(row['checkpoint'], row['role']) for row in states} == expected_membership
    state_map = {}
    for row in states:
        checkpoint_role = (row['checkpoint'], row['role'])
        columns = state_map.setdefault(checkpoint_role, {})
        assert row['column'] not in columns
        columns[row['column']] = row['handle']
    for (checkpoint, role), columns in state_map.items():
        duplicate = case['duplicate'] == 'TRUE' and checkpoint != '0' and role != 'original'
        expected_columns = ['key'] + [f'c{i:02d}' for i in range(1, 9)] + (['copy'] if duplicate else [])
        assert list(columns) == expected_columns
    for role in ('original', 'first'):
        handles = [value for (checkpoint, selected_role), value in state_map.items() if selected_role == role]
        assert all(value == handles[0] for value in handles)
    by_step = {row['checkpoint']: row for row in heap}
    deltas = {}
    for before, after in [('5', '50'), ('50', '500'), ('500', 'after_validation'),
                          ('prefixture', 'released_gc_3'), ('released', 'released_gc_3')]:
        deltas[before + '_to_' + after] = {
            field: int(by_step[after][field]) - int(by_step[before][field])
            for field in ('n_cells_used', 'vector_heap_bytes')}
    measurements.append(dict(case={key: case[key] for key in keys},
                             heap=heap, deltas=deltas, state_rows=len(states)))
assert digest(receipt_path) == receipt_digest
assert digest(root / 'products.json') == receipt['products']['sha256']
assert all(digest(Path(path)) == value for path, value in selected.items())
report = dict(status='Eight completed installed finite histories assessed',
    source=result['source_sha'], receipt_sha256=receipt_digest, cases=8,
    heap_rows=sum(len(row['heap']) for row in measurements),
    state_rows=sum(row['state_rows'] for row in measurements), measurements=measurements,
    selected_inputs_unchanged=True, selected=selected,
    scope='All eight case records, heap rows and selected state histories checked against producer identities. Original/first handles remain stable and selected owned depths equal1. Full final payload snapshots were not saved; producer independent values/schema assertions and separate semantic controls remain complementary. Finite recorder-inclusive heap only, not zero/asymptotic/exclusive object cause, timing/RSS/write or full process-image acceptance.')
with destination.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in report.items() if key not in ('measurements', 'selected')}, indent=2))
for row in measurements:
    print(row['case'], row['deltas'])
