# Deliberate tiny value/metadata faults. No timing or allocation acceptance.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
for (name in c("workloads-v1.R", "reference-v1.R", "validation-v1.R"))
    source(file.path(support, name))
schemas <- dget(Sys.getenv("DTA_STAGE8_SCHEMAS"))
suppressPackageStartupMessages(library(bench))
records <- list()
run_control <- function(name, workload, change, expected_message) {
    input <- s8_fixture(16L, 8L, workload)
    good <- s8_invoke(input, "public")
    schema <- schemas[[paste(8L, workload, sep = "-")]]
    s8_check_result(good, input, schema$result)
    s8_check_source(input, schema)
    # Materializing serialization and fresh assigned preparation make the
    # deliberately invalid table independent from source and positive result.
    bad <- dtatools::reserve_columns(unserialize(serialize(good, NULL)), n = 32L)
    s8_check_result(bad, input, schema$result)
    change(bad)
    condition <- tryCatch({s8_check_result(bad, input, schema$result); NULL}, error = identity)
    observed <- list(name = name, workload = workload, rejected = !is.null(condition),
        classes = if (is.null(condition)) character() else class(condition),
        message = if (is.null(condition)) "" else conditionMessage(condition),
        expected_message = expected_message)
    dput(observed, file.path(output, paste0(name, ".R")))
    stopifnot(!is.null(condition), grepl(expected_message, conditionMessage(condition), fixed = TRUE))
    s8_check_result(good, input, schema$result)
    s8_check_source(input, schema)
    records[[length(records) + 1L]] <<- data.frame(name, workload, rejected = TRUE,
        positive_and_sources_preserved = TRUE, message = conditionMessage(condition))
    write.csv(do.call(rbind, records), file.path(output, "validator-controls.csv"), row.names = FALSE)
}
run_control("fractional_numeric", "left_unique", function(bad) {
    data.table::set(bad, i = 1L, j = "c01", value = as.double(bad$c01[[1L]]) + .125)
}, "values differ for c01")
run_control("logical_type", "left_unique", function(bad) {
    data.table::set(bad, j = "c02", value = as.double(bad$c02))
}, "values differ for c02")
run_control("row_order", "left_unique", function(bad) {
    data.table::set(bad, j = "key", value = rev(as.double(bad$key)))
}, "values differ for key")
run_control("table_metadata", "left_unique", function(bad) {
    data.table::setattr(bad, "label", "Deliberately wrong table label")
}, "result schema")
run_control("column_metadata", "left_unique", function(bad) {
    data.table::setattr(bad$c01, "label", "Deliberately wrong column label")
}, "result schema")
run_control("outer_padding", "full_padded", function(bad) {
    data.table::set(bad, i = 1L, j = "r05", value = "wrong")
}, "values differ for r05")
run_control("group_locations", "grouped_left", function(bad) {
    groups <- unserialize(serialize(attr(bad, "groups", exact = TRUE), NULL))
    groups$.rows[[1L]] <- 2L
    data.table::setattr(bad, "groups", groups)
}, "group row locations")
run_control("nested_payload", "nest_double", function(bad) {
    child <- bad$nested[[1L]]
    data.table::set(child, i = 1L, j = "r01", value = as.double(child$r01[[1L]]) + .125)
}, "values differ for r01")
stopifnot(length(records) == 8L)
validate_benchmark_install(library_path, args[[3L]])
cat("PASS eight deliberate validator faults rejected for the intended reasons; positive results and sources preserved.\n")
