# One fixed-input operation per fresh R process; first and latest results survive.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
rows <- as.integer(args[[5L]])
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
for (name in c("workloads-v1.R", "reference-v1.R", "validation-v1.R"))
    source(file.path(support, name))
schemas <- dget(Sys.getenv("DTA_STAGE8_SCHEMAS"))
route <- Sys.getenv("DTA_STAGE8_ROUTES")
workload <- Sys.getenv("DTA_STAGE8_MEMORY_WORKLOAD")
stopifnot(route %in% c("public", "predecessor_safe_reference"),
    workload %in% c("full_padded", "base_cbind", "bind_rows_wide", "nest_double"),
    length(rows) == 1L, !is.na(rows), rows >= 16L, rows %% 4L == 0L)
if (route == "predecessor_safe_reference") s8_reference_start(library_path)
suppressPackageStartupMessages(library(bench))
width <- 8L
schema <- schemas[[paste(width, workload, sep = "-")]]
stopifnot(!is.null(schema))
writeLines(c(atomic_identity(args[[3L]], library_path, "candidate"),
    paste("workload", workload, "route", route, "rows", rows, "payload width8"),
    "Fifty calls read the original fixed x/y fixture; first and latest results remain live at5/50.",
    "Heap precedes native state observation and final payload validation; schemas contain ordinary metadata, not table handles.",
    "State frames contain scalars/addresses and are streamed, then discarded. The small heap recorder is retained.",
    "Native observations cover all flat columns and first/last nested children plus prototype, if any; all nested values are checked separately.",
    "Whole-child RSS includes setup, calls, validation, state observation and runtime recording.",
    "No foreign writes in this child. Separate tiny fifty-call source/first/latest writes qualify their bounded numeric/label cases."),
    file.path(output, "session.txt"))

s8_states <- function(value, path) {
    records <- list()
    visit <- function(frame, path) {
        for (i in seq_along(frame)) {
            column <- .subset2(frame, i)
            here <- paste(path, names(frame)[[i]], sep = "/")
            if (typeof(column) == "list") {
                # Bound observer work independently of nested output count.
                # All children still receive value/schema checks separately.
                selected <- if (length(column)) unique(c(1L, length(column))) else integer()
                for (j in selected) if (is.data.frame(.subset2(column, j)))
                    visit(.subset2(column, j), paste0(here, "[", j, "]"))
                prototype <- attr(column, "ptype", exact = TRUE)
                if (is.data.frame(prototype)) visit(prototype, paste0(here, "/ptype"))
            } else {
                info <- owned_native("C_dtatools_mutation_info", frame, as.integer(i))
                owned <- owned_native("C_dtatools_owned_info", column)
                if (!is.null(owned)) stopifnot(owned$depth == 1L)
                records[[length(records) + 1L]] <<- cbind(data.frame(path = here,
                    type = typeof(column), length = length(column), owned = !is.null(owned)),
                    as.data.frame(info))
            }
        }
    }
    visit(value, path)
    do.call(rbind, records)
}

heap <- list()
record_heap <- function(checkpoint) {
    invisible(gc(full = TRUE))
    current <- gc(full = TRUE)
    heap[[length(heap) + 1L]] <<- data.frame(checkpoint,
        n_cells_used = current["Ncells", "used"], v_cells_used = current["Vcells", "used"],
        vector_heap_bytes = current["Vcells", "used"] * 8,
        gc_used_megabytes_rounded = sum(current[, 2L]))
    write.csv(do.call(rbind, heap), file.path(output, "heap.csv"), row.names = FALSE)
    invisible(NULL)
}
record_state <- function(value, checkpoint, role) {
    current <- cbind(data.frame(checkpoint, role), s8_states(value, role))
    path <- file.path(output, "states.csv")
    write.table(current, path, sep = ",", row.names = FALSE,
        col.names = !file.exists(path), append = file.exists(path))
    invisible(NULL)
}
check <- function(input, value) {
    s8_check_source(input, schema)
    s8_check_result(value, input, schema$result)
    invisible(NULL)
}
run_repeated <- function() {
    warm_input <- s8_fixture(16L, width, workload)
    warm_result <- s8_invoke(warm_input, route)
    check(warm_input, warm_result)
    invisible(s8_states(warm_input$x, "warm_x"))
    invisible(s8_states(warm_input$y, "warm_y"))
    invisible(s8_states(warm_result, "warm_result"))
    rm(warm_input, warm_result)
    record_heap("prefixture")
    input <- s8_fixture(rows, width, workload)
    first <- latest <- NULL
    record_heap("0_source_only")
    record_state(input$x, "0", "x")
    record_state(input$y, "0", "y")
    for (i in seq_len(50L)) {
        latest <- s8_invoke(input, route)
        if (i == 1L) first <- latest
        if (i %in% c(5L, 50L)) {
            record_heap(as.character(i))
            record_state(input$x, as.character(i), "x")
            record_state(input$y, as.character(i), "y")
            record_state(first, as.character(i), "first")
            record_state(latest, as.character(i), "latest")
        }
    }
    record_heap("before_validation")
    check(input, first)
    check(input, latest)
    write.csv(data.frame(rows, width, workload, route, calls = 50L,
        source_first_latest_values_schema = TRUE),
        file.path(output, "validation.csv"), row.names = FALSE)
    record_heap("after_validation")
    record_state(input$x, "after_validation", "x")
    record_state(input$y, "after_validation", "y")
    record_state(first, "after_validation", "first")
    record_state(latest, "after_validation", "latest")
    rm(first)
    record_heap("first_released")
    rm(latest)
    record_heap("latest_released")
    rm(input)
    record_heap("inputs_released")
    for (i in seq_len(3L)) record_heap(paste0("released_gc_", i))
    invisible(NULL)
}
run_repeated()
validate_benchmark_install(library_path, args[[3L]])
cat("PASS fifty fixed-input calls, independent source/first/latest values/schema and bounded native depth checks.\n")
