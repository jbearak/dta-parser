"""Twenty-four installed candidate later-write witnesses after500calls."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/private/tmp/dta-direct-stage8-performance-preparation-01/draft-03')
output = Path('/private/tmp/dta-direct-stage8-validation/root-retention-writes-8ffa5ac5-01')
python = Path('/opt/homebrew/Cellar/python@3.14/3.14.7/bin/python3.14')
freeze_path = root / 'retention-writes-freeze-01.json'
freeze_sha = '5978135dc7414e3b41e243fdeb52fb3bd9687fb1fbdee50854a44b881cbbda4f'

def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
        bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

freeze_identity = identity(freeze_path)
if freeze_identity['sha256'] != freeze_sha:
    raise RuntimeError('Prepared source freeze changed')
freeze = json.loads(freeze_path.read_text())
if identity(freeze_path) != freeze_identity:
    raise RuntimeError('Source freeze changed while reading')
approved = {str(freeze_path): freeze_identity}
for row in freeze['files']:
    if identity(Path(row['path'])) != row:
        raise RuntimeError('Prepared source changed: ' + row['path'])
    approved[row['path']] = row
selected = [python, python.resolve(strict=True), Path(sys.executable),
    Path(__file__).resolve(), freeze_path,
    Path('/opt/homebrew/bin/git'), Path('/opt/homebrew/bin/git').resolve(strict=True),
    Path('/opt/homebrew/Cellar/r/4.6.1/bin/Rscript')]
selected.extend(Path(row['path']) for row in freeze['files'])
before = [identity(path) for path in selected]
before_by_path = {row['path']: row for row in before}
if any(before_by_path.get(path) != row for path, row in approved.items()):
    raise RuntimeError('Validated source changed before initial binding')
command = [str(python), '-I', '-B', str(root / 'run-stage8-v1.py'),
    '/Users/jmb/repos/dta-parser', 'f3b8b984c6a9ea5a0f062eee70e392bb567e5042',
    '/private/tmp/dta-direct-stage8-validation/candidate-8ffa5ac5-01',
    '8ffa5ac5f29b08e01d55c6b54288ee8679634f34', str(output),
    '--receipt-sha256', '9798c6218c36c00fb17c1af218e04d68f6f37a3bbddac499277d74f66ad05314',
    '--script', '/private/tmp/dta-direct-stage8-retention-preparation-01/installed-retention-writes-draft-v1.R',
    '--routes', 'public', '--mode', 'schemas', '--rows', '16', '--iterations', '3']
record = dict(command=command, cwd=str(root), PATH=os.environ.get('PATH'),
    launcher_python_argv=sys.orig_argv, selected_before=before,
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Twenty-four fresh public installed write witnesses after500calls; exactsource/first/latest lifetimes and duplicatecoupling. No heap/timing/RSS/performance acceptance or completecallrimageclosure.',
    returncode=None, error=None)
if output.exists():
    raise RuntimeError('Run output already exists')
save(root / 'launch-retention-writes-8ffa5ac5-01.json', record)
try:
    if [identity(path) for path in selected] != before:
        raise RuntimeError('Selected endpoints changed before invocation')
    with (root / 'launch-retention-writes-8ffa5ac5-01.log').open('x') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    record['returncode'] = result.returncode
except BaseException as error:
    record['error'] = dict(type=type(error).__name__, message=str(error))
    raise
finally:
    record['selected_after'] = None
    record['selected_inventory_error'] = None
    record['selected_unchanged'] = False
    try:
        record['selected_after'] = [identity(path) for path in selected]
        record['selected_unchanged'] = before == record['selected_after']
    except BaseException as inventory_error:
        record['selected_inventory_error'] = dict(
            type=type(inventory_error).__name__, message=str(inventory_error))
    record['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(root / 'launch-retention-writes-8ffa5ac5-01-exit.json', record)
if not record['selected_unchanged']:
    raise RuntimeError('Selected endpoints changed during invocation')
sys.exit(record['returncode'])
