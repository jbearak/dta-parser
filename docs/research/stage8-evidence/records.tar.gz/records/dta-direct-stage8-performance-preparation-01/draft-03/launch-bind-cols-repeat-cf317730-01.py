"""Sixty public candidate cases in a coordinated quiet window."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/private/tmp/dta-direct-stage8-performance-preparation-01/draft-03')
output = Path('/private/tmp/dta-direct-stage8-validation/root-bind-cols-repeat-cf317730-01')
python = Path('/opt/homebrew/Cellar/python@3.14/3.14.7/bin/python3.14')
freeze_path = root / 'bind-cols-repeat-freeze-01.json'
freeze_sha = '8acc8e4808a6a5bb26bb0e778d4ff91199a4130f8999e0412f994508b496f5d1'

def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
        bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

freeze_identity = identity(freeze_path)
if freeze_identity['sha256'] != freeze_sha:
    raise RuntimeError('Prepared source freeze changed')
freeze = json.loads(freeze_path.read_text())
if identity(freeze_path) != freeze_identity:
    raise RuntimeError('Source freeze changed while reading')
approved = {str(freeze_path): freeze_identity}
for row in freeze['files']:
    if identity(Path(row['path'])) != row:
        raise RuntimeError('Prepared source changed: ' + row['path'])
    approved[row['path']] = row
selected = [python, python.resolve(strict=True), Path(sys.executable),
    Path(__file__).resolve(), freeze_path,
    Path('/opt/homebrew/bin/git'), Path('/opt/homebrew/bin/git').resolve(strict=True),
    Path('/opt/homebrew/Cellar/r/4.6.1/bin/Rscript')]
selected.extend(Path(row['path']) for row in freeze['files'])
before = [identity(path) for path in selected]
before_by_path = {row['path']: row for row in before}
if any(before_by_path.get(path) != row for path, row in approved.items()):
    raise RuntimeError('Validated source changed before initial binding')
command = [str(python), '-I', '-B', str(root / 'run-stage8-v1.py'),
    '/Users/jmb/repos/dta-parser', 'f3b8b984c6a9ea5a0f062eee70e392bb567e5042',
    '/private/tmp/dta-direct-stage8-validation/candidate-cf317730-01',
    'cf317730d3110568c72862719424e01c2876141b', str(output),
    '--receipt-sha256', 'fd19cba85a531184d8d812a4a7ff556554917d380741b4ff191eb86972fad4b4',
    '--script', str(root / 'operations-bind-cols-repeat-v1.R'), '--routes', 'public',
    '--mode', 'measure', '--schemas', '/private/tmp/dta-direct-stage8-validation/root-performance-schemas-01/results/schemas.R',
    '--schemas-sha256', '56b4690a4b89332dbb4cdf49de822a22960292f0cd653baf77124e7004a4b8dc', '--rows', '100000,1000000', '--iterations', '7']
record = dict(command=command, cwd=str(root), PATH=os.environ.get('PATH'),
    launcher_python_argv=sys.orig_argv, selected_before=before,
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Restricted four-shape candidate bind_cols repeat during coordinated quiet; seven GC-inclusive times, separate R/native allocation observations; full OS/runtime closure and overall acceptance remain separate',
    returncode=None, error=None)
if output.exists():
    raise RuntimeError('Run output already exists')
save(root / 'launch-bind-cols-repeat-cf317730-01.json', record)
try:
    if [identity(path) for path in selected] != before:
        raise RuntimeError('Selected endpoints changed before invocation')
    with (root / 'launch-bind-cols-repeat-cf317730-01.log').open('x') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    record['returncode'] = result.returncode
except BaseException as error:
    record['error'] = dict(type=type(error).__name__, message=str(error))
    raise
finally:
    record['selected_after'] = None
    record['selected_inventory_error'] = None
    record['selected_unchanged'] = False
    try:
        record['selected_after'] = [identity(path) for path in selected]
        record['selected_unchanged'] = before == record['selected_after']
    except BaseException as inventory_error:
        record['selected_inventory_error'] = dict(
            type=type(inventory_error).__name__, message=str(inventory_error))
    record['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(root / 'launch-bind-cols-repeat-cf317730-01-exit.json', record)
if not record['selected_unchanged']:
    raise RuntimeError('Selected endpoints changed during invocation')
sys.exit(record['returncode'])
