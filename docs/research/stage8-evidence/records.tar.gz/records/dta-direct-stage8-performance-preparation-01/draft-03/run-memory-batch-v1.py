"""Launch the reviewed Stage8 memory wrapper sequentially with selected source records."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def identity(path):
    path = Path(path)
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
                bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_sha')
    parser.add_argument('installation', type=Path)
    parser.add_argument('receipt_sha')
    parser.add_argument('output', type=Path)
    parser.add_argument('--predecessor', action='store_true')
    parser.add_argument('--source-freeze-sha256', required=True)
    args = parser.parse_args()
    p = Path(__file__).resolve().parent
    python = '/opt/homebrew/Cellar/python@3.14/3.14.7/bin/python3.14'
    if args.predecessor and args.source_sha != 'af0bed0b9c200f82d37891902266d200a1819196':
        raise RuntimeError('Fixed reference requires exact predecessor')
    routes = ['public', 'predecessor_safe_reference'] if args.predecessor else ['public']
    freeze_path = p / 'memory-source-freeze-01.json'
    freeze_identity = identity(freeze_path)
    if freeze_identity['sha256'] != args.source_freeze_sha256:
        raise RuntimeError('Prepared memory source freeze differs')
    freeze = json.loads(freeze_path.read_text())
    if identity(freeze_path) != freeze_identity:
        raise RuntimeError('Memory source freeze changed while reading')
    approved = {str(freeze_path): freeze_identity}
    for row in freeze['files']:
        if identity(row['path']) != row:
            raise RuntimeError('Prepared memory source changed: ' + row['path'])
        approved[row['path']] = row
    paths = [Path(__file__).resolve(), python, sys.executable, freeze_path,
             *[row['path'] for row in freeze['files']],
             '/opt/homebrew/bin/git', '/opt/homebrew/Cellar/r/4.6.1/bin/Rscript',
             '/usr/bin/time', args.installation / 'completed-receipt.json']
    selected = [identity(path) for path in paths]
    selected_by_path = {row['path']: row for row in selected}
    if any(selected_by_path.get(path) != row for path, row in approved.items()):
        raise RuntimeError('Approved memory inputs changed before initial binding')
    args.output.mkdir(parents=True, exist_ok=False)
    commands = []
    for workload in ['full_padded', 'base_cbind', 'bind_rows_wide', 'nest_double']:
        sizes = [1024, 4096] if workload == 'nest_double' else [100000, 1000000]
        for index, rows in enumerate(sizes):
            for route in (routes if index == 0 else list(reversed(routes))):
                commands.append([python, '-I', '-B', str(p / 'run-memory-v1.py'),
                    '/Users/jmb/repos/dta-parser', 'f3b8b984c6a9ea5a0f062eee70e392bb567e5042',
                    str(args.installation), args.source_sha,
                    str(args.output / (str(rows) + '-' + workload + '-' + route)),
                    '--receipt-sha256', args.receipt_sha, '--rows', str(rows),
                    '--script', str(p / 'memory-v1.R'), '--routes', route, '--workload', workload,
                    '--mode', 'smoke', '--schemas',
                    '/private/tmp/dta-direct-stage8-validation/root-performance-schemas-01/results/schemas.R',
                    '--schemas-sha256', '56b4690a4b89332dbb4cdf49de822a22960292f0cd653baf77124e7004a4b8dc'])
    write(args.output / 'launch.json', dict(commands=commands, selected=selected,
        python_invocation=sys.orig_argv, PATH=os.environ.get('PATH'), started_utc=now(),
        scope='Sequential quiet-window memory cases; each reviewed wrapper binds its own accepted installation and runtime. '
              'This outer record binds selected launch sources/endpoints, not complete Python or child image closure. '
              'Predecessor public memory is read-only; fifty-call numeric/label isolation is separately qualified only for the fixed reference.'))
    records, error = [], None
    try:
        for index, command in enumerate(commands):
            if [identity(path) for path in paths] != selected:
                raise RuntimeError('Selected batch inputs changed')
            record = dict(command=command, started_utc=now(), returncode=None, error=None)
            write(args.output / (str(index) + '-before.json'), record)
            try:
                record['returncode'] = subprocess.run(command).returncode
            except BaseException as failure:
                record['error'] = dict(type=type(failure).__name__, message=str(failure))
                raise
            finally:
                record['completed_utc'] = now()
                records.append(record)
                write(args.output / (str(index) + '-result.json'), record)
            if record['returncode']:
                raise RuntimeError('Memory case failed; partial products retained')
            print('Completed memory case', index + 1, 'of', len(commands), flush=True)
    except BaseException as failure:
        error = dict(type=type(failure).__name__, message=str(failure))
        raise
    finally:
        final_identity_error = None
        try:
            unchanged = [identity(path) for path in paths] == selected
        except BaseException as failure:
            unchanged = False
            final_identity_error = dict(type=type(failure).__name__, message=str(failure))
        write(args.output / 'result.json', dict(records=records, error=error,
            final_identity_error=final_identity_error,
            inputs_unchanged=unchanged, finished_utc=now(),
            status='complete' if error is None and unchanged and len(records) == len(commands) else 'failed'))
    if not unchanged:
        raise RuntimeError('Selected batch inputs changed')


if __name__ == '__main__':
    main()
