"""Selected first-invocation guard for the Stage8 predecessor memory batch."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/private/tmp/dta-direct-stage8-performance-preparation-01/draft-03')
output = Path('/private/tmp/dta-direct-stage8-validation/root-memory-predecessor-01')
python = Path('/opt/homebrew/Cellar/python@3.14/3.14.7/bin/python3.14')
freeze_path = root / 'memory-source-freeze-01.json'
freeze_sha = 'f16db943b996e649a655af6686bb71bce660cd2a8cfdaeb7957cf48911db6714'

def identity(path):
    return dict(path=str(path), resolved=str(path.resolve(strict=True)),
        bytes=path.stat().st_size, mode=oct(path.stat().st_mode & 0o777),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

freeze_identity = identity(freeze_path)
if freeze_identity['sha256'] != freeze_sha:
    raise RuntimeError('Prepared source freeze changed')
freeze = json.loads(freeze_path.read_text())
if identity(freeze_path) != freeze_identity:
    raise RuntimeError('Source freeze changed while reading')
approved = {str(freeze_path): freeze_identity}
for row in freeze['files']:
    if identity(Path(row['path'])) != row:
        raise RuntimeError('Prepared source changed: ' + row['path'])
    approved[row['path']] = row
selected = [python, python.resolve(strict=True), Path(sys.executable),
    Path(__file__).resolve(), freeze_path,
    Path('/opt/homebrew/bin/git'), Path('/opt/homebrew/bin/git').resolve(strict=True),
    Path('/opt/homebrew/Cellar/r/4.6.1/bin/Rscript'), Path('/usr/bin/time')]
selected.extend(Path(row['path']) for row in freeze['files'])
before = [identity(path) for path in selected]
before_by_path = {row['path']: row for row in before}
if any(before_by_path.get(path) != row for path, row in approved.items()):
    raise RuntimeError('Validated source changed before initial binding')
command = [str(python), '-I', '-B', str(root / 'run-memory-batch-v1.py'),
    'af0bed0b9c200f82d37891902266d200a1819196',
    '/private/tmp/dta-direct-stage8-validation/predecessor-af0bed0b-01',
    '05494bd135b50c3b95827409727f5d2626e407cbe289528c4fb11b58ffdf9f72',
    str(output), '--predecessor', '--source-freeze-sha256', freeze_sha]
record = dict(command=command, cwd=str(root), PATH=os.environ.get('PATH'),
    launcher_python_argv=sys.orig_argv, selected_before=before,
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Sixteen sequential whole-child RSS/retained-heap cases during coordinated agent quiet window. MacOS time runs outside sandbox for its required sysctl. No one-operation peak, exclusiveOSCPU or full processimageclosure.',
    returncode=None, error=None)
if output.exists():
    raise RuntimeError('Run output already exists')
save(root / 'launch-memory-predecessor-01.json', record)
try:
    if [identity(path) for path in selected] != before:
        raise RuntimeError('Selected endpoints changed before invocation')
    with (root / 'launch-memory-predecessor-01.log').open('x') as log:
        result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
    record['returncode'] = result.returncode
except BaseException as error:
    record['error'] = dict(type=type(error).__name__, message=str(error))
    raise
finally:
    record['selected_after'] = None
    record['selected_inventory_error'] = None
    record['selected_unchanged'] = False
    try:
        record['selected_after'] = [identity(path) for path in selected]
        record['selected_unchanged'] = before == record['selected_after']
    except BaseException as inventory_error:
        record['selected_inventory_error'] = dict(
            type=type(inventory_error).__name__, message=str(inventory_error))
    record['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(root / 'launch-memory-predecessor-01-exit.json', record)
if not record['selected_unchanged']:
    raise RuntimeError('Selected endpoints changed during invocation')
sys.exit(record['returncode'])
