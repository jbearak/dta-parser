args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
iterations <- as.integer(args[[4L]])
row_counts <- as.integer(strsplit(args[[5L]], ",", fixed = TRUE)[[1L]])
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
for (name in c("workloads-v1.R", "reference-v1.R", "validation-v1.R"))
    source(file.path(support, name))
routes <- strsplit(Sys.getenv("DTA_STAGE8_ROUTES"), ",", fixed = TRUE)[[1L]]
mode <- Sys.getenv("DTA_STAGE8_MODE")
stopifnot(mode %in% c("schemas", "smoke", "measure"),
    identical(routes, "public") || identical(routes, c("public", "predecessor_safe_reference")),
    iterations >= 3L, length(row_counts) > 0L, !anyNA(row_counts),
    all(row_counts >= 8L & row_counts %% 4L == 0L), capabilities("profmem"))
suppressPackageStartupMessages(library(bench))
if ("predecessor_safe_reference" %in% routes) s8_reference_start(library_path)
schemas <- if (mode == "schemas") list() else dget(Sys.getenv("DTA_STAGE8_SCHEMAS"))
writeLines(c(atomic_identity(args[[3L]], library_path, "candidate"),
    paste("mode", mode),
    "Fixture construction, expectations, schema/value/source validation and native observers are outside measured calls.",
    "Rolling join_by construction is inside the whole call; reconstruction input preparation is outside.",
    "First-input-call Rprofmem precedes source payload validation and is not a cold process.",
    "Warmed and timed calls follow validation that can expose source backing. State transitions are recorded.",
    "Time samples include GC. Rprofmem and native counters overlap and must not be summed.",
    "Native observers cover all flat columns and only first/last nested children plus any prototype; all child values/schemas are checked separately.",
    "Fixed safe reference is restricted to af0bed predecessor; its isolation qualification is a separate prerequisite.",
    "Schema mode is functional preparation only. Its calls and all smoke timings are excluded from performance acceptance."),
    file.path(output, "session.txt"))

s8_profile <- function(operation, stem) {
    path <- file.path(output, paste0(stem, "-Rprofmem.log"))
    stopifnot(!file.exists(path))
    on.exit(Rprofmem(NULL), add = TRUE)
    before <- c(owned_stats(), atomic_scans())
    Rprofmem(path)
    value <- operation()
    Rprofmem(NULL)
    delta <- c(owned_stats(), atomic_scans()) - before
    lines <- readLines(path, warn = FALSE)
    events <- grepl("^[0-9]+ :", lines)
    stopifnot(all(events | grepl("^new page:", lines)))
    sizes <- as.numeric(sub(" .*", "", lines[events]))
    list(value = value, metrics = c(r_allocated_bytes = sum(sizes),
        r_largest_allocation_bytes = max(c(0, sizes)), delta))
}

s8_states <- function(value, path) {
    records <- list()
    visit <- function(frame, path) {
        for (i in seq_along(frame)) {
            column <- .subset2(frame, i)
            here <- paste(path, names(frame)[[i]], sep = "/")
            if (typeof(column) == "list") {
                # Bound observer work independently of nested output count.
                # All children still receive value/schema checks separately.
                selected <- if (length(column)) unique(c(1L, length(column))) else integer()
                for (j in selected) if (is.data.frame(.subset2(column, j)))
                    visit(.subset2(column, j), paste0(here, "[", j, "]"))
                prototype <- attr(column, "ptype", exact = TRUE)
                if (is.data.frame(prototype)) visit(prototype, paste0(here, "/ptype"))
            } else {
                info <- owned_native("C_dtatools_mutation_info", frame, as.integer(i))
                owned <- owned_native("C_dtatools_owned_info", column)
                if (!is.null(owned)) stopifnot(owned$depth == 1L)
                records[[length(records) + 1L]] <<- cbind(data.frame(path = here,
                    type = typeof(column), length = length(column), owned = !is.null(owned)),
                    as.data.frame(info))
            }
        }
    }
    visit(value, path)
    do.call(rbind, records)
}

records <- list()
run_case <- function(rows, width, workload, route) {
    input <- s8_fixture(rows, width, workload)
    key <- paste(width, workload, sep = "-")
    stem <- paste(rows, width, workload, route, sep = "-")
    invoke <- function() s8_invoke(input, route)
    if (mode == "schemas") {
        value <- invoke()
        s8_check_source(input)
        s8_check_result(value, input)
        observed <- list(x = s8_schema(input$x), y = s8_schema(input$y),
                         result = s8_schema(value))
        if (!is.null(schemas[[key]])) s8_assert(identical(schemas[[key]], observed),
            paste("schema differs by route or shape", key, route))
        schemas[[key]] <<- observed
        dput(schemas, file.path(output, "schemas.R"))
        records[[length(records) + 1L]] <<- data.frame(rows, width, workload, route,
            result_rows = nrow(value), result_columns = ncol(value), checked = TRUE)
        write.csv(do.call(rbind, records), file.path(output, "schema-calls.csv"), row.names = FALSE)
        return(invisible(NULL))
    }
    expected <- schemas[[key]]
    stopifnot(!is.null(expected))
    # Schema inspection does not coerce atomic payloads. It precedes the first
    # profile; complete payload inspection follows that first operation.
    s8_assert(identical(s8_schema(input$x), expected$x), "initial x schema")
    s8_assert(identical(s8_schema(input$y), expected$y), "initial y schema")
    states <- list()
    initial <- rbind(s8_states(input$x, "x"), s8_states(input$y, "y"))
    record_state <- function(step, value = NULL) {
        current <- rbind(s8_states(input$x, "x"), s8_states(input$y, "y"))
        s8_assert(identical(current$handle, initial$handle), "source handles changed")
        if (!is.null(value)) current <- rbind(current, s8_states(value, "result"))
        states[[length(states) + 1L]] <<- cbind(data.frame(step), current)
        write.csv(do.call(rbind, states), file.path(output, paste0(stem, "-states.csv")), row.names = FALSE)
    }
    check <- function(value) {
        s8_check_result(value, input, expected$result)
        s8_check_source(input, expected)
    }
    record_state("initial")
    first <- s8_profile(invoke, paste0(stem, "-first-input-call"))
    record_state("after_first_operation", first$value)
    check(first$value)
    record_state("after_first_validation", first$value)
    first_metrics <- first$metrics
    rm(first)
    invisible(gc())
    warm <- s8_profile(invoke, paste0(stem, "-warmed-call"))
    record_state("after_warmed_operation", warm$value)
    check(warm$value)
    record_state("after_warmed_validation", warm$value)
    warm_metrics <- warm$metrics
    rm(warm)
    invisible(gc())
    record_state("before_timing")
    mark <- bench::mark(invoke(), iterations = iterations, check = TRUE, filter_gc = FALSE)
    record_state("after_timing", mark$result[[1L]])
    check(mark$result[[1L]])
    record_state("after_final_validation", mark$result[[1L]])
    times <- as.numeric(mark$time[[1L]])
    gc_events <- as.data.frame(mark$gc[[1L]])
    stopifnot(length(times) == iterations, mark$n_itr == iterations, nrow(gc_events) == iterations)
    write.csv(cbind(data.frame(iteration = seq_along(times), seconds = times), gc_events),
        file.path(output, paste0(stem, "-times.csv")), row.names = FALSE)
    metrics <- c(stats::setNames(first_metrics, paste0("first_", names(first_metrics))),
        stats::setNames(warm_metrics, paste0("warm_", names(warm_metrics))))
    row <- cbind(data.frame(rows, width, workload, route,
        result_rows = nrow(mark$result[[1L]]), result_columns = ncol(mark$result[[1L]]),
        median_ms = as.numeric(mark$median) * 1000, iterations = mark$n_itr,
        gc_count = mark$n_gc, bench_allocated_bytes = as.numeric(mark$mem_alloc),
        values_metadata_groups_source = TRUE), as.data.frame(as.list(metrics)))
    records[[length(records) + 1L]] <<- row
    write.csv(do.call(rbind, records), file.path(output, "operations.csv"), row.names = FALSE)
    print(row[c("rows", "width", "workload", "route", "median_ms",
        "first_r_allocated_bytes", "warm_r_allocated_bytes")])
    invisible(NULL)
}

shapes <- s8_shapes(row_counts, mode)
# Restricted paired repeat: keep the exact four original bind_cols shapes.
stopifnot(mode == "measure", identical(row_counts, c(100000L, 1000000L)))
shapes <- shapes[shapes$workload == "bind_cols", , drop = FALSE]
stopifnot(nrow(shapes) == 4L)
for (i in seq_len(nrow(shapes))) {
    shape <- shapes[i, ]
    selected_routes <- if (i %% 2L) routes else rev(routes)
    for (route in selected_routes) {
        run_case(shape$rows, shape$width, shape$workload, route)
        invisible(gc())
    }
}
stopifnot(length(records) == nrow(shapes) * length(routes))
validate_benchmark_install(library_path, args[[3L]])
cat("All selected Stage8 calls passed independent values, row order, metadata schemas and source checks.\n")
