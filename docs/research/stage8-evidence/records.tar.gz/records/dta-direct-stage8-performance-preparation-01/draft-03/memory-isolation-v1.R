# Disposable numeric payload/metadata write witnesses for fixed workloads.
args <- commandArgs(TRUE)
stopifnot(length(args) == 5L)
source("benchmarks/r-dibble-dplyr/owned-atomic-helpers.R")
library_path <- atomic_start(args[[1L]], args[[3L]], "candidate")
output <- normalizePath(args[[2L]], mustWork = TRUE)
source_sha <- args[[3L]]
support <- Sys.getenv("DTA_STAGE8_SUPPORT")
schemas_path <- Sys.getenv("DTA_STAGE8_SCHEMAS")
route <- if (identical(source_sha, "af0bed0b9c200f82d37891902266d200a1819196"))
    "predecessor_safe_reference" else "public"
stopifnot(route %in% strsplit(Sys.getenv("DTA_STAGE8_ROUTES"), ",", fixed = TRUE)[[1L]])
suppressPackageStartupMessages(library(bench))

isolation_worker <- function(library_path, source_sha, support, schemas_path, route,
                             workload, side, direction, write_kind, output) {
    .libPaths(c(library_path, "/opt/homebrew/lib/R/4.6/site-library", .Library))
    record_runtime <- function() {
        ns <- sort(loadedNamespaces())
        write.table(data.frame(name = ns, path = vapply(ns, function(name)
            if (name == "base") file.path(.Library, "base") else
                getNamespaceInfo(asNamespace(name), "path"), character(1))),
            file.path(output, "namespaces.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
        dlls <- getLoadedDLLs()
        write.table(data.frame(name = names(dlls), path = vapply(dlls,
            function(dll) dll[["path"]], character(1))), file.path(output, "dlls.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
        writeLines(capture.output(sessionInfo()), file.path(output, "runtime.txt"))
    }
    tryCatch({
        library(dtatools, lib.loc = library_path)
        namespace_path <- getNamespaceInfo(asNamespace("dtatools"), "path")
        stopifnot(identical(normalizePath(namespace_path),
            normalizePath(file.path(library_path, "dtatools"))))
        provenance <- readRDS(file.path(namespace_path, "Meta", "benchmark-provenance.rds"))
        stopifnot(identical(provenance$source_sha, source_sha))
        for (name in c("workloads-v1.R", "reference-v1.R", "validation-v1.R"))
            source(file.path(support, name))
        schemas <- dget(schemas_path)
        if (route == "predecessor_safe_reference") s8_reference_start(library_path)
        semantic <- function(value) {
            fields <- attributes(value)
            fields$.dtatools_ref_state <- NULL
            fields$.internal.selfref <- NULL
            fields <- fields[sort(names(fields))]
            list(type = typeof(value), fields = lapply(fields, semantic),
                values = if (typeof(value) == "list") lapply(seq_along(value), function(i)
                    semantic(.subset2(value, i))) else {
                    result <- switch(typeof(value), logical = as.integer(value),
                        integer = as.integer(value), double = as.double(value),
                        character = as.character(value), stop("Unexpected witness type"))
                    attributes(result) <- NULL
                    result
                })
        }
        input <- s8_fixture(16L, 8L, workload)
        first <- s8_invoke(input, route)
        latest <- first
        for (i in 2:50) latest <- s8_invoke(input, route)
        schema <- schemas[[paste(8L, workload, sep = "-")]]
        s8_check_source(input, schema)
        s8_check_result(first, input, schema$result)
        s8_check_result(latest, input, schema$result)
        before <- list(x = semantic(input$x), y = semantic(input$y),
                       first = semantic(first), latest = semantic(latest))
        nested <- direction == "result" && side == "y" && workload == "nest_double"
        target <- if (direction == "source") input[[side]] else
            if (nested) latest$nested[[1L]] else latest
        column_name <- if (side == "x") "c01" else paste0(input$y_prefix, "01")
        row <- 1L
        if (direction == "source" && side == "x" && workload == "semi_half") row <- 2L
        if (direction == "result" && side == "y") {
            if (workload %in% c("base_rbind", "bind_rows_wide")) row <- 17L
            if (workload == "full_padded") row <- 9L
            if (workload == "rows_update") row <- 4L
        }
        column <- match(column_name, names(target))
        stopifnot(!is.na(column), length(.subset2(target, column)) > 1L)
        expected_target <- semantic(target)
        prior <- expected_target$values[[column]]$values[[row]]
        stopifnot(is.finite(prior))
        before_primitives <- c(as.integer(TRUE), as.integer(FALSE))
        writeLines(as.character(before_primitives), file.path(output, "primitives-before.txt"))
        if (write_kind == "payload") {
            changed <- prior + .125
            expected_target$values[[column]]$values[[row]] <- changed
        } else {
            expected_target$values[[column]]$fields$label <- semantic("Changed after fifty calls")
        }
        expected <- before
        if (direction == "source") expected[[side]] <- expected_target else if (nested) {
            slot <- match("nested", names(latest))
            expected$latest$values[[slot]]$values[[1L]] <- expected_target
        } else expected$latest <- expected_target
        observation <- list(workload = workload, side = side, direction = direction,
            write_kind = write_kind, row = row, column = column_name, nested = nested,
            before = before, expected = expected)
        # Retain prepared semantic states before any foreign setter can fail.
        saveRDS(observation, file.path(output, "prepared-observations.rds"), compress = FALSE)
        if (write_kind == "payload") {
            data.table::set(target, i = row, j = column_name, value = changed)
        } else {
            data.table::setattr(.subset2(target, column), "label", "Changed after fifty calls")
        }
        after_primitives <- c(as.integer(TRUE), as.integer(FALSE))
        writeLines(as.character(c(before_primitives, after_primitives)), file.path(output, "primitives.txt"))
        after <- list(x = semantic(input$x), y = semantic(input$y),
                      first = semantic(first), latest = semantic(latest))
        observation$after <- after
        saveRDS(observation, file.path(output, "observations.rds"), compress = FALSE)
        stopifnot(identical(before_primitives, c(1L, 0L)), identical(after_primitives, c(1L, 0L)))
        if (!identical(after, expected)) {
            writeLines(capture.output(dput(all.equal(after, expected))), file.path(output, "difference.txt"))
            stop("Source/first/latest protection or intended target change differs")
        }
        result <- list(passed = TRUE, source_sha = source_sha, namespace_path = namespace_path,
            calls = 50L, rows = 16L, width = 8L, target_column = column_name, target_row = row,
            nested = nested, primitives = after_primitives,
            scope = "Fixed-workload numeric payload/label writes, all tiny x/y/first/latest semantic records checked; no timing or whole native/child-image closure")
        dput(result, file.path(output, "result.R"))
        result
    }, finally = tryCatch(record_runtime(), error = function(error) {
        writeLines(conditionMessage(error), file.path(output, "runtime-recording-error.txt"))
    }))
}

source(file.path(support, "workloads-v1.R"))
cases <- list()
for (workload in c("full_padded", "base_cbind", "bind_rows_wide", "nest_double")) {
    sides <- if (workload %in% c("semi_half", "anti_half", "reconstruct")) "x" else c("x", "y")
    for (side in sides) for (direction in c("source", "result"))
        for (write_kind in c("payload", "metadata")) cases[[length(cases) + 1L]] <-
            data.frame(workload, side, direction, write_kind)
}
cases <- do.call(rbind, cases)
stopifnot(nrow(cases) == 32L)
records <- list()
for (i in seq_len(nrow(cases))) {
    case <- cases[i, ]
    name <- paste(case$workload, case$side, case$direction, case$write_kind, sep = "-")
    destination <- file.path(output, name)
    stopifnot(dir.create(destination))
    result <- tryCatch(callr::r(isolation_worker, args = list(library_path, source_sha,
        support, schemas_path, route, case$workload, case$side, case$direction,
        case$write_kind, destination), libpath = .libPaths(),
        stdout = file.path(destination, "stdout.log"), stderr = file.path(destination, "stderr.log"),
        timeout = 60), error = function(error) list(passed = FALSE,
            error_classes = class(error), error_message = conditionMessage(error)))
    dput(result, file.path(destination, "parent-result.R"))
    passed <- isTRUE(result$passed) && !file.exists(file.path(destination, "runtime-recording-error.txt"))
    records[[length(records) + 1L]] <- cbind(case, data.frame(route, planned_calls = 50L, passed = passed))
    write.csv(do.call(rbind, records), file.path(output, "isolation-cases.csv"), row.names = FALSE)
    if (!passed) stop(paste("Retained isolated case failure:", name))
}
stopifnot(length(records) == 32L)
validate_benchmark_install(library_path, source_sha)
cat("PASS32 fifty-call disposable fixed-workload numeric payload/metadata write cases, with source/first/latest protection.\n")
