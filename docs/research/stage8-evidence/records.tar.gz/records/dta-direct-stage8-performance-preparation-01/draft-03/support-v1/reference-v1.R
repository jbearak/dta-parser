# Benchmark-only control. Uses the qualified predecessor publication boundary
# after ordinary dplyr/base orchestration. No namespace modification.
# Adapted from dtatools af0bed0b9c200f82d37891902266d200a1819196
# R/mutate-data.R .closed_reference_verb, rbind/cbind methods and .close_dibble;
# R/dibble-rows.R .reconstruct_dibble for the fixed grouped-left control.
# The fixed workloads and write witnesses must qualify this control before timing.
s8_reference_start <- function(library_path) {
    selected <- getNamespaceInfo(asNamespace("dtatools"), "path")
    stopifnot(identical(normalizePath(selected),
        normalizePath(file.path(library_path, "dtatools"))))
    provenance <- readRDS(file.path(selected, "Meta", "benchmark-provenance.rds"))
    stopifnot(identical(provenance$source_sha,
        "af0bed0b9c200f82d37891902266d200a1819196"))
    invisible(provenance)
}

s8_reference <- function(input) {
    x <- dtatools:::.reference_snapshot(input$x)
    grouped_left <- input$workload == "grouped_left"
    if (grouped_left) {
        attr(x, "groups") <- NULL
        class(x) <- setdiff(class(x), "grouped_df")
    }
    # nest_join slices its right input into children. Retain the right dibble
    # template so those children keep the public predecessor container.
    y <- if (input$workload == "nest_double") input$y else
        dtatools:::.reference_snapshot(input$y)
    result <- s8_call(x, y, input$prepared, input$workload)
    # Matching does not need the grouping shell. Rebuild once using the
    # predecessor template metadata/grouping policy, including dataset label.
    if (grouped_left) return(dtatools:::.reconstruct_dibble(result, input$x))
    dtatools:::.close_dibble(input$x, result, "Stage8 benchmark delegation control")
}
