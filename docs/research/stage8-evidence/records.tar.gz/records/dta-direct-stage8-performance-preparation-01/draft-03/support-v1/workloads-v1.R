# Stage8 benchmark inputs. All fixture creation is outside measured calls.
s8_main <- c("left_unique", "inner_double", "full_padded", "left_rolling",
    "semi_half", "anti_half", "base_rbind", "base_cbind", "bind_rows_wide",
    "bind_cols", "rows_update", "reconstruct")
s8_extra <- c("grouped_left", "cross_four", "nest_double")

s8_payload <- function(index, column, side, wide = FALSE) {
    value <- switch((column - 1L) %% 8L + 1L,
        dtatools::dta_double(as.double(index %% 101L) + side * 1000 + .25),
        rep(c(TRUE, FALSE, TRUE, FALSE), length.out = length(index)),
        factor(c("b", "a", "b", "c")[(index - 1L) %% 4L + 1L],
               levels = c("a", "b", "c", "unused")),
        ordered(c("b", "a", "b", "c")[(index - 1L) %% 4L + 1L],
                levels = c("a", "b", "c", "unused")),
        structure((if (wide) c("right-hand-wide-string", "", "é", "other-wide-value")
                   else c("alpha", "beta", "", "é"))[(index - 1L) %% 4L + 1L],
                  class = c("dta_string", "vctrs_vctr", "character"),
                  stata.string.storage = if (wide) "str40" else "str12"),
        structure(c("one", "two", "", "é")[(index - 1L) %% 4L + 1L],
                  stata.string.storage = "str12"),
        as.integer(index %% 67L + side * 100L),
        dtatools::dta_double(as.double(index %% 31L) - .5 + side * 1000))
    # Logical values also depend on the supplied row indices for sparse updates.
    if ((column - 1L) %% 8L + 1L == 2L)
        value <- c(TRUE, FALSE, TRUE, FALSE)[(index - 1L) %% 4L + 1L]
    attr(value, "label") <- paste("Payload", column)
    value
}

s8_frame <- function(index, width, side, keys = index, prefix = "c",
                     grouped = FALSE, wide = FALSE, omit = integer()) {
    selected <- setdiff(seq_len(width), omit)
    columns <- lapply(selected, function(i) s8_payload(index, i, side, wide))
    names(columns) <- sprintf(paste0(prefix, "%02d"), selected)
    if (!is.null(keys)) columns <- c(list(key = dtatools::dta_long(keys)), columns)
    if (grouped) columns <- c(list(g = sprintf("g%03d", (index - 1L) %% 128L + 1L)), columns)
    value <- dtatools::as_dibble(tibble::new_tibble(columns, nrow = length(index)))
    attr(value, "label") <- paste("Stage 8 input", side)
    if (grouped) value <- dplyr::group_by(value, g)
    value
}

s8_fixture <- function(rows, width, workload) {
    stopifnot(rows >= 8L, rows %% 4L == 0L, width %in% c(8L, 16L),
              workload %in% c(s8_main, s8_extra))
    x_index <- seq_len(rows)
    y_index <- seq_len(rows)
    y_keys <- rev(x_index)
    y_prefix <- "r"
    x_omit <- y_omit <- integer()
    y_wide <- FALSE
    if (workload %in% c("inner_double", "nest_double")) {
        y_index <- seq_len(2L * rows)
        y_keys <- rep(rev(x_index), each = 2L)
    } else if (workload == "full_padded") {
        y_keys <- rev(x_index + rows %/% 2L)
    } else if (workload == "left_rolling") {
        y_index <- seq.int(1L, rows, by = 4L)
        y_keys <- y_index
    } else if (workload %in% c("semi_half", "anti_half")) {
        y_index <- seq.int(2L, rows, by = 2L)
        y_keys <- y_index
    } else if (workload == "rows_update") {
        y_index <- seq.int(4L, rows, by = 4L)
        y_keys <- y_index
        y_prefix <- "c"
    } else if (workload %in% c("base_rbind", "bind_rows_wide")) {
        y_prefix <- "c"
        if (workload == "bind_rows_wide") {
            x_omit <- width
            y_omit <- width - 1L
            y_wide <- TRUE
        }
    } else if (workload %in% c("base_cbind", "bind_cols", "cross_four")) {
        if (workload == "cross_four") y_index <- seq_len(4L)
        y_keys <- NULL
    }
    x <- s8_frame(x_index, width, 1L, grouped = workload == "grouped_left", omit = x_omit)
    y <- s8_frame(y_index, width, 2L, keys = y_keys, prefix = y_prefix,
                  wide = y_wide, omit = y_omit)
    prepared <- if (workload == "reconstruct") dtatools:::.reference_snapshot(x) else NULL
    list(x = x, y = y, prepared = prepared, rows = rows, width = width,
         workload = workload, x_index = x_index, y_index = y_index,
         y_keys = y_keys, y_prefix = y_prefix, x_omit = x_omit,
         y_omit = y_omit, y_wide = y_wide)
}

s8_call <- function(x, y, prepared, workload) {
    switch(workload,
        left_unique = dplyr::left_join(x, y, by = "key"),
        inner_double = dplyr::inner_join(x, y, by = "key", relationship = "many-to-many"),
        full_padded = dplyr::full_join(x, y, by = "key"),
        left_rolling = dplyr::left_join(x, y, by = dplyr::join_by(closest(key >= key))),
        semi_half = dplyr::semi_join(x, y, by = "key"),
        anti_half = dplyr::anti_join(x, y, by = "key"),
        base_rbind = base::rbind(x, y),
        base_cbind = base::cbind(x, y),
        bind_rows_wide = dplyr::bind_rows(x, y),
        bind_cols = dplyr::bind_cols(x, y),
        rows_update = dplyr::rows_update(x, y, by = "key"),
        reconstruct = dplyr::dplyr_reconstruct(prepared, x),
        grouped_left = dplyr::left_join(x, y, by = "key"),
        cross_four = dplyr::cross_join(x, y),
        nest_double = dplyr::nest_join(x, y, by = "key", name = "nested"),
        stop("Unknown Stage8 workload"))
}

s8_invoke <- function(input, route) {
    if (route == "predecessor_safe_reference") return(s8_reference(input))
    stopifnot(identical(route, "public"))
    s8_call(input$x, input$y, input$prepared, input$workload)
}

s8_shapes <- function(row_counts, mode) {
    shapes <- expand.grid(rows = row_counts, width = c(8L, 16L),
                          workload = s8_main, stringsAsFactors = FALSE)
    extra_rows <- if (mode %in% c("schemas", "smoke")) list(
        grouped_left = row_counts, cross_four = row_counts, nest_double = row_counts
    ) else list(grouped_left = row_counts, cross_four = c(25000L, 250000L),
                nest_double = c(1024L, 4096L))
    for (name in s8_extra) shapes <- rbind(shapes, expand.grid(
        rows = extra_rows[[name]], width = c(8L, 16L), workload = name,
        stringsAsFactors = FALSE))
    shapes
}
