# Values and row locations come from fixture arithmetic, not candidate calls.
# Schemas are explicitly predecessor observations, checked separately.
s8_plain <- function(value) {
    out <- switch(typeof(value), double = as.double(value), integer = as.integer(value),
        logical = as.integer(value), character = as.character(value),
        stop("Unexpected atomic payload type"))
    attributes(out) <- NULL
    out
}

s8_values <- function(index, column, side, wide = FALSE) {
    position <- (index - 1L) %% 4L + 1L
    value <- switch((column - 1L) %% 8L + 1L,
        as.double(index %% 101L) + side * 1000 + .25,
        c(1L, 0L, 1L, 0L)[position],
        c(2L, 1L, 2L, 3L)[position],
        c(2L, 1L, 2L, 3L)[position],
        (if (wide) c("right-hand-wide-string", "", "é", "other-wide-value")
         else c("alpha", "beta", "", "é"))[position],
        c("one", "two", "", "é")[position],
        as.double(index %% 67L + side * 100L),
        as.double(index %% 31L) - .5 + side * 1000)
    if (is.character(value)) value[is.na(value)] <- ""
    value
}

s8_schema <- function(value) {
    fields <- attributes(value)
    fields$.dtatools_ref_state <- NULL
    fields$.internal.selfref <- NULL
    if (is.data.frame(value)) fields$row.names <- NULL
    fields <- fields[sort(names(fields))]
    for (name in intersect(names(fields), c("groups", "ptype")))
        fields[[name]] <- s8_schema(fields[[name]])
    slots <- NULL
    if (typeof(value) == "list") {
        items <- lapply(seq_along(value), function(i) s8_schema(.subset2(value, i)))
        if (is.data.frame(value)) slots <- items else if (length(items)) {
            stopifnot(all(vapply(items, identical, logical(1), items[[1L]])))
            slots <- items[1L]
        } else slots <- list()
    }
    list(type = typeof(value), metadata = fields, slots = slots)
}

s8_assert <- function(ok, label) {
    if (!isTRUE(ok)) stop(paste("Stage8 benchmark validation:", label), call. = FALSE)
    invisible(NULL)
}

s8_column <- function(frame, name, expected) {
    s8_assert(name %in% names(frame), paste("missing column", name))
    s8_assert(identical(s8_plain(.subset2(frame, name)), expected),
              paste("values differ for", name))
}

s8_table <- function(value, rows, column_names, dibble = TRUE) {
    s8_assert(is.data.frame(value) && identical(nrow(value), as.integer(rows)), "row count")
    s8_assert(identical(names(value), column_names), "column names or order")
    s8_assert(all(vapply(seq_along(value), function(i)
        length(.subset2(value, i)) == rows, logical(1))), "column lengths")
    if (dibble) s8_assert(dtatools::is_dibble(value), "result is not a dibble")
    # Full row-name contents are checked for these automatic-row-name fixtures.
    s8_assert(identical(as.character(attr(value, "row.names")),
                         as.character(seq_len(rows))), "row names")
}

s8_groups <- function(value, index) {
    groups <- attr(value, "groups", exact = TRUE)
    keys <- sprintf("g%03d", sort(unique((index - 1L) %% 128L + 1L)))
    s8_assert(is.data.frame(groups) && identical(names(groups), c("g", ".rows")), "group columns")
    s8_column(groups, "g", keys)
    group_values <- sprintf("g%03d", (index - 1L) %% 128L + 1L)
    s8_column(value, "g", group_values)
    s8_assert(length(groups$.rows) == length(keys), "group count")
    for (i in seq_along(keys)) s8_assert(
        identical(groups$.rows[[i]], which(group_values == keys[[i]])), "group row locations")
    s8_assert(identical(attr(groups$.rows, "ptype", exact = TRUE), integer()), "group prototype")
}

s8_check_source <- function(input, schemas = NULL) {
    for (side in c("x", "y")) {
        value <- input[[side]]
        index <- input[[paste0(side, "_index")]]
        prefix <- if (side == "x") "c" else input$y_prefix
        omitted <- input[[paste0(side, "_omit")]]
        columns <- setdiff(seq_len(input$width), omitted)
        keys <- if (side == "x") input$x_index else input$y_keys
        grouped <- side == "x" && input$workload == "grouped_left"
        expected_names <- c(if (grouped) "g", if (!is.null(keys)) "key",
                            sprintf(paste0(prefix, "%02d"), columns))
        s8_table(value, length(index), expected_names)
        if (!is.null(keys)) s8_column(value, "key", as.double(keys))
        for (column in columns) s8_column(value, sprintf(paste0(prefix, "%02d"), column),
            s8_values(index, column, if (side == "x") 1L else 2L,
                       side == "y" && input$y_wide))
        if (grouped) s8_groups(value, index)
        if (!is.null(schemas)) s8_assert(identical(s8_schema(value), schemas[[side]]),
                                        paste("source schema", side))
    }
    invisible(NULL)
}

s8_check_result <- function(value, input, schema = NULL) {
    n <- input$rows
    w <- input$width
    workload <- input$workload
    index <- seq_len(n)
    left <- index
    right <- n + 1L - index
    key <- as.double(index)
    payload <- sprintf("c%02d", seq_len(w))
    right_names <- sprintf("r%02d", seq_len(w))
    if (workload == "inner_double") {
        left <- rep(index, each = 2L)
        right <- as.vector(rbind(2L * (n - index) + 1L, 2L * (n - index) + 2L))
        key <- as.double(left)
    } else if (workload == "full_padded") {
        left <- c(index, rep(NA_integer_, n %/% 2L))
        right <- c(ifelse(index <= n %/% 2L, NA_integer_, n + n %/% 2L + 1L - index),
                   seq_len(n %/% 2L))
        key <- as.double(c(index, rev(index + n %/% 2L)[seq_len(n %/% 2L)]))
    } else if (workload == "left_rolling") {
        right <- ((index - 1L) %/% 4L) * 4L + 1L
    } else if (workload %in% c("semi_half", "anti_half")) {
        left <- index[index %% 2L == if (workload == "semi_half") 0L else 1L]
        key <- as.double(left)
    } else if (workload == "cross_four") {
        left <- rep(index, each = 4L)
        right <- rep(seq_len(4L), times = n)
        key <- as.double(left)
    }

    if (workload %in% c("base_rbind", "bind_rows_wide")) {
        s8_table(value, 2L * n, c("key", payload))
        s8_column(value, "key", as.double(c(index, rev(index))))
        for (column in seq_len(w)) {
            a <- if (column %in% input$x_omit) rep(NA_integer_, n) else index
            b <- if (column %in% input$y_omit) rep(NA_integer_, n) else index
            s8_column(value, payload[[column]],
                c(s8_values(a, column, 1L), s8_values(b, column, 2L, input$y_wide)))
        }
    } else if (workload %in% c("rows_update", "reconstruct")) {
        s8_table(value, n, c("key", payload))
        s8_column(value, "key", key)
        for (column in seq_len(w)) {
            expected <- s8_values(index, column, 1L)
            if (workload == "rows_update") {
                selected <- seq.int(4L, n, by = 4L)
                expected[selected] <- s8_values(selected, column, 2L)
            }
            s8_column(value, payload[[column]], expected)
        }
    } else if (workload == "nest_double") {
        s8_table(value, n, c("key", payload, "nested"))
        s8_column(value, "key", key)
        for (column in seq_len(w)) s8_column(value, payload[[column]],
                                             s8_values(index, column, 1L))
        s8_assert(length(value$nested) == n, "nested table count")
        for (i in index) {
            child <- value$nested[[i]]
            locations <- c(2L * (n - i) + 1L, 2L * (n - i) + 2L)
            s8_table(child, 2L, right_names, dibble = FALSE)
            for (column in seq_len(w)) s8_column(child, right_names[[column]],
                s8_values(locations, column, 2L))
        }
    } else {
        grouped <- workload == "grouped_left"
        only_left <- workload %in% c("semi_half", "anti_half")
        columns <- c(if (grouped) "g", if (workload == "left_rolling") "key.x" else "key",
                     payload, if (!only_left) c(if (workload == "left_rolling") "key.y", right_names))
        s8_table(value, length(left), columns)
        s8_column(value, if (workload == "left_rolling") "key.x" else "key", key)
        if (workload == "left_rolling") s8_column(value, "key.y", as.double(right))
        if (workload %in% c("base_cbind", "bind_cols")) right <- index
        for (column in seq_len(w)) {
            s8_column(value, payload[[column]], s8_values(left, column, 1L))
            if (!only_left) s8_column(value, right_names[[column]], s8_values(right, column, 2L))
        }
        if (grouped) s8_groups(value, left)
    }
    if (!is.null(schema)) s8_assert(identical(s8_schema(value), schema), "result schema")
    invisible(NULL)
}
