"""Read all saved Stage8 series, times, GC records and raw allocation profiles."""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys

run = Path(sys.argv[1]).resolve(strict=True)
destination = Path(sys.argv[2])
expected_iterations = int(sys.argv[3])
expected_routes = sys.argv[4].split(',')
results = run / 'results'
receipt_path = run / 'receipt.json'
receipt = json.loads(receipt_path.read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for row in (receipt['result'], receipt['products']):
    assert sha(Path(row['path'])) == row['sha256']
index = json.loads((run / 'products.json').read_text())['products']
indexed = {row['path']: row for row in index}
observed = {}
def read(path):
    data = path.read_bytes()
    identity = hashlib.sha256(data).hexdigest()
    assert identity == indexed[str(path)]['sha256'], str(path)
    observed[str(path)] = identity
    return data.decode()
def read_csv(path):
    return list(csv.DictReader(read(path).splitlines()))
result = json.loads(read(run / 'result.json'))
command = json.loads(read(run / 'command-result.json'))
runtime = json.loads(read(run / 'runtime-coverage.json'))
assert result['status'] == 'complete' and result['inputs_unchanged']
assert result['input_binding_complete'] and command['returncode'] == 0
rows = read_csv(results / 'operations.csv')
main = ['left_unique', 'inner_double', 'full_padded', 'left_rolling',
        'semi_half', 'anti_half', 'base_rbind', 'base_cbind', 'bind_rows_wide',
        'bind_cols', 'rows_update', 'reconstruct']
shapes = {(n, w, name) for n in [100000, 1000000] for w in [8, 16] for name in main}
shapes |= {(n, w, 'grouped_left') for n in [100000, 1000000] for w in [8, 16]}
shapes |= {(n, w, 'cross_four') for n in [25000, 250000] for w in [8, 16]}
shapes |= {(n, w, 'nest_double') for n in [1024, 4096] for w in [8, 16]}
expected = {(*shape, route) for shape in shapes for route in expected_routes}
actual = {(int(r['rows']), int(r['width']), r['workload'], r['route']) for r in rows}
assert actual == expected and len(actual) == len(rows)
steps = {'initial', 'after_first_operation', 'after_first_validation',
         'after_warmed_operation', 'after_warmed_validation', 'before_timing',
         'after_timing', 'after_final_validation'}
profile_count = sample_count = state_count = gc_total = 0
for row in rows:
    stem = '-'.join(row[k] for k in ['rows', 'width', 'workload', 'route'])
    assert row['values_metadata_groups_source'] == 'TRUE'
    assert int(row['iterations']) == expected_iterations
    times = read_csv(results / (stem + '-times.csv'))
    assert [int(t['iteration']) for t in times] == list(range(1, expected_iterations + 1))
    values = [float(t['seconds']) for t in times]
    assert all(math.isfinite(x) and x > 0 for x in values)
    assert math.isclose(statistics.median(values) * 1000, float(row['median_ms']), rel_tol=1e-10, abs_tol=1e-8)
    gc_count = sum(int(t[k]) for t in times for k in ['level0', 'level1', 'level2'])
    assert gc_count == int(row['gc_count'])
    gc_total += gc_count
    sample_count += len(times)
    for stage, name in [('first', 'first-input-call'), ('warm', 'warmed-call')]:
        lines = read(results / (stem + '-' + name + '-Rprofmem.log')).splitlines()
        sizes = []
        for line in lines:
            match = re.match(r'^(\d+) :', line)
            assert match or line.startswith('new page:'), line
            if match:
                sizes.append(int(match[1]))
        assert sum(sizes) == int(float(row[stage + '_r_allocated_bytes']))
        assert max(sizes, default=0) == int(float(row[stage + '_r_largest_allocation_bytes']))
        profile_count += 1
    states = read_csv(results / (stem + '-states.csv'))
    assert {s['step'] for s in states} == steps
    assert all(int(s['depth']) == 1 for s in states if s['owned'] == 'TRUE')
    original = {s['path']: s['handle'] for s in states if s['step'] == 'initial'}
    for step in steps:
        current = {s['path']: s['handle'] for s in states
                   if s['step'] == step and (s['path'].startswith('x/') or s['path'].startswith('y/'))}
        assert current == original
    state_count += len(states)
assert profile_count == len(rows) * 2 and sample_count == len(rows) * expected_iterations
assert all(sha(Path(path)) == digest for path, digest in observed.items())
report = dict(status='complete saved-grid assessment', series=len(rows), samples=sample_count,
    profiles=profile_count, state_rows=state_count, gc_events=gc_total,
    receipt_sha256=sha(receipt_path), result=result, runtime=runtime,
    exact_shape_membership=True, all_raw_profile_sums_and_maxima_match=True,
    all_sample_medians_and_gc_totals_match=True, all_state_steps_and_source_handles_match=True,
    observed_owned_depth_one=True, selected_inputs_unchanged=True,
    scope='Read all saved CSV/time/GC/profile/state records against producer product identities; native depth and source handles checked. No new workload, duplicate full runtime inventory or exclusive native-cause analysis. Candidate comparison and overall acceptance remain separate.',
    selected_files=observed)
with destination.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: v for k, v in report.items() if k not in ['selected_files', 'result', 'runtime']}, indent=2))
