use crate::buffer::Cursor;
use crate::ext::TokenStreamExt as _;
use core::cmp::Ordering;
use proc_macro2::{Delimiter, TokenStream};

pub(crate) fn between(begin: Cursor, end: Cursor) -> TokenStream {
    let mut cursor = begin;
    assert!(crate::buffer::same_buffer(end, cursor));

    let mut tokens = TokenStream::new();
    while cursor != end {
        let (tt, next) = cursor.token_tree().unwrap();

        if crate::buffer::cmp_assuming_same_buffer(end, next) == Ordering::Less {
            // A syntax node can cross the boundary of a None-delimited group
            // due to such groups being transparent to the parser in most cases.
            // Any time this occurs the group is known to be semantically
            // irrelevant. https://github.com/dtolnay/syn/issues/1235
            if let Some((inside, _span, after)) = cursor.group(Delimiter::None) {
                assert!(next == after);
                cursor = inside;
                continue;
            } else {
                panic!("verbatim end must not be inside a delimited group");
            }
        }

        tokens.append(tt);
        cursor = next;
    }
    tokens
}
