<!---
  Licensed to the Apache Software Foundation (ASF) under one
  or more contributor license agreements.  See the NOTICE file
  distributed with this work for additional information
  regarding copyright ownership.  The ASF licenses this file
  to you under the Apache License, Version 2.0 (the
  "License"); you may not use this file except in compliance
  with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

  Unless required by applicable law or agreed to in writing,
  software distributed under the License is distributed on an
  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, either express or implied.  See the License for the
  specific language governing permissions and limitations
  under the License.
-->

# `arrow-ipc`

Support for reading and writing files and streams in the [Arrow IPC Format] to and from [Apache Arrow].

See the [main repository README] and the [API documentation] for more details.

## Security

See the [Security Policy] for information on the security model and how to report vulnerabilities.

[Apache Arrow]: https://arrow.apache.org/
[Arrow IPC Format]: https://arrow.apache.org/docs/format/Columnar.html#format-ipc
[main repository README]: https://github.com/apache/arrow-rs
[API documentation]: https://docs.rs/arrow-ipc/latest
[Security Policy]: https://github.com/apache/arrow-rs/blob/main/SECURITY.md
