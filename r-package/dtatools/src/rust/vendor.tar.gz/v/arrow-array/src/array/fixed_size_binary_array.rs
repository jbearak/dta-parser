// Licensed to the Apache Software Foundation (ASF) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The ASF licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

use crate::array::print_long_array;
use crate::iterator::FixedSizeBinaryIter;
use crate::{Array, ArrayAccessor, ArrayRef, FixedSizeListArray, Scalar};
use arrow_buffer::buffer::NullBuffer;
use arrow_buffer::{ArrowNativeType, Buffer, MutableBuffer, bit_util};
use arrow_data::{ArrayData, ArrayDataBuilder};
use arrow_schema::{ArrowError, DataType};
use std::any::Any;
use std::sync::Arc;

/// An array of [fixed-size binary values](https://arrow.apache.org/docs/format/Columnar.html#fixed-size-primitive-layout)
///
/// Each element in a [`FixedSizeBinaryArray`] has `value_length` bytes, where
/// `value_length` is defined by the schema.
///
/// This array type is useful for storing fixed-length values such as 16-byte
/// UUIDs (`value_length = 16`).
///
/// # Layout
///
/// Values in a [`FixedSizeBinaryArray`] are stored contiguously in a single
/// buffer. The byte offset for the `i`-th element can be calculated as
/// `i * value_length`.
///
/// Nulls are stored in a standard optional Arrow [`NullBuffer`].
///
/// For example, a 100-value [`FixedSizeBinaryArray`] with `value_length = 12`
/// is shown below.
///
/// ```text
/// ┌──────────────────────────────────────────┐
/// │ Computed byte offsets                    │
/// │          ┌──────────────────────┐ ┌────┐ │
/// │          │┌────────────────────┐│ │    │ │
/// │       0  ││value 0  (12 bytes) ││ │ 1  │ │
/// │          │├────────────────────┤│ │    │ │
/// │       12 ││value 1  (12 bytes) ││ │ 0  │ │
/// │          │├────────────────────┤│ │    │ │
/// │       24 ││value 2  (12 bytes) ││ │ 1  │ │
/// │          │└────────────────────┘│ │    │ │
/// │          │         ...          │ │... │ │
/// │          │┌───────────────────┐ │ │    │ │
/// │     1188 ││value 99 (12 bytes)│ │ │ 1  │ │
/// │          │└───────────────────┘ │ │    │ │
/// │          └──────────────────────┘ └────┘ │
/// │           value_data              nulls  │
/// └──────────────────────────────────────────┘
/// ```
///
/// # Examples
///
/// Create an array from an iterable argument of byte slices.
///
/// ```
///    use arrow_array::{Array, FixedSizeBinaryArray};
///    let input_arg = vec![ vec![1, 2], vec![3, 4], vec![5, 6] ];
///    let arr = FixedSizeBinaryArray::try_from_iter(input_arg.into_iter()).unwrap();
///
///    assert_eq!(3, arr.len());
///
/// ```
/// Create an array from an iterable argument of sparse byte slices.
/// Sparsity means that the input argument can contain `None` items.
/// ```
///    use arrow_array::{Array, FixedSizeBinaryArray};
///    let input_arg = vec![ None, Some(vec![7, 8]), Some(vec![9, 10]), None, Some(vec![13, 14]) ];
///    let arr = FixedSizeBinaryArray::try_from_sparse_iter_with_size(input_arg.into_iter(), 2).unwrap();
///    assert_eq!(5, arr.len())
///
/// ```
///
#[derive(Clone)]
pub struct FixedSizeBinaryArray {
    /// Must be DataType::FixedSizeBinary(value_size)
    data_type: DataType,
    /// `len` values, each `value_size` bytes
    value_data: Buffer,
    /// Optional Null Buffer
    nulls: Option<NullBuffer>,
    /// Number of elements in the array
    len: usize,
    /// size of each element, validated to fit in a positive i32
    ///
    /// Corresponds to the [`byteWidth` field] in the Arrow Spec
    ///
    /// note: Arrow stores `value_len` using i32. This implementation stores it
    /// as a usize to ensure correct offset calculations.
    ///
    /// [`byteWidth` field]: https://github.com/apache/arrow/blob/2a89d03bbefd620b42126b8e00f8ae57e99cd638/format/Schema.fbs#L211
    value_size: usize,
}

impl FixedSizeBinaryArray {
    /// Create a new [`FixedSizeBinaryArray`] with `value_length` bytes per element, panicking on
    /// failure
    ///
    /// # Panics
    ///
    /// Panics if [`Self::try_new`] returns an error
    pub fn new(value_length: i32, values: Buffer, nulls: Option<NullBuffer>) -> Self {
        Self::try_new(value_length, values, nulls).unwrap()
    }

    /// Create a new [`FixedSizeBinaryArray`] from the provided parts without validation.
    ///
    /// # Safety
    /// - `value_length >= 0`
    /// - `values.len() == len * value_length as usize`
    /// - `nulls.len() == len` if `nulls` is `Some`
    pub unsafe fn new_unchecked(
        value_length: i32,
        values: Buffer,
        nulls: Option<NullBuffer>,
        len: usize,
    ) -> Self {
        if cfg!(feature = "force_validate") {
            return Self::try_new_with_len(value_length, values, nulls, len).unwrap();
        }
        Self {
            data_type: DataType::FixedSizeBinary(value_length),
            value_data: values,
            value_size: value_length as usize,
            nulls,
            len,
        }
    }

    /// Create a new [`Scalar`] from `value`
    pub fn new_scalar(value: impl AsRef<[u8]>) -> Scalar<Self> {
        let v = value.as_ref();
        let value_length =
            i32::try_from(v.len()).expect("FixedSizeBinaryArray value length exceeds i32");
        Scalar::new(Self::new(value_length, Buffer::from(v), None))
    }

    /// Create a new [`FixedSizeBinaryArray`] from the provided parts, returning an error on failure
    ///
    /// Creating an array with `value_length == 0` will try to get the length from the null
    /// buffer. If no null buffer is provided, the resulting array will have length zero.
    /// You can use [`Self::try_new_with_len`] to provide the length
    ///
    /// # Errors
    ///
    /// * `value_length < 0`
    /// * `values.len() / value_length != nulls.len()`
    /// * `value_length == 0 && values.len() != 0`
    pub fn try_new(
        value_length: i32,
        values: Buffer,
        nulls: Option<NullBuffer>,
    ) -> Result<Self, ArrowError> {
        let value_size = value_length.to_usize().ok_or_else(|| {
            ArrowError::InvalidArgumentError(format!(
                "Value length cannot be negative, got {value_length}"
            ))
        })?;

        let len = match values.len().checked_div(value_size) {
            Some(len) => len,
            None => nulls.as_ref().map(|n| n.len()).unwrap_or(0),
        };

        Self::try_new_with_len(value_length, values, nulls, len)
    }

    /// Create a new [`FixedSizeBinaryArray`] from the provided parts and number of elements, returning an error on failure
    ///
    /// This is useful when the length cannot be determinated from the provided values (in case of `value_length == 0`) or nulls (`nulls.is_none()`).
    ///
    /// # Errors
    ///
    /// * `value_length < 0`
    /// * `values.len() / value_length != len`
    /// * `value_length == 0 && values.len() != 0`
    /// * `nulls.len() != len`
    /// * `value_length != 0 && values.len() / value_length != len`
    pub fn try_new_with_len(
        value_length: i32,
        values: Buffer,
        nulls: Option<NullBuffer>,
        len: usize,
    ) -> Result<Self, ArrowError> {
        let data_type = DataType::FixedSizeBinary(value_length);
        let value_size = value_length.to_usize().ok_or_else(|| {
            ArrowError::InvalidArgumentError(format!(
                "Value length cannot be negative, got {value_length}"
            ))
        })?;

        if let Some(nulls) = &nulls {
            if nulls.len() != len {
                return Err(ArrowError::InvalidArgumentError(format!(
                    "Incorrect length of null buffer for FixedSizeBinaryArray, expected {} got {}",
                    len,
                    nulls.len(),
                )));
            }
        }

        if value_size != 0 && values.len() / value_size != len {
            return Err(ArrowError::InvalidArgumentError(format!(
                "Incorrect length of values buffer for FixedSizeBinaryArray, expected {} got {}",
                len,
                values.len() / value_size,
            )));
        }

        if value_size == 0 && !values.is_empty() {
            return Err(ArrowError::InvalidArgumentError(
                "Buffer cannot have non-zero length if the value length is zero".to_owned(),
            ));
        }

        Ok(Self {
            data_type,
            value_data: values,
            value_size,
            nulls,
            len,
        })
    }

    /// Create a new [`FixedSizeBinaryArray`] of length `len` where all values are null
    ///
    /// # Panics
    ///
    /// Panics if
    ///
    /// * `value_length < 0`
    /// * `value_length * len` would overflow `usize`
    /// * `value_length * len * 8` would overflow `usize`
    pub fn new_null(value_length: i32, len: usize) -> Self {
        const BITS_IN_A_BYTE: usize = 8;
        let value_size = value_length.to_usize().unwrap();
        let capacity_in_bytes = value_size.checked_mul(len).unwrap();
        let capacity_in_bits = capacity_in_bytes.checked_mul(BITS_IN_A_BYTE).unwrap();
        Self {
            data_type: DataType::FixedSizeBinary(value_length),
            value_data: MutableBuffer::new_null(capacity_in_bits).into(),
            nulls: Some(NullBuffer::new_null(len)),
            value_size,
            len,
        }
    }

    /// Deconstruct this array into its constituent parts
    pub fn into_parts(self) -> (i32, Buffer, Option<NullBuffer>) {
        let value_length = self.value_length();
        (value_length, self.value_data, self.nulls)
    }

    /// Returns the element at index `i` as a byte slice.
    ///
    /// Note: This method does not check for nulls and the value is arbitrary
    /// (but still well-defined) if [`is_null`](Self::is_null) returns true for the index.
    ///
    /// # Panics
    /// Panics if index `i` is out of bounds.
    pub fn value(&self, i: usize) -> &[u8] {
        let len = self.len();
        assert!(
            i < len,
            "Trying to access an element at index {i} from a FixedSizeBinaryArray of length {len}",
        );
        let position = i * self.value_size;
        unsafe {
            std::slice::from_raw_parts(self.value_data.as_ptr().add(position), self.value_size)
        }
    }

    /// Returns the element at index `i` as a byte slice.
    ///
    /// Note: This method does not check for nulls and the value is arbitrary
    /// if [`is_null`](Self::is_null) returns true for the index.
    ///
    /// # Safety
    ///
    /// Caller is responsible for ensuring that the index is within the bounds
    /// of the array
    pub unsafe fn value_unchecked(&self, i: usize) -> &[u8] {
        let position = i * self.value_size;
        unsafe {
            std::slice::from_raw_parts(self.value_data.as_ptr().add(position), self.value_size)
        }
    }

    /// Returns the offset for the element at index `i`.
    ///
    /// Note this doesn't do any bound checking, for performance reason.
    ///
    /// # Panics
    ///
    /// Panics if the computed byte offset exceeds `i32::MAX`.
    #[deprecated(since = "59.0.0", note = "Use i * value_size() instead")]
    #[inline]
    pub fn value_offset(&self, i: usize) -> i32 {
        self.value_length() * i as i32
    }

    /// Returns the length for an element.
    ///
    /// All elements have the same length as the array is a fixed size.
    ///
    /// Returns an `i32` to be compatible with the Arrow spec.
    ///
    /// Use [`Self::value_size`] to return a `usize`.
    #[inline]
    pub fn value_length(&self) -> i32 {
        // This is safe: constructor validated that value_size was a valid i32
        self.value_size as i32
    }

    /// Return the length for an element, as a usize.
    ///
    /// All elements have the same length as the array is a fixed size.
    ///
    /// Note: This value will always fit, without overflow, into an i32
    #[inline]
    pub fn value_size(&self) -> usize {
        self.value_size
    }

    /// Returns the values of this array.
    ///
    /// Unlike [`Self::value_data`] this returns the [`Buffer`]
    /// allowing for zero-copy cloning.
    #[inline]
    pub fn values(&self) -> &Buffer {
        &self.value_data
    }

    /// Returns the raw value data.
    pub fn value_data(&self) -> &[u8] {
        self.value_data.as_slice()
    }

    /// Returns a zero-copy slice of this array with the indicated offset and length.
    pub fn slice(&self, offset: usize, len: usize) -> Self {
        assert!(
            offset.saturating_add(len) <= self.len,
            "the length + offset of the sliced FixedSizeBinaryArray cannot exceed the existing length"
        );
        let offset_bytes = offset
            .checked_mul(self.value_size)
            .expect("offset overflow");
        let len_bytes = len.checked_mul(self.value_size).expect("offset overflow");

        Self {
            data_type: self.data_type.clone(),
            nulls: self.nulls.as_ref().map(|n| n.slice(offset, len)),
            value_size: self.value_size,
            value_data: self.value_data.slice_with_length(offset_bytes, len_bytes),
            len,
        }
    }

    /// Create an array from an iterable argument of sparse byte slices.
    /// Sparsity means that items returned by the iterator are optional, i.e input argument can
    /// contain `None` items.
    ///
    /// # Examples
    ///
    /// ```
    /// use arrow_array::FixedSizeBinaryArray;
    /// let input_arg = vec![
    ///     None,
    ///     Some(vec![7, 8]),
    ///     Some(vec![9, 10]),
    ///     None,
    ///     Some(vec![13, 14]),
    ///     None,
    /// ];
    /// let array = FixedSizeBinaryArray::try_from_sparse_iter(input_arg.into_iter()).unwrap();
    /// ```
    ///
    /// # Errors
    ///
    /// Returns error if argument has length zero, or sizes of nested slices don't match.
    #[deprecated(
        since = "28.0.0",
        note = "This function will fail if the iterator produces only None values; prefer `try_from_sparse_iter_with_size`"
    )]
    pub fn try_from_sparse_iter<T, U>(mut iter: T) -> Result<Self, ArrowError>
    where
        T: Iterator<Item = Option<U>>,
        U: AsRef<[u8]>,
    {
        let mut len = 0;
        let mut value_size = None;
        let mut byte = 0;

        let iter_size_hint = iter.size_hint().0;
        let mut null_buf = MutableBuffer::new(bit_util::ceil(iter_size_hint, 8));
        let mut buffer = MutableBuffer::new(0);

        let mut prepend = 0;
        iter.try_for_each(|item| -> Result<(), ArrowError> {
            // extend null bitmask by one byte per each 8 items
            if byte == 0 {
                null_buf.push(0u8);
                byte = 8;
            }
            byte -= 1;

            if let Some(slice) = item {
                let slice = slice.as_ref();
                if let Some(size) = value_size {
                    if size != slice.len() {
                        return Err(ArrowError::InvalidArgumentError(format!(
                            "Nested array size mismatch: one is {}, and the other is {}",
                            size,
                            slice.len()
                        )));
                    }
                } else {
                    let len = slice.len();
                    value_size = Some(len);
                    // Now that we know how large each element is we can reserve
                    // sufficient capacity in the underlying mutable buffer for
                    // the data.
                    if let Some(capacity) = iter_size_hint.checked_mul(len) {
                        buffer.reserve(capacity);
                    }
                    let prepend_zeros = slice.len().checked_mul(prepend).ok_or_else(|| {
                        ArrowError::InvalidArgumentError(format!(
                            "FixedSizeBinaryArray error: value size {} * prepend {prepend} exceeds usize",
                            slice.len()
                        ))
                    })?;
                    buffer.extend_zeros(prepend_zeros);
                }
                bit_util::set_bit(null_buf.as_slice_mut(), len);
                buffer.extend_from_slice(slice);
            } else if let Some(size) = value_size {
                buffer.extend_zeros(size);
            } else {
                prepend += 1;
            }

            len += 1;

            Ok(())
        })?;

        if len == 0 {
            return Err(ArrowError::InvalidArgumentError(
                "Input iterable argument has no data".to_owned(),
            ));
        }

        let nulls = NullBuffer::from_unsliced_buffer(null_buf, len);

        let value_size = value_size.unwrap_or(0);
        let value_length = value_size.try_into().map_err(|_| {
            ArrowError::InvalidArgumentError(format!(
                "FixedSizeBinaryArray value length exceeds i32, got {value_size}"
            ))
        })?;
        Ok(Self {
            data_type: DataType::FixedSizeBinary(value_length),
            value_data: buffer.into(),
            nulls,
            value_size,
            len,
        })
    }

    /// Create an array from an iterable argument of sparse byte slices.
    /// Sparsity means that items returned by the iterator are optional, i.e input argument can
    /// contain `None` items. In cases where the iterator returns only `None` values, this
    /// also takes a `value_length` parameter to ensure that a valid
    /// [`FixedSizeBinaryArray`] is still created.
    ///
    /// # Examples
    ///
    /// ```
    /// use arrow_array::FixedSizeBinaryArray;
    /// let input_arg = vec![
    ///     None,
    ///     Some(vec![7, 8]),
    ///     Some(vec![9, 10]),
    ///     None,
    ///     Some(vec![13, 14]),
    ///     None,
    /// ];
    /// let array = FixedSizeBinaryArray::try_from_sparse_iter_with_size(input_arg.into_iter(), 2).unwrap();
    /// ```
    ///
    /// # Errors
    ///
    /// Returns error if argument has length zero, or sizes of nested slices don't match.
    pub fn try_from_sparse_iter_with_size<T, U>(
        mut iter: T,
        value_length: i32,
    ) -> Result<Self, ArrowError>
    where
        T: Iterator<Item = Option<U>>,
        U: AsRef<[u8]>,
    {
        let value_size = value_length.to_usize().ok_or_else(|| {
            ArrowError::InvalidArgumentError(format!(
                "Value length cannot be negative, got {value_length}"
            ))
        })?;
        let mut len = 0;
        let mut byte = 0;

        let iter_size_hint = iter.size_hint().0;
        let mut null_buf = MutableBuffer::new(bit_util::ceil(iter_size_hint, 8));
        let capacity = iter_size_hint.checked_mul(value_size).ok_or_else(|| {
            ArrowError::InvalidArgumentError(format!(
                "FixedSizeBinaryArray error: value size {value_size} * len hint {iter_size_hint} exceeds usize"
            ))
        })?;
        let mut buffer = MutableBuffer::new(capacity);

        iter.try_for_each(|item| -> Result<(), ArrowError> {
            // extend null bitmask by one byte per each 8 items
            if byte == 0 {
                null_buf.push(0u8);
                byte = 8;
            }
            byte -= 1;

            if let Some(slice) = item {
                let slice = slice.as_ref();
                if value_size != slice.len() {
                    return Err(ArrowError::InvalidArgumentError(format!(
                        "Nested array size mismatch: one is {}, and the other is {}",
                        value_length,
                        slice.len()
                    )));
                }

                bit_util::set_bit(null_buf.as_slice_mut(), len);
                buffer.extend_from_slice(slice);
            } else {
                buffer.extend_zeros(value_size);
            }

            len += 1;

            Ok(())
        })?;

        let nulls = NullBuffer::from_unsliced_buffer(null_buf, len);

        Ok(Self {
            data_type: DataType::FixedSizeBinary(value_length),
            value_data: buffer.into(),
            nulls,
            len,
            value_size,
        })
    }

    /// Create an array from an iterable argument of byte slices.
    ///
    /// # Examples
    ///
    /// ```
    /// use arrow_array::FixedSizeBinaryArray;
    /// let input_arg = vec![
    ///     vec![1, 2],
    ///     vec![3, 4],
    ///     vec![5, 6],
    /// ];
    /// let array = FixedSizeBinaryArray::try_from_iter(input_arg.into_iter()).unwrap();
    /// ```
    ///
    /// # Errors
    ///
    /// Returns error if argument has length zero, or sizes of nested slices don't match.
    pub fn try_from_iter<T, U>(mut iter: T) -> Result<Self, ArrowError>
    where
        T: Iterator<Item = U>,
        U: AsRef<[u8]>,
    {
        let mut len = 0;
        let mut value_size = None;
        let iter_size_hint = iter.size_hint().0;
        let mut buffer = MutableBuffer::new(0);

        iter.try_for_each(|item| -> Result<(), ArrowError> {
            let slice = item.as_ref();
            if let Some(value_size) = value_size {
                if value_size != slice.len() {
                    return Err(ArrowError::InvalidArgumentError(format!(
                        "Nested array size mismatch: one is {value_size}, and the other is {}",
                        slice.len()
                    )));
                }
            } else {
                let len = slice.len();
                value_size = Some(len);
                if let Some(capacity) = iter_size_hint.checked_mul(len) {
                    buffer.reserve(capacity);
                }
            }

            buffer.extend_from_slice(slice);

            len += 1;

            Ok(())
        })?;

        if len == 0 {
            return Err(ArrowError::InvalidArgumentError(
                "Input iterable argument has no data".to_owned(),
            ));
        }

        let value_size = value_size.unwrap_or(0);
        let value_length = value_size.try_into().map_err(|_| {
            ArrowError::InvalidArgumentError(format!(
                "FixedSizeBinaryArray value length exceeds i32, got {value_size}"
            ))
        })?;
        Ok(Self {
            data_type: DataType::FixedSizeBinary(value_length),
            value_data: buffer.into(),
            nulls: None,
            value_size,
            len,
        })
    }

    /// constructs a new iterator
    pub fn iter(&self) -> FixedSizeBinaryIter<'_> {
        FixedSizeBinaryIter::new(self)
    }
}

impl From<ArrayData> for FixedSizeBinaryArray {
    fn from(data: ArrayData) -> Self {
        let (data_type, len, nulls, offset, buffers, _child_data) = data.into_parts();

        assert_eq!(
            buffers.len(),
            1,
            "FixedSizeBinaryArray data should contain 1 buffer only (values)"
        );
        let value_length = match data_type {
            DataType::FixedSizeBinary(len) => len,
            _ => panic!("Expected data type to be FixedSizeBinary"),
        };

        let value_size = value_length
            .to_usize()
            .expect("FixedSizeBinaryArray value length must be non-negative");
        let value_data = buffers[0].slice_with_length(
            offset.checked_mul(value_size).expect("offset overflow"),
            len.checked_mul(value_size).expect("length overflow"),
        );

        Self {
            data_type,
            nulls,
            len,
            value_data,
            value_size,
        }
    }
}

impl From<FixedSizeBinaryArray> for ArrayData {
    fn from(array: FixedSizeBinaryArray) -> Self {
        let builder = ArrayDataBuilder::new(array.data_type)
            .len(array.len)
            .buffers(vec![array.value_data])
            .nulls(array.nulls);

        unsafe { builder.build_unchecked() }
    }
}

/// Creates a `FixedSizeBinaryArray` from `FixedSizeList<u8>` array
impl From<FixedSizeListArray> for FixedSizeBinaryArray {
    fn from(v: FixedSizeListArray) -> Self {
        let value_len = v.value_length();
        let v = v.into_data();
        assert_eq!(
            v.child_data().len(),
            1,
            "FixedSizeBinaryArray can only be created from list array of u8 values \
             (i.e. FixedSizeList<PrimitiveArray<u8>>)."
        );
        let child_data = &v.child_data()[0];

        assert_eq!(
            child_data.child_data().len(),
            0,
            "FixedSizeBinaryArray can only be created from list array of u8 values \
             (i.e. FixedSizeList<PrimitiveArray<u8>>)."
        );
        assert_eq!(
            child_data.data_type(),
            &DataType::UInt8,
            "FixedSizeBinaryArray can only be created from FixedSizeList<u8> arrays, mismatched data types."
        );
        assert_eq!(
            child_data.null_count(),
            0,
            "The child array cannot contain null values."
        );

        let builder = ArrayData::builder(DataType::FixedSizeBinary(value_len))
            .len(v.len())
            .offset(v.offset())
            .add_buffer(child_data.buffers()[0].slice(child_data.offset()))
            .nulls(v.nulls().cloned());

        let data = unsafe { builder.build_unchecked() };
        Self::from(data)
    }
}

impl TryFrom<Vec<Option<&[u8]>>> for FixedSizeBinaryArray {
    type Error = ArrowError;

    fn try_from(v: Vec<Option<&[u8]>>) -> Result<Self, Self::Error> {
        #[allow(deprecated)]
        Self::try_from_sparse_iter(v.into_iter())
    }
}

impl TryFrom<Vec<&[u8]>> for FixedSizeBinaryArray {
    type Error = ArrowError;

    fn try_from(v: Vec<&[u8]>) -> Result<Self, Self::Error> {
        Self::try_from_iter(v.into_iter())
    }
}

impl<const N: usize> TryFrom<Vec<Option<&[u8; N]>>> for FixedSizeBinaryArray {
    type Error = ArrowError;

    fn try_from(v: Vec<Option<&[u8; N]>>) -> Result<Self, Self::Error> {
        N.try_into()
            .map_err(|_| {
                ArrowError::InvalidArgumentError(format!(
                    "FixedSizeBinaryArray value length exceeds i32, got {N}"
                ))
            })
            .and_then(|x| Self::try_from_sparse_iter_with_size(v.into_iter(), x))
    }
}

impl<const N: usize> TryFrom<Vec<&[u8; N]>> for FixedSizeBinaryArray {
    type Error = ArrowError;

    fn try_from(v: Vec<&[u8; N]>) -> Result<Self, Self::Error> {
        Self::try_from_iter(v.into_iter())
    }
}

impl std::fmt::Debug for FixedSizeBinaryArray {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "FixedSizeBinaryArray<{}>\n[\n", self.value_length())?;
        print_long_array(self, f, |array, index, f| {
            std::fmt::Debug::fmt(&array.value(index), f)
        })?;
        write!(f, "]")
    }
}

/// SAFETY: Correctly implements the contract of Arrow Arrays
unsafe impl Array for FixedSizeBinaryArray {
    fn as_any(&self) -> &dyn Any {
        self
    }

    fn to_data(&self) -> ArrayData {
        self.clone().into()
    }

    fn into_data(self) -> ArrayData {
        self.into()
    }

    fn data_type(&self) -> &DataType {
        &self.data_type
    }

    fn slice(&self, offset: usize, length: usize) -> ArrayRef {
        Arc::new(self.slice(offset, length))
    }

    fn len(&self) -> usize {
        self.len
    }

    fn is_empty(&self) -> bool {
        self.len == 0
    }

    fn shrink_to_fit(&mut self) {
        self.value_data.shrink_to_fit();
        if let Some(nulls) = &mut self.nulls {
            nulls.shrink_to_fit();
        }
    }

    fn offset(&self) -> usize {
        // Slices are normalized by slicing `value_data`/`nulls` directly;
        // FSB does not retain a separate logical element offset.
        0
    }

    fn nulls(&self) -> Option<&NullBuffer> {
        self.nulls.as_ref()
    }

    fn logical_null_count(&self) -> usize {
        // More efficient that the default implementation
        self.null_count()
    }

    fn get_buffer_memory_size(&self) -> usize {
        let mut sum = self.value_data.capacity();
        if let Some(n) = &self.nulls {
            sum += n.buffer().capacity();
        }
        sum
    }

    fn get_array_memory_size(&self) -> usize {
        std::mem::size_of::<Self>() + self.get_buffer_memory_size()
    }

    #[cfg(feature = "pool")]
    fn claim(&self, pool: &dyn arrow_buffer::MemoryPool) {
        self.value_data.claim(pool);
        if let Some(nulls) = &self.nulls {
            nulls.claim(pool);
        }
    }
}

impl<'a> ArrayAccessor for &'a FixedSizeBinaryArray {
    type Item = &'a [u8];

    fn value(&self, index: usize) -> Self::Item {
        FixedSizeBinaryArray::value(self, index)
    }

    unsafe fn value_unchecked(&self, index: usize) -> Self::Item {
        unsafe { FixedSizeBinaryArray::value_unchecked(self, index) }
    }
}

impl<'a> IntoIterator for &'a FixedSizeBinaryArray {
    type Item = Option<&'a [u8]>;
    type IntoIter = FixedSizeBinaryIter<'a>;

    fn into_iter(self) -> Self::IntoIter {
        FixedSizeBinaryIter::<'a>::new(self)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::RecordBatch;
    use arrow_schema::{Field, Schema};

    #[test]
    fn test_fixed_size_binary_array() {
        let values = b"hellotherearrow";

        let array_data = ArrayData::builder(DataType::FixedSizeBinary(5))
            .len(3)
            .add_buffer(Buffer::from(values))
            .build()
            .unwrap();
        let fixed_size_binary_array = FixedSizeBinaryArray::from(array_data);
        assert_eq!(3, fixed_size_binary_array.len());
        assert_eq!(0, fixed_size_binary_array.null_count());
        assert_eq!(
            [b'h', b'e', b'l', b'l', b'o'],
            fixed_size_binary_array.value(0)
        );
        assert_eq!(
            [b't', b'h', b'e', b'r', b'e'],
            fixed_size_binary_array.value(1)
        );
        assert_eq!(
            [b'a', b'r', b'r', b'o', b'w'],
            fixed_size_binary_array.value(2)
        );
        assert_eq!(5, fixed_size_binary_array.value_length());
        for i in 0..3 {
            assert!(fixed_size_binary_array.is_valid(i));
            assert!(!fixed_size_binary_array.is_null(i));
        }

        // Test binary array with offset
        let array_data = ArrayData::builder(DataType::FixedSizeBinary(5))
            .len(2)
            .offset(1)
            .add_buffer(Buffer::from(values))
            .build()
            .unwrap();
        let fixed_size_binary_array = FixedSizeBinaryArray::from(array_data);
        assert_eq!(
            [b't', b'h', b'e', b'r', b'e'],
            fixed_size_binary_array.value(0)
        );
        assert_eq!(
            [b'a', b'r', b'r', b'o', b'w'],
            fixed_size_binary_array.value(1)
        );
        assert_eq!(2, fixed_size_binary_array.len());
        assert_eq!(5, fixed_size_binary_array.value_length());
    }

    #[test]
    fn test_fixed_size_binary_array_from_fixed_size_list_array() {
        let values = [0_u8, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13];
        let values_data = ArrayData::builder(DataType::UInt8)
            .len(12)
            .offset(2)
            .add_buffer(Buffer::from_slice_ref(values))
            .build()
            .unwrap();
        // [null, [10, 11, 12, 13]]
        let array_data = unsafe {
            ArrayData::builder(DataType::FixedSizeList(
                Arc::new(Field::new_list_field(DataType::UInt8, false)),
                4,
            ))
            .len(2)
            .offset(1)
            .add_child_data(values_data)
            .null_bit_buffer(Some(Buffer::from_slice_ref([0b101])))
            .build_unchecked()
        };
        let list_array = FixedSizeListArray::from(array_data);
        let binary_array = FixedSizeBinaryArray::from(list_array);

        assert_eq!(2, binary_array.len());
        assert_eq!(1, binary_array.null_count());
        assert!(binary_array.is_null(0));
        assert!(binary_array.is_valid(1));
        assert_eq!(&[10, 11, 12, 13], binary_array.value(1));
    }

    #[test]
    #[should_panic(
        expected = "FixedSizeBinaryArray can only be created from FixedSizeList<u8> arrays"
    )]
    // Different error messages, so skip for now
    // https://github.com/apache/arrow-rs/issues/1545
    #[cfg(not(feature = "force_validate"))]
    fn test_fixed_size_binary_array_from_incorrect_fixed_size_list_array() {
        let values: [u32; 12] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
        let values_data = ArrayData::builder(DataType::UInt32)
            .len(12)
            .add_buffer(Buffer::from_slice_ref(values))
            .build()
            .unwrap();

        let array_data = unsafe {
            ArrayData::builder(DataType::FixedSizeList(
                Arc::new(Field::new_list_field(DataType::Binary, false)),
                4,
            ))
            .len(3)
            .add_child_data(values_data)
            .build_unchecked()
        };
        let list_array = FixedSizeListArray::from(array_data);
        drop(FixedSizeBinaryArray::from(list_array));
    }

    #[test]
    #[should_panic(expected = "The child array cannot contain null values.")]
    fn test_fixed_size_binary_array_from_fixed_size_list_array_with_child_nulls_failed() {
        let values = [0_u8, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
        let values_data = ArrayData::builder(DataType::UInt8)
            .len(12)
            .add_buffer(Buffer::from_slice_ref(values))
            .null_bit_buffer(Some(Buffer::from_slice_ref([0b101010101010])))
            .build()
            .unwrap();

        let array_data = unsafe {
            ArrayData::builder(DataType::FixedSizeList(
                Arc::new(Field::new_list_field(DataType::UInt8, false)),
                4,
            ))
            .len(3)
            .add_child_data(values_data)
            .build_unchecked()
        };
        let list_array = FixedSizeListArray::from(array_data);
        drop(FixedSizeBinaryArray::from(list_array));
    }

    #[test]
    fn test_fixed_size_binary_array_fmt_debug() {
        let values = b"hellotherearrow";

        let array_data = ArrayData::builder(DataType::FixedSizeBinary(5))
            .len(3)
            .add_buffer(Buffer::from(values))
            .build()
            .unwrap();
        let arr = FixedSizeBinaryArray::from(array_data);
        assert_eq!(
            "FixedSizeBinaryArray<5>\n[\n  [104, 101, 108, 108, 111],\n  [116, 104, 101, 114, 101],\n  [97, 114, 114, 111, 119],\n]",
            format!("{arr:?}")
        );
    }

    #[test]
    fn test_fixed_size_binary_array_from_iter() {
        let input_arg = vec![vec![1, 2], vec![3, 4], vec![5, 6]];
        let arr = FixedSizeBinaryArray::try_from_iter(input_arg.into_iter()).unwrap();

        assert_eq!(2, arr.value_length());
        assert_eq!(3, arr.len())
    }

    #[test]
    fn test_all_none_fixed_size_binary_array_from_sparse_iter() {
        let none_option: Option<[u8; 32]> = None;
        let input_arg = vec![none_option, none_option, none_option];
        #[allow(deprecated)]
        let arr = FixedSizeBinaryArray::try_from_sparse_iter(input_arg.into_iter()).unwrap();
        assert_eq!(0, arr.value_length());
        assert_eq!(3, arr.len())
    }

    #[test]
    fn test_fixed_size_binary_array_from_sparse_iter() {
        let input_arg = vec![
            None,
            Some(vec![7, 8]),
            Some(vec![9, 10]),
            None,
            Some(vec![13, 14]),
        ];
        #[allow(deprecated)]
        let arr = FixedSizeBinaryArray::try_from_sparse_iter(input_arg.iter().cloned()).unwrap();
        assert_eq!(2, arr.value_length());
        assert_eq!(5, arr.len());

        let arr =
            FixedSizeBinaryArray::try_from_sparse_iter_with_size(input_arg.into_iter(), 2).unwrap();
        assert_eq!(2, arr.value_length());
        assert_eq!(5, arr.len());
    }

    #[test]
    fn test_fixed_size_binary_array_from_sparse_iter_with_size_all_none() {
        let input_arg = vec![None, None, None, None, None] as Vec<Option<Vec<u8>>>;

        let arr = FixedSizeBinaryArray::try_from_sparse_iter_with_size(input_arg.into_iter(), 16)
            .unwrap();
        assert_eq!(16, arr.value_length());
        assert_eq!(5, arr.len())
    }

    #[test]
    fn test_fixed_size_binary_array_from_vec() {
        let values = vec!["one".as_bytes(), b"two", b"six", b"ten"];
        let array = FixedSizeBinaryArray::try_from(values).unwrap();
        assert_eq!(array.len(), 4);
        assert_eq!(array.null_count(), 0);
        assert_eq!(array.logical_null_count(), 0);
        assert_eq!(array.value(0), b"one");
        assert_eq!(array.value(1), b"two");
        assert_eq!(array.value(2), b"six");
        assert_eq!(array.value(3), b"ten");
        assert!(!array.is_null(0));
        assert!(!array.is_null(1));
        assert!(!array.is_null(2));
        assert!(!array.is_null(3));
    }

    #[test]
    fn test_fixed_size_binary_array_from_vec_incorrect_length() {
        let values = vec!["one".as_bytes(), b"two", b"three", b"four"];
        assert!(FixedSizeBinaryArray::try_from(values).is_err());
    }

    #[test]
    fn test_fixed_size_binary_array_from_opt_vec() {
        let values = vec![
            Some("one".as_bytes()),
            Some(b"two"),
            None,
            Some(b"six"),
            Some(b"ten"),
        ];
        let array = FixedSizeBinaryArray::try_from(values).unwrap();
        assert_eq!(array.len(), 5);
        assert_eq!(array.value(0), b"one");
        assert_eq!(array.value(1), b"two");
        assert_eq!(array.value(3), b"six");
        assert_eq!(array.value(4), b"ten");
        assert!(!array.is_null(0));
        assert!(!array.is_null(1));
        assert!(array.is_null(2));
        assert!(!array.is_null(3));
        assert!(!array.is_null(4));
    }

    #[test]
    fn test_fixed_size_binary_array_from_opt_vec_incorrect_length() {
        let values = vec![
            Some("one".as_bytes()),
            Some(b"two"),
            None,
            Some(b"three"),
            Some(b"four"),
        ];
        assert!(FixedSizeBinaryArray::try_from(values).is_err());
    }

    #[test]
    fn fixed_size_binary_array_all_null() {
        let data = vec![None] as Vec<Option<String>>;
        let array =
            FixedSizeBinaryArray::try_from_sparse_iter_with_size(data.into_iter(), 0).unwrap();
        array
            .into_data()
            .validate_full()
            .expect("All null array has valid array data");
    }

    #[test]
    // Test for https://github.com/apache/arrow-rs/issues/1390
    fn fixed_size_binary_array_all_null_in_batch_with_schema() {
        let schema = Schema::new(vec![Field::new("a", DataType::FixedSizeBinary(2), true)]);

        let none_option: Option<[u8; 2]> = None;
        let item = FixedSizeBinaryArray::try_from_sparse_iter_with_size(
            vec![none_option, none_option, none_option].into_iter(),
            2,
        )
        .unwrap();

        // Should not panic
        RecordBatch::try_new(Arc::new(schema), vec![Arc::new(item)]).unwrap();
    }

    #[test]
    #[should_panic(
        expected = "Trying to access an element at index 4 from a FixedSizeBinaryArray of length 3"
    )]
    fn test_fixed_size_binary_array_get_value_index_out_of_bound() {
        let values = vec![Some("one".as_bytes()), Some(b"two"), None];
        let array = FixedSizeBinaryArray::try_from(values).unwrap();

        array.value(4);
    }

    #[test]
    fn test_constructors() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);
        let a = FixedSizeBinaryArray::new(2, buffer.clone(), None);
        assert_eq!(a.len(), 5);

        let nulls = NullBuffer::new_null(5);
        FixedSizeBinaryArray::new(2, buffer.clone(), Some(nulls));

        let null_array = FixedSizeBinaryArray::new_null(4, 3);
        assert_eq!(null_array.len(), 3);
        assert_eq!(null_array.values().len(), 12);

        let a = FixedSizeBinaryArray::new(3, buffer.clone(), None);
        assert_eq!(a.len(), 3);

        let nulls = NullBuffer::new_null(3);
        FixedSizeBinaryArray::new(3, buffer.clone(), Some(nulls));

        let err = FixedSizeBinaryArray::try_new(-1, buffer.clone(), None).unwrap_err();

        assert_eq!(
            err.to_string(),
            "Invalid argument error: Value length cannot be negative, got -1"
        );

        let nulls = NullBuffer::new_null(3);
        let err = FixedSizeBinaryArray::try_new(2, buffer.clone(), Some(nulls)).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Invalid argument error: Incorrect length of null buffer for FixedSizeBinaryArray, expected 5 got 3"
        );

        let zero_sized = FixedSizeBinaryArray::new(0, Buffer::default(), None);
        assert_eq!(zero_sized.len(), 0);
        assert_eq!(zero_sized.null_count(), 0);
        assert_eq!(zero_sized.values().len(), 0);

        let nulls = NullBuffer::new_null(3);
        let zero_sized_with_nulls = FixedSizeBinaryArray::new(0, Buffer::default(), Some(nulls));
        assert_eq!(zero_sized_with_nulls.len(), 3);
        assert_eq!(zero_sized_with_nulls.null_count(), 3);
        assert_eq!(zero_sized_with_nulls.values().len(), 0);

        let zero_sized_with_non_empty_buffer_err =
            FixedSizeBinaryArray::try_new(0, buffer, None).unwrap_err();
        assert_eq!(
            zero_sized_with_non_empty_buffer_err.to_string(),
            "Invalid argument error: Buffer cannot have non-zero length if the value length is zero"
        );
    }

    #[test]
    fn test_try_new_with_len() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);

        let a = FixedSizeBinaryArray::try_new_with_len(2, buffer.clone(), None, 5).unwrap();
        assert_eq!(a.len(), 5);

        let nulls = NullBuffer::new_null(5);
        let a = FixedSizeBinaryArray::try_new_with_len(2, buffer, Some(nulls), 5).unwrap();
        assert_eq!(a.len(), 5);
        assert_eq!(a.null_count(), 5);

        let a = FixedSizeBinaryArray::try_new_with_len(2, Buffer::default(), None, 0).unwrap();
        assert_eq!(a.len(), 0);
    }

    #[test]
    fn test_try_new_with_len_zero_width() {
        // Zero-width with no nulls: the case where the length cannot be inferred from the parts
        let a = FixedSizeBinaryArray::try_new_with_len(0, Buffer::default(), None, 5).unwrap();
        assert_eq!(a.len(), 5);
        assert_eq!(a.null_count(), 0);
        assert_eq!(a.values().len(), 0);

        let nulls = NullBuffer::new_null(3);
        let a =
            FixedSizeBinaryArray::try_new_with_len(0, Buffer::default(), Some(nulls), 3).unwrap();
        assert_eq!(a.len(), 3);
        assert_eq!(a.null_count(), 3);
    }

    #[test]
    fn test_try_new_with_len_negative_value_length() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);
        let err = FixedSizeBinaryArray::try_new_with_len(-1, buffer, None, 5).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Invalid argument error: Value length cannot be negative, got -1"
        );
    }

    #[test]
    fn test_try_new_with_len_incorrect_null_buffer_length() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);
        let nulls = NullBuffer::new_null(3);
        let err = FixedSizeBinaryArray::try_new_with_len(2, buffer, Some(nulls), 5).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Invalid argument error: Incorrect length of null buffer for FixedSizeBinaryArray, expected 5 got 3"
        );
    }

    #[test]
    fn test_try_new_with_len_incorrect_values_buffer_length() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);
        let err = FixedSizeBinaryArray::try_new_with_len(2, buffer, None, 3).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Invalid argument error: Incorrect length of values buffer for FixedSizeBinaryArray, expected 3 got 5"
        );
    }

    #[test]
    fn test_try_new_with_len_zero_width_non_empty_buffer() {
        let buffer = Buffer::from_vec(vec![0_u8; 10]);
        let err = FixedSizeBinaryArray::try_new_with_len(0, buffer, None, 5).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Invalid argument error: Buffer cannot have non-zero length if the value length is zero"
        );
    }
}
